# Smart Agro Insight (SAI)

A responsive React/Vite prototype based on the supplied Smart Agro Insight dashboard screenshot, with an Administrator Dashboard interface.

## Included
- Farmer-facing dashboard layout
- Administrator control center
- Farmer registration modal and searchable demo records
- Sample weather, market, alert, and service-status cards
- Responsive mobile navigation
- English/Hausa language selector UI

## Run locally
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```

## Important
This is a front-end prototype. Sample weather, market prices, alerts, and farmer records are illustrative. Farmer changes are held in browser memory only. Authentication, database persistence, live weather/market APIs, AI service integration, and production administrator permissions must be connected before real-world use.
