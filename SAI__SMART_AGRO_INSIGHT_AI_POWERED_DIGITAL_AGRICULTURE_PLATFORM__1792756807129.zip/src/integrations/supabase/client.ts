import * as Supabase from '@supabase/supabase-js'

const supabaseUrl = 'https://ptpbboracebakgliakrd.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InB0cGJib3JhY2ViYWtnbGlha3JkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODI2Nzc0ODQsImV4cCI6MjA5ODI1MzQ4NH0.g7Ct1MjyRfi7Tu3lZZ5DmivFQmVtdNNRw6ePyCormUM';

export const supabase = Supabase.createClient(supabaseUrl, supabaseAnonKey)
