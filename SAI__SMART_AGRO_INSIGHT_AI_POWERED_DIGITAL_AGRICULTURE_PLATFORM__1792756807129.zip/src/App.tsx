import React, { StrictMode, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Navigation } from '@/components/Navigation';
import { Toaster } from '@/components/ui/sonner';
import { I18nProvider } from '@/lib/i18n';
import { ShareDownloadModal } from '@/components/ShareDownloadModal';

// Lazy load components
const Dashboard = React.lazy(() => import('@/components/Dashboard'));
const Weather = React.lazy(() => import('@/components/Weather'));
const Market = React.lazy(() => import('@/components/Market'));
const Records = React.lazy(() => import('@/components/Records'));
const Alerts = React.lazy(() => import('@/components/Alerts'));
const MobileServices = React.lazy(() => import('@/components/MobileServices'));
const AiAssistant = React.lazy(() => import('@/components/AiAssistant'));
const Partnership = React.lazy(() => import('@/components/Partnership'));
const AdminDashboard = React.lazy(() => import('@/components/AdminDashboard'));
const AdminLogin = React.lazy(() => import('@/components/AdminLogin'));
const AdminSignUp = React.lazy(() => import('@/components/AdminSignUp'));

function AppContent() {
  return (
    <Router>
      <div className="min-h-screen bg-slate-50 text-slate-900 md:pl-64">
        <Navigation />
        
        <main className="container mx-auto p-4 pb-24 md:p-8 md:pb-8">
          <React.Suspense fallback={
            <div className="flex h-[60vh] items-center justify-center">
              <div className="h-8 w-8 animate-spin rounded-full border-4 border-green-600 border-t-transparent"></div>
            </div>
          }>
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/weather" element={<Weather />} />
              <Route path="/market" element={<Market />} />
              <Route path="/records" element={<Records />} />
              <Route path="/alerts" element={<Alerts />} />
              <Route path="/partnerships" element={<Partnership />} />
              <Route path="/mobile" element={<MobileServices />} />
              <Route path="/ask-sai" element={<AiAssistant />} />
              <Route path="/admin/login" element={<AdminLogin />} />
              <Route path="/admin/signup" element={<AdminSignUp />} />
              <Route path="/admin" element={<AdminDashboard />} />
              {/* Fallback: redirect unknown paths to the dashboard */}
              <Route path="*" element={<Dashboard />} />
            </Routes>
          </React.Suspense>
        </main>

        <Toaster position="top-right" closeButton richColors />
      </div>
    </Router>
  );
}

function App() {
  useEffect(() => {
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js', { scope: '/' })
          .then((registration) => {
            console.log('SW registered: ', registration);
          })
          .catch((registrationError) => {
            console.log('SW registration failed: ', registrationError);
          });
      });
    }
  }, []);

  return (
    <StrictMode>
      <I18nProvider>
        <AppContent />
        <ShareDownloadModal open={false} onClose={() => {}} />
      </I18nProvider>
    </StrictMode>
  );
}

export default App;