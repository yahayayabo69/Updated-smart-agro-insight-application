import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

/* ------------------------------------------------------------------ */
/*  MARKET PRICES — enriched with zones, categories, trends            */
/* ------------------------------------------------------------------ */

export interface MarketPrice {
  id?: string;
  crop: string;
  cropCategory: 'grains' | 'tubers' | 'cash_crops' | 'vegetables';
  price: number;
  unit: string;
  location: string;
  state: string;
  zone: string;
  trend: 'up' | 'down' | 'stable';
  change: string;
  updatedAt: string;
  verified: boolean;
}

export interface PartnershipRecord {
  id?: string;
  orgName: string;
  partnershipType: 'agribusiness' | 'cooperative' | 'buyer' | 'ngo' | 'government';
  contactPerson: string;
  contactEmail: string;
  contactPhone: string;
  state: string;
  description: string;
  status: 'pending' | 'approved' | 'rejected';
  created_at?: string;
}

export const NIGERIAN_ZONES: Record<string, string[]> = {
  'North West': ['Kano', 'Kaduna', 'Katsina', 'Sokoto', 'Kebbi', 'Zamfara', 'Jigawa'],
  'North Central': ['Niger', 'Plateau', 'Benue', 'Kogi', 'Kwara', 'FCT Abuja', 'Nasarawa'],
  'North East': ['Borno', 'Yobe', 'Bauchi', 'Adamawa', 'Gombe', 'Taraba'],
  'South West': ['Lagos', 'Oyo', 'Ogun', 'Osun', 'Ondo', 'Ekiti'],
  'South East': ['Enugu', 'Anambra', 'Abia', 'Imo', 'Ebonyi'],
  'South South': ['Rivers', 'Delta', 'Edo', 'Akwa Ibom', 'Cross River', 'Bayelsa'],
};

export const CROP_CATEGORIES: Record<string, string[]> = {
  grains: ['Maize', 'Rice', 'Sorghum', 'Millet', 'Wheat', 'Cowpea (Beans)', 'Soybean'],
  tubers: ['Yam', 'Cassava', 'Sweet Potato', 'Irish Potato'],
  cash_crops: ['Groundnut', 'Sesame', 'Cotton', 'Hibiscus', 'Cocoa', 'Cashew'],
  vegetables: ['Tomato', 'Onion', 'Pepper', 'Okra', 'Cabbage', 'Carrot', 'Spinach', 'Garlic'],
};

export const MOCK_MARKET_PRICES: MarketPrice[] = [
  // North West
  { crop: 'Maize', cropCategory: 'grains', price: 28000, unit: '100kg bag', location: 'Dawanau Kano', state: 'Kano', zone: 'North West', trend: 'up', change: '+2.5%', updatedAt: new Date().toISOString(), verified: true },
  { crop: 'Sorghum (Dawa)', cropCategory: 'grains', price: 25000, unit: '100kg bag', location: 'Kurmi Market', state: 'Kano', zone: 'North West', trend: 'up', change: '+1.8%', updatedAt: new Date().toISOString(), verified: true },
  { crop: 'Rice (Local)', cropCategory: 'grains', price: 42000, unit: '50kg bag', location: 'Sokoto Main', state: 'Sokoto', zone: 'North West', trend: 'stable', change: '0.0%', updatedAt: new Date().toISOString(), verified: true },
  { crop: 'Yam', cropCategory: 'tubers', price: 45000, unit: '100 tubers', location: 'Sabon Gari', state: 'Kaduna', zone: 'North West', trend: 'up', change: '+5.0%', updatedAt: new Date().toISOString(), verified: true },
  { crop: 'Groundnut (Kaya)', cropCategory: 'cash_crops', price: 35000, unit: '100kg bag', location: 'Katsina Main', state: 'Katsina', zone: 'North West', trend: 'up', change: '+3.2%', updatedAt: new Date().toISOString(), verified: true },
  { crop: 'Tomato (Gona)', cropCategory: 'vegetables', price: 12000, unit: '50kg bag', location: 'Birnin Kebbi', state: 'Kebbi', zone: 'North West', trend: 'down', change: '-4.1%', updatedAt: new Date().toISOString(), verified: false },
  // North Central
  { crop: 'Rice', cropCategory: 'grains', price: 38000, unit: '50kg bag', location: 'Gboko Benue', state: 'Benue', zone: 'North Central', trend: 'up', change: '+1.5%', updatedAt: new Date().toISOString(), verified: true },
  { crop: 'Cassava (Fura)', cropCategory: 'tubers', price: 15000, unit: '100 tubers', location: 'Minna Central', state: 'Niger', zone: 'North Central', trend: 'stable', change: '-0.3%', updatedAt: new Date().toISOString(), verified: true },
  { crop: 'Yam', cropCategory: 'tubers', price: 40000, unit: '100 tubers', location: 'Gboko Benue', state: 'Benue', zone: 'North Central', trend: 'up', change: '+4.2%', updatedAt: new Date().toISOString(), verified: true },
  { crop: 'Sorghum', cropCategory: 'grains', price: 22000, unit: '100kg bag', location: 'Jos Plateau', state: 'Plateau', zone: 'North Central', trend: 'stable', change: '+0.5%', updatedAt: new Date().toISOString(), verified: true },
  { crop: 'Sesame (Busa)', cropCategory: 'cash_crops', price: 55000, unit: '100kg bag', location: 'Lafia Nasarawa', state: 'Nasarawa', zone: 'North Central', trend: 'up', change: '+6.1%', updatedAt: new Date().toISOString(), verified: true },
  // North East
  { crop: 'Maize', cropCategory: 'grains', price: 26000, unit: '100kg bag', location: 'Bauchi Main', state: 'Bauchi', zone: 'North East', trend: 'up', change: '+1.9%', updatedAt: new Date().toISOString(), verified: true },
  { crop: 'Millet (Wai)', cropCategory: 'grains', price: 20000, unit: '100kg bag', location: 'Maiduguri', state: 'Borno', zone: 'North East', trend: 'stable', change: '+0.2%', updatedAt: new Date().toISOString(), verified: false },
  { crop: 'Cowpea (Lambun)', cropCategory: 'grains', price: 35000, unit: '100kg bag', location: 'Damaturu', state: 'Yobe', zone: 'North East', trend: 'up', change: '+2.1%', updatedAt: new Date().toISOString(), verified: true },
  // South West
  { crop: 'Cassava (Garri)', cropCategory: 'tubers', price: 15000, unit: '50kg bag', location: 'Mile 12 Lagos', state: 'Lagos', zone: 'South West', trend: 'down', change: '-1.2%', updatedAt: new Date().toISOString(), verified: true },
  { crop: 'Rice', cropCategory: 'grains', price: 55000, unit: '50kg bag', location: 'Bodija Ibadan', state: 'Oyo', zone: 'South West', trend: 'up', change: '+3.0%', updatedAt: new Date().toISOString(), verified: true },
  { crop: 'Yam', cropCategory: 'tubers', price: 50000, unit: '100 tubers', location: 'Bodija Ibadan', state: 'Oyo', zone: 'South West', trend: 'up', change: '+2.8%', updatedAt: new Date().toISOString(), verified: true },
  { crop: 'Tomato', cropCategory: 'vegetables', price: 18000, unit: '50kg bag', location: 'Mile 12 Lagos', state: 'Lagos', zone: 'South West', trend: 'down', change: '-2.5%', updatedAt: new Date().toISOString(), verified: true },
  { crop: 'Onion', cropCategory: 'vegetables', price: 22000, unit: '50kg bag', location: 'Lagos', state: 'Lagos', zone: 'South West', trend: 'stable', change: '+0.1%', updatedAt: new Date().toISOString(), verified: true },
  // South East
  { crop: 'Cassava', cropCategory: 'tubers', price: 12000, unit: '100 tubers', location: 'Onitsha Main', state: 'Anambra', zone: 'South East', trend: 'down', change: '-0.8%', updatedAt: new Date().toISOString(), verified: true },
  { crop: 'Yam', cropCategory: 'tubers', price: 48000, unit: '100 tubers', location: 'Enugu New Market', state: 'Enugu', zone: 'South East', trend: 'up', change: '+3.5%', updatedAt: new Date().toISOString(), verified: true },
  { crop: 'Palm Oil', cropCategory: 'cash_crops', price: 8500, unit: '25 litre', location: 'Onitsha', state: 'Anambra', zone: 'South East', trend: 'up', change: '+1.2%', updatedAt: new Date().toISOString(), verified: true },
  // South South
  { crop: 'Rice', cropCategory: 'grains', price: 48000, unit: '50kg bag', location: 'Port Harcourt', state: 'Rivers', zone: 'South South', trend: 'up', change: '+2.0%', updatedAt: new Date().toISOString(), verified: true },
  { crop: 'Cassava', cropCategory: 'tubers', price: 10000, unit: '100 tubers', location: 'Warri', state: 'Delta', zone: 'South South', trend: 'stable', change: '-0.5%', updatedAt: new Date().toISOString(), verified: true },
  { crop: 'Palm Kernel', cropCategory: 'cash_crops', price: 12000, unit: '100kg bag', location: 'Calabar', state: 'Cross River', zone: 'South South', trend: 'up', change: '+4.5%', updatedAt: new Date().toISOString(), verified: true },
];

/* ------------------------------------------------------------------ */
/*  PARTNERSHIP RECORDS                                                */
/* ------------------------------------------------------------------ */

export const DEFAULT_PARTNERSHIPS: PartnershipRecord[] = [
  { orgName: 'Sokoto Farmers Cooperative Union', partnershipType: 'cooperative', contactPerson: 'Alhaji Musa Ibrahim', contactEmail: 'info@sokotocoop.ng', contactPhone: '+234 803 000 1001', state: 'Sokoto', description: 'Union of 12 farmer cooperatives serving 5,000+ members across Sokoto State.', status: 'approved' },
  { orgName: 'YABTECH Agribusiness Hub', partnershipType: 'agribusiness', contactPerson: 'Dr. Amina Suleiman', contactEmail: 'contact@yabtech.ng', contactPhone: '+234 803 000 2002', state: 'Sokoto', description: 'Agri-tech incubator providing seed distribution, irrigation solutions, and digital advisory services.', status: 'approved' },
  { orgName: 'Kano Grain Traders Association', partnershipType: 'buyer', contactPerson: 'Baba Abdullahi', contactEmail: 'orders@kanograins.ng', contactPhone: '+234 803 000 3003', state: 'Kano', description: 'Major grain buyer and distributor operating Dawanau and Kurmi markets.', status: 'approved' },
  { orgName: 'Northern Input Suppliers Ltd', partnershipType: 'agribusiness', contactPerson: 'Eng. Yusuf Garba', contactEmail: 'sales@northerninputs.ng', contactPhone: '+234 803 000 4004', state: 'Kaduna', description: 'Leading supplier of fertilizers, pesticides, and modern farming equipment.', status: 'approved' },
  { orgName: 'Feed the North NGO', partnershipType: 'ngo', contactPerson: 'Sarah Okonkwo', contactEmail: 'programs@feedthenorth.org', contactPhone: '+234 803 000 5005', state: 'Zaria', description: 'International NGO focused on climate-resilient agriculture and women empowerment.', status: 'approved' },
  { orgName: 'Federal Ministry of Agriculture - Sokoto', partnershipType: 'government', contactPerson: 'Hon. Bello Usman', contactEmail: 'agriculture@sokoto.gov.ng', contactPhone: '+234 803 000 6006', state: 'Sokoto', description: 'State desk for implementing national agricultural intervention programs.', status: 'approved' },
  { orgName: 'Benue Rice Growers Cooperative', partnershipType: 'cooperative', contactPerson: 'Chief Emeka Nwosu', contactEmail: 'benrucecoop@gmail.com', contactPhone: '+234 803 000 7007', state: 'Benue', description: 'Cooperative of 3,000 rice farmers in the food basket of the nation.', status: 'approved' },
  { orgName: 'Lagos Produce Importers Ltd', partnershipType: 'buyer', contactPerson: 'Mrs. Funke Adeyemi', contactEmail: 'procurement@lagosproduce.ng', contactPhone: '+234 803 000 8008', state: 'Lagos', description: 'Large-scale produce buyer supplying retail chains across Southwest Nigeria.', status: 'pending' },
  { orgName: 'USAID Feed the Future Nigeria', partnershipType: 'ngo', contactPerson: 'James Mitchell', contactEmail: 'nigeria@usaid.gov', contactPhone: '+234 803 000 9009', state: 'FCT Abuja', description: 'US government initiative supporting smallholder farmers with technology and finance.', status: 'approved' },
  { orgName: 'Anchor Borrowers Programme - CBN', partnershipType: 'government', contactPerson: 'Dr. Ngozi Eze', contactEmail: 'anchor@cbn.gov.ng', contactPhone: '+234 803 000 1111', state: 'FCT Abuja', description: 'Central Bank intervention program linking smallholders to inputs and markets.', status: 'approved' },
];

/* ------------------------------------------------------------------ */
/*  SUPABASE HELPERS                                                   */
/* ------------------------------------------------------------------ */

export async function fetchMarketPrices(): Promise<MarketPrice[]> {
  const { data, error } = await supabase.from('market_prices').select('*').order('crop');
  if (error) throw error;
  return (data as MarketPrice[]) ?? [];
}

export async function fetchPartnerships(): Promise<PartnershipRecord[]> {
  const { data, error } = await supabase.from('partnerships').select('*').order('created_at', { ascending: false });
  if (error) throw error;
  return (data as PartnershipRecord[]) ?? [];
}

export async function submitPartnership(data: Omit<PartnershipRecord, 'id' | 'status' | 'created_at'>) {
  const { error } = await supabase.from('partnerships').insert([{ ...data, status: 'pending' }]);
  if (error) throw error;
}

/* ------------------------------------------------------------------ */
/*  WEATHER & FORECAST MOCK DATA                                       */
/* ------------------------------------------------------------------ */

export interface WeatherData {
  temp: number;
  condition: string;
  humidity: number;
  windSpeed: number;
  location: string;
  advice: string;
}

export interface ForecastDay {
  day: string;
  condition: string;
  temp: number;
}

export const MOCK_WEATHER: WeatherData = {
  temp: 34,
  condition: 'Sunny',
  humidity: 45,
  windSpeed: 12,
  location: 'Sokoto, Nigeria',
  advice: 'Optimal conditions for field operations. Water crops early morning to minimize evaporation.',
};

export const MOCK_FORECAST: ForecastDay[] = [
  { day: 'Mon', condition: 'Sunny', temp: 36 },
  { day: 'Tue', condition: 'Partly Cloudy', temp: 34 },
  { day: 'Wed', condition: 'Rain', temp: 30 },
  { day: 'Thu', condition: 'Thunderstorm', temp: 28 },
  { day: 'Fri', condition: 'Cloudy', temp: 31 },
];

/* ------------------------------------------------------------------ */
/*  PEST ALERT MOCK DATA                                               */
/* ------------------------------------------------------------------ */

export interface PestAlert {
  id: string;
  title: string;
  description: string;
  action: string;
  severity: 'high' | 'medium';
  location: string;
  date: string;
}

export const MOCK_PEST_ALERTS: PestAlert[] = [
  {
    id: 'a1',
    title: 'Fall Armyworm Outbreak Detected',
    description: 'High population of Fall Armyworm larvae observed in maize fields across Sokoto North and South LGAs. Immediate scouting and intervention required.',
    action: 'Scout fields daily for egg masses on upper leaf surfaces. Apply Bt-based biopesticides or chlorantraniliprole at first sign of larval damage. Remove and destroy infested plant debris.',
    severity: 'high',
    location: 'Sokoto North LGA',
    date: '2024-01-15',
  },
  {
    id: 'a2',
    title: 'Tuta Absoluta Warning',
    description: 'Tomato leafminer (Tuta Absoluta) activity increasing in tomato-growing areas. Early detection critical to prevent crop loss.',
    action: 'Install pheromone traps at 5 traps per hectare. Remove and destroy infested leaves. Apply spinosad-based products as preventive measure.',
    severity: 'medium',
    location: 'Kaduna State',
    date: '2024-01-12',
  },
];