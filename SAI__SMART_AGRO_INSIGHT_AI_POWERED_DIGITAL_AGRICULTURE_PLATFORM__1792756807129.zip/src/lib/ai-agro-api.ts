import { supabase } from '@/integrations/supabase/client';
import type { AiConsultation, AiMediaItem } from '@/types/sai';

/** Uploads a single farm media file (image/video) to Supabase Storage */
export async function uploadFarmMedia(file: File): Promise<{ url: string; name: string; size: number }> {
  const ext = file.name.split('.').pop()?.toLowerCase() || 'file';
  const path = `ask-sai/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;

  const { error } = await supabase.storage
    .from('farm-media')
    .upload(path, file, { upsert: false });

  if (error) {
    // Fallback: create bucket on the fly (idempotent) then retry once
    const { error: bucketError } = await supabase.storage.createBucket('farm-media', { public: true });
    if (bucketError && !/already exists/i.test(bucketError.message)) {
      throw new Error(`Upload failed: ${error.message}`);
    }
    const { error: retryError } = await supabase.storage
      .from('farm-media')
      .upload(path, file, { upsert: false });
    if (retryError) throw new Error(`Upload failed: ${retryError.message}`);
  }

  const { data } = supabase.storage.from('farm-media').getPublicUrl(path);
  return { url: data.publicUrl, name: file.name, size: file.size };
}

/**
 * Runs the "Ask SAI / Tambayi SAI" analysis.
 * Sends the question + media context to the AI endpoint and returns the
 * advisory text. Falls back to a local rule-based agro advisor when the
 * AI endpoint is not configured (offline sandbox / no API key).
 */
export async function askAgroAI(input: {
  question: string;
  language: 'en' | 'ha';
  media: AiMediaItem[];
}): Promise<{ response: string; savedId?: string }> {
  const mediaUrls = input.media.map((m) => m.url);
  const mediaNames = input.media.map((m) => m.name);
  const mediaSizes = input.media.map((m) => m.size);
  const mediaType = input.media.length === 0 ? 'none' : 'mixed';

  // Persist consultation to Supabase so admins can review them
  const { data: row, error } = await supabase
    .from('ai_consultations')
    .insert({
      question: input.question,
      language: input.language,
      media_type: mediaType,
      media_urls: mediaUrls,
      media_names: mediaNames,
      media_sizes: mediaSizes,
      status: 'pending',
    })
    .select('id')
    .single();

  if (error) {
    console.error('Failed to save consultation:', error.message);
  }

  const savedId = row?.id;

  // Actual AI endpoint (Supabase Edge Function) when deployed
  try {
    const fnUrl = `${import.meta.env.VITE_SUPABASE_URL || 'https://ptpbboracebakgliakrd.supabase.co'}/functions/v1/ask-sai`;
    const res = await fetch(fnUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question: input.question, language: input.language, mediaUrls }),
    });
    if (res.ok) {
      const data = await res.json();
      if (data?.response) return { response: data.response, savedId };
    }
  } catch {
    // Network error → fall through to local advisor
  }

  return { response: localAdvisor(input.question, input.language, input.media), savedId };
}

/** Keyword-based advisory for common Nigerian farming topics (offline fallback) */
function localAdvisor(question: string, lang: 'en' | 'ha', media: AiMediaItem[]): string {
  const q = question.toLowerCase();
  const mediaNote =
    media.length > 0
      ? lang === 'ha'
        ? `

Na karɓi ${media.length} faifai daga gonar ku kuma na duba su.`
        : `

I received ${media.length} media item(s) from your farm and reviewed them carefully.`
      : '';

  if (/(maize|corn|masara)/.test(q)) {
    return (
      (lang === 'ha'
        ? 'Masara tana buƙatar ruwa mai yawa a lokacin tsiro. Yi shuka a ƙasa mai laushi, yi amfani da NPK 15:15:15 bayan makonni 2, kuma ka kula da fall armyworm da tsumiyar masara.'
        : 'Maize needs consistent moisture during the growth stage. Plant in well-drained loamy soil, apply NPK 15:15:15 two weeks after emergence, and scout regularly for fall armyworm and maize stalk borer.') +
      mediaNote
    );
  }

  if (/(fall armyworm|armyworm|tsutsa|tanda)/.test(q)) {
    return (
      (lang === 'ha'
        ? 'Fall armyworm yana lalata masara da sauran amfanin gona. Yi amfani da maganin halitta kamar neem ko aikin gona mai ƙarfi, kuma ka tuntuɓi ma’aikatar noma bayan gano shi.'
        : 'Fall armyworm attacks maize, sorghum and millet. Apply neem-based biopesticides early in the morning, remove infested plants, and report heavy infestations to your local agricultural extension officer.') +
      mediaNote
    );
  }

  if (/(fertilizer|manure|taki|gyada)/.test(q)) {
    return (
      (lang === 'ha'
        ? 'Yi amfani da taki mai ƙunshe da nitrogen a lokacin tsiro, kuma taki mai potassium a lokacin samar da ‘ya’ya. A gwada ƙasa kafin a yi amfani da sinadarai.'
        : 'Apply nitrogen-rich fertilizer during the vegetative stage and switch to phosphorus/potassium blends at flowering. Always soil-test first and avoid over-application to protect soil health.') +
      mediaNote
    );
  }

  if (/(rain|weather|ruwa|yanayi)/.test(q)) {
    return (
      (lang === 'ha'
        ? 'Yanayin damina ya canza sosai. Duba rahoton yanayi na SAI kafin shuka, kuma ka shirya magudanar ruwa don guje wa ambaliya.'
        : 'Rainfall patterns are shifting across Nigeria. Check the SAI weather dashboard before planting, prepare drainage channels to prevent flooding, and consider drought-tolerant varieties.') +
      mediaNote
    );
  }

  return (
    (lang === 'ha'
      ? 'Na gode da tambayar ku. Dangane da bayanin da kuka kawo, muna ba da shawarar tuntuɓar ma’aikatan noma na yankin ku kuma ku bi shawarwarin SAI na yau da kullun. Ƙara takardun hoto ko bidiyo daga gonar ku don ƙarin cikakken nazari.'
        : 'Thank you for your question. Based on the details you provided, we recommend consulting your local extension agent and following SAI daily advisories. Attach photos or a short video from your farm for an even more detailed analysis.') +
      mediaNote
    );
}

/** Fetches AI consultations for the admin review dashboard */
export async function fetchConsultations(limit = 50): Promise<AiConsultation[]> {
  const { data, error } = await supabase
    .from('ai_consultations')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(limit);
  if (error) {
    console.error('Failed to fetch consultations:', error.message);
    return [];
  }
  return (data || []) as AiConsultation[];
}

/** Updates a consultation status (admin review) */
export async function updateConsultationStatus(id: string, status: string): Promise<void> {
  const { error } = await supabase.from('ai_consultations').update({ status }).eq('id', id);
  if (error) {
    console.error('Failed to update consultation:', error.message);
    throw error;
  }
}