import { toast } from 'sonner';

export interface FarmerRecord {
  id: string;
  farmer_name: string;
  location: string;
  crop: string;
  farm_size: string;
  planting_date: string;
  expected_harvest: string;
  yield_estimate: string;
  phone: string;
  status: 'Active' | 'Harvested' | 'Pending';
  created_at?: string;
}

export const STORAGE_KEY = 'sai-farmer-records';

export const CROP_OPTIONS = [
  'Maize', 'Cassava', 'Yam', 'Rice', 'Beans',
  'Tomato', 'Pepper', 'Groundnut', 'Garlic',
];

export const STATUS_OPTIONS: FarmerRecord['status'][] = ['Active', 'Harvested', 'Pending'];

export function exportToCSV(records: FarmerRecord[]): string {
  const headers = ['ID', 'Farmer Name', 'Location', 'Crop', 'Farm Size', 'Planting Date', 'Expected Harvest', 'Yield Estimate', 'Phone', 'Status'];
  const rows = records.map(r => [
    r.id, r.farmer_name, r.location, r.crop, r.farm_size,
    r.planting_date, r.expected_harvest, r.yield_estimate,
    r.phone, r.status,
  ]);
  const nl = String.fromCharCode(10);
  return [headers.join(','), ...rows.map(r => r.map(v => `"${v}"`).join(','))].join(nl);
}

export const handleShare = async () => {
  const shareData = {
    title: 'SAI Smart Agro Insight',
    text: 'Check out SAI Smart Agro Insight - Digital advisory for Nigerian farmers!',
    url: window.location.origin,
  };

  try {
    if (navigator.share) {
      await navigator.share(shareData);
      toast.success('Shared successfully!');
    } else {
      await navigator.clipboard.writeText(window.location.origin);
      toast.success('Link copied to clipboard!');
    }
  } catch (err) {
    if ((err as Error).name !== 'AbortError') {
      toast.error('Could not share the app');
    }
  }
};