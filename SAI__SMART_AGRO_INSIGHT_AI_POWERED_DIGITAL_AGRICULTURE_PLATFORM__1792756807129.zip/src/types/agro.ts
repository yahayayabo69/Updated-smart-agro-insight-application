export type Language = 'en' | 'ha';

export interface FarmerRecord {
  id: string;
  nin: string;
  fullName: string;
  phone: string;
  state: string;
  lga: string;
  cooperative?: string;
  farmSizeHectares: number;
  soilType: string;
  irrigationMode: 'rainfed' | 'irrigation' | 'mixed';
  plantingDate: string;
  primaryCrop: string;
  secondaryCrop?: string;
  createdAt: string;
  status: 'pending' | 'approved' | 'verified';
}

export interface CropDefinition {
  name: string;
  hausaName: string;
  yorubaName: string;
  igboName: string;
  category: 'staple' | 'cash' | 'vegetable' | 'tuber' | 'legume' | 'spice' | 'fruit' | 'fiber';
  growingSeasons: string[];
  optimalSoil: string;
  rainfallNeeded: string;
  daysToHarvest: number;
  yieldPerHectare: string;
  pests: string[];
  fertilizerFormula: string;
  zones: string[];
}

export interface WeatherAdvisory {
  zone: string;
  temperature: string;
  humidity: string;
  rainfall: string;
  windSpeed: string;
  forecast: string;
  advisory: string;
  rainWindow: string;
}

export interface PestDiagnosis {
  pestName: string;
  affectedCrops: string[];
  symptoms: string[];
  organicTreatment: string;
  chemicalTreatment: string;
  severity: 'low' | 'medium' | 'high';
}

export interface MarketPriceEntry {
  marketName: string;
  location: string;
  crop: string;
  pricePer100kg: number;
  pricePerTon: number;
  priceDelta7d: number;
  volume: string;
  demandIndex: 'low' | 'medium' | 'high';
  brokerContact: string;
}

export interface AdminInquiry {
  whatsapp: string;
  phone: string;
  email: string;
  officeAddress: string;
  regionalOfficers: { region: string; name: string; phone: string }[];
}
