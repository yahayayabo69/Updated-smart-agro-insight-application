export interface Farmer {
  id: string;
  fullName: string;
  phone: string;
  password: string;
  email?: string;
  state: string;
  lga: string;
  community: string;
  preferredLanguage: 'en' | 'ha';
  mainCrops: string[];
  createdAt: string;
}

export interface Farm {
  id: string;
  farmerId: string;
  name: string;
  location: string;
  size: number;
  unit: 'ha' | 'acres';
  crop: string;
  plantingDate: string;
  expectedHarvest: string;
  notes: string;
  createdAt: string;
}

export interface NorthernCrop {
  id: string;
  nameEn: string;
  nameHa: string;
  waterReq: string;
  pests: string[];
  durationDays: number;
  soilType: string;
  season: string;
}

export interface MarketPrice {
  id: string;
  market: string;
  price: number;
  unit: string;
  trend: 'up' | 'down' | 'stable';
  verified: boolean;
  updatedAt: string;
}

export interface Alert {
  id: string;
  title: string;
  severity: 'high' | 'medium' | 'low';
  location: string;
  date: string;
  description: string;
  action: string;
}

export interface Inquiry {
  id: string;
  name: string;
  email: string;
  message: string;
  responded: boolean;
  response?: string;
  createdAt: string;
}

export interface PartnerOrg {
  id: string;
  name: string;
  type: 'cooperative' | 'agribusiness' | 'buyer' | 'input_supplier' | 'ngo' | 'extension' | 'financial';
  crops: string[];
  location: string;
  verified: boolean;
  contact: string;
}

export interface IoTConfig {
  brokerUrl: string;
  topic: string;
  deviceId: string;
  connected: boolean;
}

export interface SmsConfig {
  provider: 'termii' | 'africastalking' | '';
  apiKey: string;
}

export type Role = 'farmer' | 'admin' | 'guest';

export interface AiMediaItem {
  url: string;
  name: string;
  size: number;
  type: 'image' | 'video';
}

export interface AiConsultation {
  id: string;
  question: string;
  language: 'en' | 'ha';
  media_type: string;
  media_urls: string[];
  media_names: string[];
  media_sizes: number[];
  ai_response: string;
  status: string;
  created_at: string;
}