import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { ShieldCheck, Mail, Lock, User, Building, Loader2, Leaf, CheckCircle2, ArrowRight } from 'lucide-react';

export function AdminSignUp() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  
  // Step 1: Auth credentials
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');

  // Step 2: Org details
  const [organization, setOrganization] = useState('');
  const [designation, setDesignation] = useState('');
  const [stateDesk, setStateDesk] = useState('');
  const [roleAccess, setRoleAccess] = useState('admin');

  const validateStep1 = () => {
    if (!fullName.trim()) {
      toast.error('Please enter your full name.');
      return false;
    }
    if (!email.trim() || !email.includes('@')) {
      toast.error('Please enter a valid email address.');
      return false;
    }
    if (password.length < 8) {
      setPasswordError('Password must be at least 8 characters.');
      return false;
    }
    if (password !== confirmPassword) {
      setPasswordError('Passwords do not match.');
      return false;
    }
    setPasswordError('');
    return true;
  };

  const handleNext = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateStep1()) return;
    setStep(2);
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (step === 1) {
      handleNext(e);
      return;
    }

    setLoading(true);
    try {
      // Create auth user with metadata
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName,
            organization,
            designation,
            state_desk: stateDesk,
            role_access: roleAccess,
          },
        },
      });

      if (authError) throw authError;

      if (authData.user) {
        // Store admin profile in admins table
        const { error: profileError } = await supabase
          .from('admins')
          .insert([{
            email,
            name: fullName,
            role: roleAccess,
          }]);

        if (profileError) throw profileError;
      }

      toast.success('Account created successfully! Please sign in.');
      navigate('/admin/login', { state: { prefillEmail: email } });
    } catch (error: any) {
      toast.error(error.message || 'Sign up failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-green-50 via-white to-emerald-50 p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-green-600 shadow-lg shadow-green-200">
            <ShieldCheck className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-2xl font-black text-slate-900">Admin Registration</h1>
          <p className="mt-1 text-sm text-slate-500">First time accessing SAI Administration? Register below.</p>
        </div>

        {/* Progress Steps */}
        <div className="flex items-center justify-center gap-2 mb-8">
          <div className={`flex h-8 w-8 items-center justify-center rounded-full text-xs font-black ${step >= 1 ? 'bg-green-600 text-white' : 'bg-slate-200 text-slate-500'}`}>
            {step > 1 ? <CheckCircle2 className="h-4 w-4" /> : '1'}
          </div>
          <div className={`h-1 w-12 rounded-full ${step >= 2 ? 'bg-green-600' : 'bg-slate-200'}`} />
          <div className={`flex h-8 w-8 items-center justify-center rounded-full text-xs font-black ${step >= 2 ? 'bg-green-600 text-white' : 'bg-slate-200 text-slate-500'}`}>
            2
          </div>
        </div>

        {/* Sign Up Card */}
        <div className="rounded-2xl border border-slate-200 bg-white p-8 shadow-xl shadow-slate-100/50">
          <form onSubmit={handleSignUp} className="space-y-5">
            {step === 1 ? (
              <>
                <div>
                  <label className="mb-1.5 block text-sm font-semibold text-slate-700">Full Name</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={e => setFullName(e.target.value)}
                      placeholder="Your full name"
                      className="w-full rounded-xl border border-slate-200 bg-slate-50 py-3 pl-10 pr-4 text-sm font-medium text-slate-900 placeholder:text-slate-400 focus:border-green-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-green-100"
                    />
                  </div>
                </div>

                <div>
                  <label className="mb-1.5 block text-sm font-semibold text-slate-700">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={e => setEmail(e.target.value)}
                      placeholder="admin@example.com"
                      className="w-full rounded-xl border border-slate-200 bg-slate-50 py-3 pl-10 pr-4 text-sm font-medium text-slate-900 placeholder:text-slate-400 focus:border-green-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-green-100"
                    />
                  </div>
                </div>

                <div>
                  <label className="mb-1.5 block text-sm font-semibold text-slate-700">Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={e => { setPassword(e.target.value); setPasswordError(''); }}
                      placeholder="Min 8 characters"
                      className={`w-full rounded-xl border bg-slate-50 py-3 pl-10 pr-4 text-sm font-medium text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none focus:ring-2 ${passwordError ? 'border-red-300 focus:border-red-500 focus:ring-red-100' : 'border-slate-200 focus:border-green-500 focus:ring-green-100'}`}
                    />
                  </div>
                  {passwordError && <p className="mt-1 text-xs text-red-500 font-medium">{passwordError}</p>}
                </div>

                <div>
                  <label className="mb-1.5 block text-sm font-semibold text-slate-700">Confirm Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                    <input
                      type="password"
                      required
                      value={confirmPassword}
                      onChange={e => { setConfirmPassword(e.target.value); setPasswordError(''); }}
                      placeholder="Repeat password"
                      className={`w-full rounded-xl border bg-slate-50 py-3 pl-10 pr-4 text-sm font-medium text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none focus:ring-2 ${passwordError ? 'border-red-300 focus:border-red-500 focus:ring-red-100' : 'border-slate-200 focus:border-green-500 focus:ring-green-100'}`}
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="flex w-full items-center justify-center gap-2 rounded-xl bg-green-600 py-3 text-sm font-bold text-white shadow-lg shadow-green-200 transition-all hover:bg-green-700 active:scale-[0.98]"
                >
                  Continue <ArrowRight className="h-4 w-4" />
                </button>
              </>
            ) : (
              <>
                <div>
                  <label className="mb-1.5 block text-sm font-semibold text-slate-700">Organization / Agency</label>
                  <div className="relative">
                    <Building className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      required
                      value={organization}
                      onChange={e => setOrganization(e.target.value)}
                      placeholder="Organization or agency name"
                      className="w-full rounded-xl border border-slate-200 bg-slate-50 py-3 pl-10 pr-4 text-sm font-medium text-slate-900 placeholder:text-slate-400 focus:border-green-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-green-100"
                    />
                  </div>
                </div>

                <div>
                  <label className="mb-1.5 block text-sm font-semibold text-slate-700">Designation</label>
                  <input
                    type="text"
                    required
                    value={designation}
                    onChange={e => setDesignation(e.target.value)}
                    placeholder="e.g. Director, Coordinator"
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 py-3 px-4 text-sm font-medium text-slate-900 placeholder:text-slate-400 focus:border-green-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-green-100"
                  />
                </div>

                <div>
                  <label className="mb-1.5 block text-sm font-semibold text-slate-700">State Desk</label>
                  <input
                    type="text"
                    required
                    value={stateDesk}
                    onChange={e => setStateDesk(e.target.value)}
                    placeholder="e.g. Sokoto State"
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 py-3 px-4 text-sm font-medium text-slate-900 placeholder:text-slate-400 focus:border-green-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-green-100"
                  />
                </div>

                <div>
                  <label className="mb-1.5 block text-sm font-semibold text-slate-700">Role Access</label>
                  <select
                    value={roleAccess}
                    onChange={e => setRoleAccess(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 py-3 px-4 text-sm font-medium text-slate-900 focus:border-green-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-green-100"
                  >
                    <option value="super_admin">Super Administrator</option>
                    <option value="admin">Administrator</option>
                    <option value="moderator">Moderator</option>
                    <option value="analyst">Data Analyst</option>
                    <option value="viewer">Viewer</option>
                  </select>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="flex w-full items-center justify-center gap-2 rounded-xl bg-green-600 py-3 text-sm font-bold text-white shadow-lg shadow-green-200 transition-all hover:bg-green-700 active:scale-[0.98] disabled:opacity-60"
                >
                  {loading ? (
                    <><Loader2 className="h-4 w-4 animate-spin" /> Creating Account...</>
                  ) : (
                    <><ShieldCheck className="h-4 w-4" /> Complete Registration</>
                  )}
                </button>
              </>
            )}
          </form>

          <div className="mt-6 text-center">
            <button
              onClick={() => step === 2 ? setStep(1) : navigate('/admin/login')}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-green-600"
            >
              <Leaf className="h-3.5 w-3.5" />
              {step === 2 ? 'Back to Step 1' : 'Already have an account? Sign In'}
            </button>
          </div>
        </div>

        <p className="mt-6 text-center text-[11px] text-slate-400">
          Authorized personnel only. All registrations are logged.
        </p>
      </div>
    </div>
  );
}

export default AdminSignUp;
