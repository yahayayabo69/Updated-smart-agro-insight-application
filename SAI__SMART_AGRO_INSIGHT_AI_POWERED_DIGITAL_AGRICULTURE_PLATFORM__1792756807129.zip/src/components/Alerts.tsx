import React from 'react';
import { 
  Bell, 
  AlertTriangle, 
  AlertCircle, 
  Info,
  MapPin,
  Calendar,
  ChevronRight,
  ShieldCheck,
  Phone
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MOCK_PEST_ALERTS } from '@/lib/mock-data';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

export default function Alerts() {
  return (
    <div className="space-y-8 pb-8">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between px-2">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">Pest & Disease Alerts</h2>
          <p className="text-slate-500 font-medium">Real-time biosecurity warnings for your region</p>
        </div>
        <Button className="rounded-xl bg-slate-900 font-bold h-11 px-6 shadow-xl">
          <Phone className="h-4 w-4 mr-2 text-green-400" /> Emergency Hotline
        </Button>
      </div>

      {/* Emergency Advisory Banner */}
      <div className="grid gap-6">
        {MOCK_PEST_ALERTS.map((alert) => (
          <Card key={alert.id} className={cn(
            "group overflow-hidden border-none shadow-xl transition-all hover:shadow-2xl",
            alert.severity === 'high' ? "bg-red-50" : "bg-amber-50"
          )}>
            <div className="flex flex-col md:flex-row">
              {/* Severity Side Tab */}
              <div className={cn(
                "flex w-full flex-shrink-0 flex-col items-center justify-center p-6 md:w-40",
                alert.severity === 'high' ? "bg-red-600 text-white" : "bg-amber-500 text-white"
              )}>
                {alert.severity === 'high' ? (
                  <AlertTriangle className="h-10 w-10 mb-2 animate-pulse" />
                ) : (
                  <AlertCircle className="h-10 w-10 mb-2" />
                )}
                <span className="text-[10px] font-black uppercase tracking-[0.2em]">{alert.severity} Risk</span>
              </div>

              {/* Content Area */}
              <div className="flex flex-1 flex-col p-8">
                <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
                  <div className="space-y-1">
                    <h3 className="text-2xl font-black text-slate-900 tracking-tight">{alert.title}</h3>
                    <div className="flex flex-wrap items-center gap-4 text-xs font-bold text-slate-400">
                      <span className="flex items-center gap-1.5 uppercase tracking-wider">
                        <MapPin className="h-3.5 w-3.5" /> {alert.location}
                      </span>
                      <span className="flex items-center gap-1.5 uppercase tracking-wider">
                        <Calendar className="h-3.5 w-3.5" /> Reported {new Date(alert.date).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                  <Badge variant="outline" className={cn(
                    "w-fit border-2 px-3 py-1 font-black uppercase tracking-widest",
                    alert.severity === 'high' ? "border-red-200 text-red-600 bg-red-50/50" : "border-amber-200 text-amber-600 bg-amber-50/50"
                  )}>
                    Emergency
                  </Badge>
                </div>

                <div className="mb-8 max-w-2xl">
                   <p className="text-sm font-medium leading-relaxed text-slate-600 mb-6">
                     {alert.description}
                   </p>
                   
                   <div className="rounded-2xl border border-slate-200 bg-white/50 p-6 backdrop-blur-sm">
                      <div className="mb-3 flex items-center gap-2">
                         <ShieldCheck className={cn(
                           "h-5 w-5",
                           alert.severity === 'high' ? "text-red-600" : "text-amber-600"
                         )} />
                         <span className="text-xs font-black uppercase tracking-widest text-slate-900">Recommended Counter-Action</span>
                      </div>
                      <p className="text-sm font-bold leading-relaxed text-slate-800 italic">
                        "{alert.action}"
                      </p>
                   </div>
                </div>

                <div className="mt-auto flex flex-wrap gap-4 pt-4 border-t border-slate-100">
                   <Button size="sm" variant="outline" className="rounded-lg font-bold border-slate-200 h-10 px-4">
                     Request On-Field Visit
                   </Button>
                   <Button size="sm" className={cn(
                     "rounded-lg font-black h-10 px-4 text-white shadow-lg",
                     alert.severity === 'high' ? "bg-red-600 shadow-red-600/20" : "bg-amber-500 shadow-amber-500/20"
                   )}>
                     Download Treatment Guide <ChevronRight className="h-4 w-4 ml-1" />
                   </Button>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* General Information / Education */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
         <Card className="border-none bg-white p-6 shadow-xl shadow-slate-200/50">
            <h4 className="text-lg font-black text-slate-900 mb-2 flex items-center gap-2">
               <Info className="h-5 w-5 text-blue-500" />
               Prevention Tips
            </h4>
            <ul className="space-y-3">
               {[
                 'Always use certified disease-free seeds.',
                 'Ensure proper distance between planting rows.',
                 'Monitor fields at least twice a week.'
               ].map((tip, i) => (
                 <li key={i} className="flex gap-2 text-xs font-medium text-slate-500 leading-relaxed">
                   <span className="h-1.5 w-1.5 rounded-full bg-blue-500 mt-1.5 flex-shrink-0"></span>
                   {tip}
                 </li>
               ))}
            </ul>
         </Card>

         <Card className="border-none bg-white p-6 shadow-xl shadow-slate-200/50 lg:col-span-2">
            <h4 className="text-lg font-black text-slate-900 mb-4 tracking-tight">Report an Infestation</h4>
            <p className="text-xs text-slate-500 leading-relaxed mb-6 max-w-md">
              Help us help you and your community. If you see signs of unusual pests or disease, report it immediately to our network of extension workers.
            </p>
            <div className="flex gap-4">
               <Button variant="outline" className="rounded-xl font-bold h-11 px-6 border-slate-200">
                 Upload Photo
               </Button>
               <Button className="rounded-xl bg-slate-900 font-bold h-11 px-6 text-white">
                 Submit Report
               </Button>
            </div>
         </Card>
      </div>
    </div>
  );
}
