import React, { useState, useMemo } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  MapPin, 
  Search,
  Filter,
  ArrowRightLeft,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Calculator
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { MOCK_MARKET_PRICES, NIGERIAN_ZONES, CROP_CATEGORIES, type MarketPrice } from '@/lib/mock-data';
import { useI18n } from '@/lib/i18n';
import { motion } from 'framer-motion';

const ZONE_KEYS = Object.keys(NIGERIAN_ZONES);
const CATEGORY_KEYS = Object.keys(CROP_CATEGORIES);

export default function Market() {
  const { t } = useI18n();
  const [search, setSearch] = useState('');
  const [zoneFilter, setZoneFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [arbitrageFrom, setArbitrageFrom] = useState('');
  const [arbitrageTo, setArbitrageTo] = useState('');
  const [showArbitrage, setShowArbitrage] = useState(false);

  const filtered = useMemo(() => {
    return MOCK_MARKET_PRICES.filter((item) => {
      const matchSearch = search === '' || item.crop.toLowerCase().includes(search.toLowerCase()) || item.location.toLowerCase().includes(search.toLowerCase());
      const matchZone = zoneFilter === 'all' || item.zone === zoneFilter;
      const matchCat = categoryFilter === 'all' || item.cropCategory === categoryFilter;
      return matchSearch && matchZone && matchCat;
    });
  }, [search, zoneFilter, categoryFilter]);

  const topGainer = useMemo(() => {
    const ups = MOCK_MARKET_PRICES.filter(m => m.trend === 'up').sort((a, b) => parseFloat(b.change) - parseFloat(a.change));
    return ups[0];
  }, []);

  const topLoser = useMemo(() => {
    const downs = MOCK_MARKET_PRICES.filter(m => m.trend === 'down').sort((a, b) => parseFloat(a.change) - parseFloat(b.change));
    return downs[0];
  }, []);

  const arbitrageResult = useMemo(() => {
    if (!arbitrageFrom || !arbitrageTo) return null;
    const crops = [...new Set(MOCK_MARKET_PRICES.map(p => p.crop))];
    let bestSpread: { crop: string; fromPrice: number; toPrice: number; spread: number } | null = null;
    for (const crop of crops) {
      const fromPrices = MOCK_MARKET_PRICES.filter(p => p.crop === crop && p.location.includes(arbitrageFrom));
      const toPrices = MOCK_MARKET_PRICES.filter(p => p.crop === crop && p.location.includes(arbitrageTo));
      for (const fp of fromPrices) {
        for (const tp of toPrices) {
          const spread = tp.price - fp.price;
          if (!bestSpread || spread > bestSpread.spread) {
            bestSpread = { crop, fromPrice: fp.price, toPrice: tp.price, spread };
          }
        }
      }
    }
    return bestSpread;
  }, [arbitrageFrom, arbitrageTo]);

  const lastUpdate = MOCK_MARKET_PRICES[0]?.updatedAt;
  const hoursAgo = lastUpdate ? Math.max(1, Math.round((Date.now() - new Date(lastUpdate).getTime()) / 3600000)) : 0;

  return (
    <div className="space-y-8 pb-8">
      {/* Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between px-2">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">{t('marketIntelligence')}</h2>
          <p className="text-slate-500 font-medium">{t('realtimePrices')}</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button variant="outline" className="rounded-xl border-slate-200 shadow-sm font-bold h-11">
            <Filter className="h-4 w-4 mr-2" /> {t('filter')}
          </Button>
          <Button className="rounded-xl bg-green-600 font-bold h-11 px-6 shadow-lg shadow-green-600/20">
            {t('compareMarkets')}
          </Button>
        </div>
      </div>

      {/* Ticker Banner */}
      <div className="flex items-center gap-3 rounded-xl bg-green-600 px-4 py-3 text-white">
        <Clock className="h-4 w-4 shrink-0" />
        <span className="text-xs font-bold">{t('lastUpdated')}: {hoursAgo} {t('hoursAgo')}</span>
        <Badge className="ml-auto bg-white/20 text-white hover:bg-white/20 border-none text-[10px] font-bold uppercase">
          {t('fresh')}
        </Badge>
      </div>

      {/* Featured Cards */}
      <div className="grid gap-6 md:grid-cols-3">
        {topGainer && (
          <Card className="border-none bg-white p-6 shadow-xl shadow-slate-200/50">
            <div className="flex items-center gap-4 mb-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-green-50 text-green-600">
                <TrendingUp className="h-6 w-6" />
              </div>
              <div>
                <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">{t('topGainer')}</p>
                <h3 className="text-xl font-black text-slate-900">{topGainer.crop}</h3>
              </div>
            </div>
            <div className="flex items-end justify-between">
              <span className="text-3xl font-black text-slate-900">&#8358;{topGainer.price.toLocaleString()}</span>
              <Badge className="bg-green-100 text-green-700 hover:bg-green-100 border-none font-black text-xs">{topGainer.change}</Badge>
            </div>
            <p className="mt-4 text-xs font-bold text-slate-400 flex items-center gap-1 uppercase tracking-wider">
              <MapPin className="h-3 w-3" /> {topGainer.location}
            </p>
          </Card>
        )}

        {topLoser && (
          <Card className="border-none bg-white p-6 shadow-xl shadow-slate-200/50">
            <div className="flex items-center gap-4 mb-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-red-50 text-red-600">
                <TrendingDown className="h-6 w-6" />
              </div>
              <div>
                <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">{t('topLoser')}</p>
                <h3 className="text-xl font-black text-slate-900">{topLoser.crop}</h3>
              </div>
            </div>
            <div className="flex items-end justify-between">
              <span className="text-3xl font-black text-slate-900">&#8358;{topLoser.price.toLocaleString()}</span>
              <Badge className="bg-red-100 text-red-700 hover:bg-red-100 border-none font-black text-xs">{topLoser.change}</Badge>
            </div>
            <p className="mt-4 text-xs font-bold text-slate-400 flex items-center gap-1 uppercase tracking-wider">
              <MapPin className="h-3 w-3" /> {topLoser.location}
            </p>
          </Card>
        )}

        <Card className="border-none bg-slate-900 p-6 text-white shadow-xl">
          <div className="h-full flex flex-col justify-between">
            <div>
              <h3 className="text-lg font-black mb-2 tracking-tight">{t('marketPulse')}</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Overall market trends show a 1.2% increase in grain prices this week due to regional logistics shifts across Nigeria.
              </p>
            </div>
            <Button size="sm" className="mt-6 bg-white text-slate-900 font-black hover:bg-slate-100">
              {t('weeklyReport')}
            </Button>
          </div>
        </Card>
      </div>

      {/* Arbitrage Calculator */}
      <Card className="border-none bg-white shadow-2xl shadow-slate-200/60 overflow-hidden">
        <CardHeader className="border-b border-slate-50 p-6">
          <div className="flex items-center gap-2">
            <Calculator className="h-5 w-5 text-green-600" />
            <CardTitle className="text-lg font-black tracking-tight">{t('priceDispersion')}</CardTitle>
          </div>
          <CardDescription>{t('historicalTrends')}</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end">
            <div className="flex-1">
              <label className="mb-1.5 block text-xs font-bold text-slate-500 uppercase tracking-wider">{t('fromMarket')}</label>
              <Input placeholder="e.g. Kano" value={arbitrageFrom} onChange={e => setArbitrageFrom(e.target.value)} className="h-11 rounded-xl bg-slate-50 border-none font-medium" />
            </div>
            <div className="flex-1">
              <label className="mb-1.5 block text-xs font-bold text-slate-500 uppercase tracking-wider">{t('toMarket')}</label>
              <Input placeholder="e.g. Lagos" value={arbitrageTo} onChange={e => setArbitrageTo(e.target.value)} className="h-11 rounded-xl bg-slate-50 border-none font-medium" />
            </div>
            <Button onClick={() => setShowArbitrage(true)} className="h-11 rounded-xl bg-green-600 font-bold px-6 shadow-lg shadow-green-600/20">
              {t('calculateArbitrage')}
            </Button>
          </div>
          {showArbitrage && arbitrageResult && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="mt-4 rounded-xl bg-green-50 p-4 border border-green-200">
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle2 className="h-4 w-4 text-green-600" />
                <span className="text-sm font-bold text-slate-900">{arbitrageResult.crop}</span>
              </div>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase">{t('fromMarket')}</p>
                  <p className="text-sm font-black text-slate-900">&#8358;{arbitrageResult.fromPrice.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase">{t('toMarket')}</p>
                  <p className="text-sm font-black text-slate-900">&#8358;{arbitrageResult.toPrice.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase">{t('potentialProfit')}</p>
                  <p className="text-sm font-black text-green-700">&#8358;{arbitrageResult.spread.toLocaleString()}</p>
                </div>
              </div>
            </motion.div>
          )}
          {showArbitrage && !arbitrageResult && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="mt-4 rounded-xl bg-amber-50 p-4 border border-amber-200">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-amber-600" />
                <p className="text-sm font-semibold text-amber-800">No direct price data found between those markets. Try broader terms.</p>
              </div>
            </motion.div>
          )}
        </CardContent>
      </Card>

      {/* Main Price Table */}
      <Card className="border-none bg-white shadow-2xl shadow-slate-200/60 overflow-hidden">
        <CardHeader className="border-b border-slate-50 p-6">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <CardTitle className="text-xl font-black tracking-tight">{t('priceFeed')}</CardTitle>
              <CardDescription className="text-xs font-bold uppercase tracking-widest text-slate-400">{filtered.length} {t('records')}</CardDescription>
            </div>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
              <div className="relative w-full sm:w-64">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                <Input 
                  placeholder={t('searchCrops')} 
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  className="pl-10 h-11 rounded-xl bg-slate-50 border-none font-medium placeholder:text-slate-400"
                />
              </div>
              <Select value={zoneFilter} onValueChange={setZoneFilter}>
                <SelectTrigger className="h-11 w-full sm:w-48 rounded-xl bg-slate-50 border-none font-medium">
                  <SelectValue placeholder={t('allZones')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t('allZones')}</SelectItem>
                  {ZONE_KEYS.map(z => <SelectItem key={z} value={z}>{z}</SelectItem>)}
                </SelectContent>
              </Select>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="h-11 w-full sm:w-48 rounded-xl bg-slate-50 border-none font-medium">
                  <SelectValue placeholder={t('allCategories')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t('allCategories')}</SelectItem>
                  {CATEGORY_KEYS.map(c => <SelectItem key={c} value={c}>{t(c)}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-50 text-[10px] font-black uppercase tracking-widest text-slate-400">
                  <th className="px-6 py-4">{t('cropType')}</th>
                  <th className="px-6 py-4 text-center">{t('trend')}</th>
                  <th className="px-6 py-4">{t('price')}</th>
                  <th className="px-6 py-4">{t('unit')}</th>
                  <th className="px-6 py-4">{t('marketLocation')}</th>
                  <th className="px-6 py-4 text-right">{t('actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {filtered.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center">
                      <p className="text-sm font-semibold text-slate-400">{t('noData')}</p>
                    </td>
                  </tr>
                ) : (
                  filtered.map((item, idx) => (
                    <tr key={idx} className="group transition-colors hover:bg-green-50/50">
                      <td className="px-6 py-5">
                        <div className="flex items-center gap-3">
                          <div className="h-10 w-10 rounded-xl bg-slate-100 flex items-center justify-center transition-colors group-hover:bg-white shadow-sm">
                            <ArrowRightLeft className="h-5 w-5 text-slate-400 group-hover:text-green-600" />
                          </div>
                          <div>
                            <span className="text-sm font-black text-slate-900">{item.crop}</span>
                            <Badge variant="outline" className="ml-2 text-[9px] font-bold uppercase text-slate-400 border-slate-200">{item.zone}</Badge>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-5 text-center">
                        {item.trend === 'up' && <Badge className="bg-green-100 text-green-700 hover:bg-green-100 border-none font-bold text-[10px] uppercase">{item.change}</Badge>}
                        {item.trend === 'down' && <Badge className="bg-red-100 text-red-700 hover:bg-red-100 border-none font-bold text-[10px] uppercase">{item.change}</Badge>}
                        {item.trend === 'stable' && <Badge className="bg-slate-100 text-slate-500 hover:bg-slate-100 border-none font-bold text-[10px] uppercase">Stable</Badge>}
                      </td>
                      <td className="px-6 py-5">
                        <span className="text-lg font-black text-slate-900">&#8358;{item.price.toLocaleString()}</span>
                      </td>
                      <td className="px-6 py-5">
                        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">{item.unit}</span>
                      </td>
                      <td className="px-6 py-5">
                        <div className="flex items-center gap-1 text-sm font-bold text-slate-600">
                          <MapPin className="h-3.5 w-3.5 text-slate-400" />
                          {item.location}, {item.state}
                        </div>
                      </td>
                      <td className="px-6 py-5 text-right">
                        <div className="flex items-center justify-end gap-2">
                          {item.verified ? (
                            <CheckCircle2 className="h-4 w-4 text-green-500" />
                          ) : (
                            <AlertTriangle className="h-4 w-4 text-amber-500" />
                          )}
                          <Button variant="ghost" size="sm" className="h-8 rounded-lg font-black text-green-600 hover:bg-white hover:text-green-700">
                            {t('details')}
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
        <div className="bg-slate-50 p-6 text-center border-t border-slate-100">
          <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">
            Prices aggregated from Nigerian Agricultural Market Information System (NAMIS)
          </p>
        </div>
      </Card>
    </div>
  );
}
