import { useState } from 'react';
import { motion } from 'framer-motion';
import type { FarmerRecord, Language } from '@/types/agro';
import { CROPS, NIGERIAN_STATES, SOIL_TYPES } from '@/data/nigeriaAgroData';
import { Sprout, Wheat, Users, MapPin, Calendar, Save, ChevronRight, CheckCircle2, AlertCircle } from 'lucide-react';

type IrrigationMode = 'rainfed' | 'irrigation' | 'mixed';

const TEMPLATES = [
  { state: 'Kano', lga: 'Kano Municipal', crop: 'Groundnut', secondary: 'Sorghum', soil: 'Sandy loam', hectares: 5, irrigation: 'rainfed' as IrrigationMode },
  { state: 'Benue', lga: 'Gboko', crop: 'Yam', secondary: 'Cassava', soil: 'Loamy', hectares: 3, irrigation: 'rainfed' as IrrigationMode },
  { state: 'Niger', lga: 'Bida', crop: 'Rice', secondary: 'Maize', soil: 'Clay', hectares: 8, irrigation: 'irrigation' as IrrigationMode },
  { state: 'Ogun', lga: 'Abeokuta', crop: 'Cassava', secondary: 'Plantain', soil: 'Lateritic', hectares: 4, irrigation: 'mixed' as IrrigationMode },
];

export function FarmerOnboarding({ language, onSubmit }: {
  language: Language;
  onSubmit: (record: FarmerRecord) => void;
}) {
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({
    nin: '', fullName: '', phone: '', state: '', lga: '', cooperative: '',
    farmSizeHectares: 0, soilType: '', irrigationMode: 'rainfed' as IrrigationMode,
    plantingDate: '', primaryCrop: '', secondaryCrop: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const t = {
    en: {
      title: 'Farmer Registration Portal',
      subtitle: 'Register your farm profile to receive AI-powered agro-advisory, weather forecasts, and market intelligence.',
      stepLabels: ['Personal Details', 'Farm Profile', 'Crop Selection'],
      next: 'Next Step',
      submit: 'Submit & Get AI Advisory',
      back: 'Back',
      template: 'Quick Templates',
      fields: {
        nin: 'National ID (NIN)', fullName: 'Full Name', phone: 'Phone Number',
        state: 'State', lga: 'LGA', cooperative: 'Cooperative Name (Optional)',
        hectares: 'Farm Size (Hectares)', soilType: 'Soil Type', irrigation: 'Irrigation Mode',
        plantingDate: 'Expected Planting Date', primaryCrop: 'Primary Crop', secondaryCrop: 'Secondary Crop (Optional)',
      },
      irrigations: ['Rainfed Only', 'Irrigation System', 'Mixed (Both)'],
      success: 'Registration Successful!',
      successMsg: 'Your farm has been registered. The AI Agro-Engine is analyzing your data for personalized advisory.',
    },
    ha: {
      title: 'Shafin Rajistar Manoma',
      subtitle: 'Ƙidaya bayanan fadarmu don samun shawarwarci na noma ta AI, hasashen yanayi, da kasida.',
      stepLabels: ['Bayanan Mutum', 'Tsarin Fara', 'Zabin Shuka'],
      next: 'Mataki Na Gaba',
      submit: 'Ƙaddamar & Samu Shawarar AI',
      back: 'Baya',
      template: 'Samfuran Saurari',
      fields: {
        nin: 'ID Ɗan Adam (NIN)', fullName: 'Sunai Gana', phone: 'Lambar Waya',
        state: 'Jiha', lga: 'LGA', cooperative: 'Sunan Haɗin Kai (Zaɓi)',
        hectares: 'Girman Fara (Hektara)', soilType: 'Irin Ƙasa', irrigation: 'Hanyar Ruwa',
        plantingDate: 'Kwanakin Shuka', primaryCrop: 'Shinkafta Na Farko', secondaryCrop: 'Shinkafta Na Biyu (Zaɓi)',
      },
      irrigations: ['Ruwan Sama Kawai', 'Tsarin Ruwa', 'Haɗin (Duka)'],
      success: 'An Daidaita!',
      successMsg: 'An ƙaddamar da faranka. Injiniyar AI tana binciken bayananka don shawarwarci.',
    },
  }[language];

  const handleTemplate = (tpl: typeof TEMPLATES[0]) => {
    setForm({
      ...form,
      state: tpl.state,
      lga: tpl.lga,
      primaryCrop: tpl.crop,
      secondaryCrop: tpl.secondary,
      soilType: tpl.soil,
      farmSizeHectares: tpl.hectares,
      irrigationMode: tpl.irrigation,
    });
  };

  const handleSubmit = () => {
    if (!form.nin || !form.fullName || !form.phone || !form.state || !form.primaryCrop) return;
    const record: FarmerRecord = {
      id: crypto.randomUUID(),
      ...form,
      createdAt: new Date().toISOString(),
      status: 'pending',
    };
    onSubmit(record);
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col items-center justify-center rounded-2xl border border-emerald-200 bg-emerald-50 p-12 text-center">
        <CheckCircle2 className="mb-4 h-16 w-16 text-emerald-600" />
        <h3 className="text-2xl font-bold text-emerald-900">{t.success}</h3>
        <p className="mt-2 max-w-md text-slate-600">{t.successMsg}</p>
        <button onClick={() => { setSubmitted(false); setStep(0); }} className="mt-6 rounded-lg bg-emerald-700 px-6 py-2.5 text-sm font-medium text-white hover:bg-emerald-800">
          {language === 'en' ? 'Register Another Farmer' : 'Ƙara Ɗayan Manoma'}
        </button>
      </motion.div>
    );
  }

  const inputClass = "w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500";
  const labelClass = "block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5";

  return (
    <div className="max-w-3xl mx-auto">
      {/* Progress */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-2">
          {t.stepLabels.map((label, i) => (
            <span key={i} className={`text-xs font-medium ${i <= step ? 'text-emerald-700' : 'text-slate-400'}`}>
              {i + 1}. {label}
            </span>
          ))}
        </div>
        <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
          <motion.div className="h-full bg-emerald-600 rounded-full" initial={{ width: 0 }} animate={{ width: `${((step + 1) / 3) * 100}%` }} transition={{ duration: 0.4 }} />
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-6 md:p-8 shadow-sm">
        <h2 className="text-xl font-bold text-slate-900 mb-1">{t.title}</h2>
        <p className="text-sm text-slate-500 mb-6">{t.subtitle}</p>

        {/* Quick Templates */}
        {step === 0 && (
          <div className="mb-6">
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-3">{t.template}</p>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {TEMPLATES.map((tpl, i) => (
                <button key={i} onClick={() => handleTemplate(tpl)} className="rounded-lg border border-slate-200 p-3 text-left text-xs hover:border-emerald-400 hover:bg-emerald-50 transition-colors">
                  <p className="font-semibold text-slate-800">{tpl.state}</p>
                  <p className="text-slate-500">{tpl.crop} · {tpl.hectares}ha</p>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Step 0: Personal */}
        {step === 0 && (
          <div className="space-y-4">
            <div><label className={labelClass}>{t.fields.nin}</label><input className={inputClass} value={form.nin} onChange={e => setForm({ ...form, nin: e.target.value })} placeholder="11-digit NIN" /></div>
            <div><label className={labelClass}>{t.fields.fullName}</label><input className={inputClass} value={form.fullName} onChange={e => setForm({ ...form, fullName: e.target.value })} placeholder="Full name" /></div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div><label className={labelClass}>{t.fields.phone}</label><input className={inputClass} value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="+234..." /></div>
              <div><label className={labelClass}>{t.fields.state}</label>
                <select className={inputClass} value={form.state} onChange={e => setForm({ ...form, state: e.target.value })}>
                  <option value="">Select State</option>
                  {NIGERIAN_STATES.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div><label className={labelClass}>{t.fields.lga}</label><input className={inputClass} value={form.lga} onChange={e => setForm({ ...form, lga: e.target.value })} placeholder="Local Government Area" /></div>
              <div><label className={labelClass}>{t.fields.cooperative}</label><input className={inputClass} value={form.cooperative} onChange={e => setForm({ ...form, cooperative: e.target.value })} placeholder="Optional" /></div>
            </div>
          </div>
        )}

        {/* Step 1: Farm */}
        {step === 1 && (
          <div className="space-y-4">
            <div><label className={labelClass}>{t.fields.hectares}</label><input type="number" min="0.1" step="0.1" className={inputClass} value={form.farmSizeHectares || ''} onChange={e => setForm({ ...form, farmSizeHectares: parseFloat(e.target.value) || 0 })} placeholder="e.g. 5" /></div>
            <div><label className={labelClass}>{t.fields.soilType}</label>
              <select className={inputClass} value={form.soilType} onChange={e => setForm({ ...form, soilType: e.target.value })}>
                <option value="">Select Soil Type</option>
                {SOIL_TYPES.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div><label className={labelClass}>{t.fields.irrigation}</label>
              <div className="grid grid-cols-3 gap-2">
                {t.irrigations.map((opt, i) => (
                  <button key={i} onClick={() => setForm({ ...form, irrigationMode: ['rainfed', 'irrigation', 'mixed'][i] as IrrigationMode })}
                    className={`rounded-lg border px-3 py-2.5 text-xs font-medium transition-all ${
                      form.irrigationMode === ['rainfed', 'irrigation', 'mixed'][i]
                        ? 'border-emerald-500 bg-emerald-50 text-emerald-800' : 'border-slate-200 text-slate-600 hover:border-slate-300'
                    }`}>{opt}</button>
                ))}
              </div>
            </div>
            <div><label className={labelClass}>{t.fields.plantingDate}</label><input type="date" className={inputClass} value={form.plantingDate} onChange={e => setForm({ ...form, plantingDate: e.target.value })} /></div>
          </div>
        )}

        {/* Step 2: Crops */}
        {step === 2 && (
          <div className="space-y-4">
            <div><label className={labelClass}>{t.fields.primaryCrop}</label>
              <select className={inputClass} value={form.primaryCrop} onChange={e => setForm({ ...form, primaryCrop: e.target.value })}>
                <option value="">Select Primary Crop</option>
                {CROPS.map(c => <option key={c.name} value={c.name}>{c.name} ({c.hausaName})</option>)}
              </select>
            </div>
            <div><label className={labelClass}>{t.fields.secondaryCrop}</label>
              <select className={inputClass} value={form.secondaryCrop || ''} onChange={e => setForm({ ...form, secondaryCrop: e.target.value || undefined })}>
                <option value="">None</option>
                {CROPS.filter(c => c.name !== form.primaryCrop).map(c => <option key={c.name} value={c.name}>{c.name} ({c.hausaName})</option>)}
              </select>
            </div>
          </div>
        )}

        {/* Navigation */}
        <div className="mt-8 flex items-center justify-between">
          {step > 0 ? (
            <button onClick={() => setStep(step - 1)} className="flex items-center gap-1 text-sm font-medium text-slate-500 hover:text-slate-700">
              <ChevronRight className="h-4 w-4 rotate-180" />{t.back}
            </button>
          ) : <div />}
          {step < 2 ? (
            <button onClick={() => setStep(step + 1)} className="flex items-center gap-1 rounded-lg bg-emerald-700 px-5 py-2.5 text-sm font-medium text-white hover:bg-emerald-800">
              {t.next}<ChevronRight className="h-4 w-4" />
            </button>
          ) : (
            <button onClick={handleSubmit} disabled={!form.nin || !form.fullName || !form.phone || !form.state || !form.primaryCrop}
              className="flex items-center gap-2 rounded-lg bg-emerald-700 px-5 py-2.5 text-sm font-medium text-white hover:bg-emerald-800 disabled:opacity-40 disabled:cursor-not-allowed">
              <Save className="h-4 w-4" />{t.submit}
            </button>
          )}
        </div>
        {!form.nin || !form.fullName || !form.phone || !form.state || !form.primaryCrop ? (
          <p className="mt-2 text-xs text-amber-600 flex items-center gap-1"><AlertCircle className="h-3 w-3" />{language === 'en' ? 'Please fill all required fields before submitting.' : 'Da fatan za a cika duk filayen da ake buƙata kafin ƙaddamar.'}</p>
        ) : null}
      </div>
    </div>
  );
}
