import React, { useState, createContext, useContext, type ReactNode } from 'react';
import { motion } from 'framer-motion';
import { useT } from '@/hooks/useT';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Leaf,
  ArrowRight,
  Users,
  Globe,
  Shield,
  Zap,
  Mail,
  Phone,
  MapPin,
  ChevronDown,
  X,
  ShieldCheck,
  Lock,
  Sparkles,
} from 'lucide-react';
import { NIGERIA_STATES_LGA } from '@/data/saiData';

/* ------------------------------------------------------------------ */
/*  Lightweight auth context (stub — real auth lives in AdminLogin)   */
/* ------------------------------------------------------------------ */

interface AuthContextType {
  loginFarmer: (_phone: string, _pass: string) => boolean;
  loginAdmin: (_email: string, _pass: string) => boolean;
  registerFarmer: (_data: Record<string, unknown>) => void;
}

const AuthCtx = createContext<AuthContextType | null>(null);

function useAuth(): AuthContextType {
  const ctx = useContext(AuthCtx);
  if (!ctx) throw new Error('useAuth must be used within <AuthProvider>');
  return ctx;
}

function AuthProvider({ children }: { children: ReactNode }) {
  const value: AuthContextType = {
    loginFarmer: () => true,
    loginAdmin: () => true,
    registerFarmer: () => {},
  };
  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>;
}

export function Website() {
  const { loginAdmin, registerFarmer } = useAuth();
  const t = useT();
  const [showLogin, setShowLogin] = useState(false);
  const [showRegister, setShowRegister] = useState(false);
  const [contactForm, setContactForm] = useState({ name: '', email: '', message: '' });

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('Thank you! Your inquiry has been received.');
    setContactForm({ name: '', email: '', message: '' });
  };

  return (
    <div className="space-y-0">
      <AuthProvider>
        <div className="space-y-0">
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-green-900 via-green-800 to-emerald-900 text-white py-20 md:py-32">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute right-10 top-10 h-64 w-64 rounded-full bg-green-400 blur-3xl" />
          <div className="absolute left-10 bottom-10 h-48 w-48 rounded-full bg-amber-400 blur-3xl" />
        </div>
        <div className="container relative mx-auto px-4 text-center">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <Badge className="mb-6 bg-green-500/20 text-green-200 border-green-400/30 font-bold px-4 py-2 text-sm">
              YABTECH SMART AGRO INSIGHT ENTERPRISE
            </Badge>
            <h1 className="mb-6 text-4xl font-black tracking-tight md:text-6xl lg:text-7xl leading-none">
              Empowering Nigerian<br /><span className="text-green-400">Farmers with Data</span>
            </h1>
            <p className="mx-auto mb-10 max-w-2xl text-lg text-green-100 leading-relaxed">
              Real-time weather, market prices, pest alerts, and AI-powered farming advice — all in your language.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button size="lg" className="h-14 rounded-2xl bg-green-500 px-8 text-lg font-bold hover:bg-green-400 shadow-xl shadow-green-500/30" onClick={() => setShowRegister(true)}>
                Get Started Free <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button size="lg" variant="outline" className="h-14 rounded-2xl border-white/20 bg-white/10 px-8 text-lg font-bold backdrop-blur-sm hover:bg-white/20" onClick={() => setShowLogin(true)}>
                Login
              </Button>
              <Button size="lg" variant="outline" className="h-14 rounded-2xl border-green-400/40 bg-green-500/15 px-8 text-lg font-bold backdrop-blur-sm hover:bg-green-500/25 shadow-xl shadow-green-900/20" onClick={() => setShowLogin(true)}>
                <ShieldCheck className="mr-2 h-5 w-5" /> Admin Portal
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats Bar */}
      <section className="bg-white border-b border-slate-100 py-8">
        <div className="container mx-auto grid grid-cols-2 md:grid-cols-4 gap-6 px-4">
          {[
            { label: 'Crops Covered', value: '32+', icon: Leaf },
            { label: 'Markets Tracked', value: '10+', icon: Globe },
            { label: 'States Active', value: '12', icon: MapPin },
            { label: 'Languages', value: 'EN / HA', icon: Users },
          ].map((s, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }} className="text-center">
              <s.icon className="mx-auto h-6 w-6 text-green-600 mb-2" />
              <p className="text-2xl font-black text-slate-900">{s.value}</p>
              <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">{s.label}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Solutions */}
      <section className="py-20 bg-slate-50">
        <div className="container mx-auto px-4">
          <h2 className="mb-12 text-center text-3xl font-black tracking-tight md:text-4xl">Our Solutions</h2>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {[
              { title: 'Weather Intelligence', desc: 'Live Open-Meteo API data for Sokoto and all Nigerian LGAs with farmer-specific advisories.', color: 'blue' },
              { title: 'Market Prices', desc: 'Real-time commodity prices from 10+ Northern Nigeria markets with trend analysis.', color: 'green' },
              { title: 'Pest & Disease Alerts', desc: 'Early warning system for Fall Armyworm, Tuta Absoluta, and more.', color: 'red' },
              { title: 'AI Agro Advisor', desc: 'Ask questions about any crop, pest, or practice — get instant localized answers.', color: 'amber' },
              { title: 'Multi-Farm Management', desc: 'Track planting dates, harvest expectations, and farm notes across multiple plots.', color: 'emerald' },
              { title: 'USSD & SMS Access', desc: `*384*724# for feature phones. Termii and Africa's Talking gateway integration.`, color: 'purple' },
            ].map((s, i) => (
              <Card key={i} className="border-none bg-white shadow-lg shadow-slate-200/50 hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <div className={`mb-4 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-${s.color}-50 text-${s.color}-600`}>
                    <Zap className="h-6 w-6" />
                  </div>
                  <h3 className="mb-2 text-lg font-black text-slate-900">{s.title}</h3>
                  <p className="text-sm text-slate-500 leading-relaxed">{s.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* For Farmers */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid gap-12 md:grid-cols-2 items-center">
            <div>
              <Badge className="mb-4 bg-green-100 text-green-700 font-bold px-3 py-1">For Farmers</Badge>
              <h2 className="mb-6 text-3xl font-black tracking-tight md:text-4xl">Everything You Need to Grow More</h2>
              <ul className="space-y-4">
                {['Register your farms and track progress', 'Get weather forecasts tailored to your LGA', 'Check market prices before selling', 'Report pests and get expert advice', 'Access everything via USSD on any phone'].map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <div className="mt-1 flex h-6 w-6 items-center justify-center rounded-full bg-green-100 text-green-600 flex-shrink-0">
                      <ChevronDown className="h-3 w-3 rotate-[-90deg]" />
                    </div>
                    <span className="text-sm font-medium text-slate-700">{item}</span>
                  </li>
                ))}
              </ul>
              <Button className="mt-8 h-12 rounded-xl bg-green-600 font-bold hover:bg-green-500" onClick={() => setShowRegister(true)}>
                Register as Farmer
              </Button>
            </div>
            <div className="rounded-3xl bg-gradient-to-br from-green-50 to-emerald-50 p-12 text-center">
              <Leaf className="mx-auto h-24 w-24 text-green-600 mb-4" />
              <p className="text-xl font-black text-green-900 mb-2">SAI Mobile App</p>
              <p className="text-sm text-green-700">Available on Android • USSD: *384*724#</p>
            </div>
          </div>
        </div>
      </section>

      {/* Partners */}
      <section className="py-20 bg-slate-50">
        <div className="container mx-auto px-4 text-center">
          <h2 className="mb-12 text-3xl font-black tracking-tight md:text-4xl">Trusted Partners</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {['Sokoto Farmers Coop', 'YABTECH Hub', 'Kano Grain Traders', 'Northern Inputs Ltd'].map((name, i) => (
              <Card key={i} className="border-none bg-white shadow-md p-6">
                <p className="text-sm font-black text-slate-700">{name}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 max-w-2xl">
          <h2 className="mb-8 text-center text-3xl font-black tracking-tight md:text-4xl">Contact Us</h2>
          <form onSubmit={handleContactSubmit} className="space-y-4">
            <Input placeholder="Your Name" value={contactForm.name} onChange={e => setContactForm(p => ({ ...p, name: e.target.value }))} required className="h-12 rounded-xl" />
            <Input type="email" placeholder="Email Address" value={contactForm.email} onChange={e => setContactForm(p => ({ ...p, email: e.target.value }))} className="h-12 rounded-xl" />
            <Textarea placeholder="Your Message" value={contactForm.message} onChange={e => setContactForm(p => ({ ...p, message: e.target.value }))} required className="min-h-[120px] rounded-xl" />
            <Button type="submit" className="w-full h-12 rounded-xl bg-green-600 font-bold hover:bg-green-500">
              <Mail className="mr-2 h-4 w-4" /> Send Inquiry
            </Button>
          </form>
          <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center text-sm text-slate-500">
            <span className="flex items-center gap-2"><MapPin className="h-4 w-4" /> Yabo, Sokoto State, Nigeria</span>
            <span className="flex items-center gap-2"><Phone className="h-4 w-4" /> +234 800 SAI NOMA</span>
            <span className="flex items-center gap-2"><Mail className="h-4 w-4" /> info@sai.yabtech.ng</span>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-12">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Leaf className="h-6 w-6 text-green-500" />
            <span className="text-lg font-black text-white">SAI by YABTECH</span>
          </div>
          <p className="text-sm mb-2">Smart Agro Insight Enterprise — Yabo, Sokoto, Nigeria</p>
          <p className="text-xs text-slate-500 mb-6">Founded by Yahaya Abubakar</p>
          <Button variant="outline" className="h-10 rounded-xl border-green-500/40 bg-green-500/10 px-6 text-sm font-bold text-green-400 hover:bg-green-500/20 hover:text-green-300" onClick={() => setShowLogin(true)}>
            <ShieldCheck className="mr-2 h-4 w-4" /> Admin Portal Login
          </Button>
        </div>
      </footer>

      {/* Login Modal */}
      {showLogin && <LoginModal onClose={() => setShowLogin(false)} />}
      {showRegister && <RegisterModal onClose={() => setShowRegister(false)} />}
        </div>
      </AuthProvider>
    </div>
  );
}

function LoginModal({ onClose }: { onClose: () => void }) {
  const { loginFarmer, loginAdmin } = useAuth();
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [isAdmin, setIsAdmin] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isAdmin) {
      if (!loginAdmin(phone, password)) return;
    } else {
      if (!loginFarmer(phone, password)) toast.error('Invalid credentials');
    }
    toast.success(isAdmin ? 'Welcome, Administrator' : 'Welcome back, Farmer');
    onClose();
  };

  const fillDemoAdmin = () => {
    setPhone('admin@sai.yabtech.ng');
    setPassword('yabtech2025');
    setIsAdmin(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="w-full max-w-md rounded-2xl bg-white p-8 shadow-2xl">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-black text-slate-900">{isAdmin ? 'Admin Login' : 'Farmer Login'}</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="h-6 w-6" />
          </button>
        </div>
        {!isAdmin ? (
          <button
            onClick={fillDemoAdmin}
            className="mb-4 flex w-full items-center justify-between rounded-xl border border-green-200 bg-green-50 px-4 py-3 text-left transition-all hover:border-green-400 hover:shadow-lg hover:shadow-green-100"
          >
            <div>
              <p className="flex items-center gap-1.5 text-sm font-black text-green-800">
                <Sparkles className="h-4 w-4" /> Demo Admin Access
              </p>
              <p className="text-xs text-green-600 mt-0.5">One-click demo login for administrators</p>
            </div>
            <ArrowRight className="h-4 w-4 text-green-600" />
          </button>
        ) : (
          <div className="mb-4 rounded-xl bg-slate-50 border border-slate-200 px-4 py-3">
            <p className="flex items-center gap-1.5 text-xs font-black text-slate-700">
              <Lock className="h-3.5 w-3.5 text-green-600" /> Demo Admin Credentials
            </p>
            <p className="text-xs text-slate-500 mt-1 font-mono">admin@sai.yabtech.ng / yabtech2025</p>
          </div>
        )}
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input placeholder={isAdmin ? 'Admin Email' : 'Phone Number'} value={phone} onChange={e => setPhone(e.target.value)} required className="h-12 rounded-xl" />
          <Input type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} required className="h-12 rounded-xl" />
          <label className="flex items-center gap-2 text-sm font-medium text-slate-600">
            <input type="checkbox" checked={isAdmin} onChange={e => setIsAdmin(e.target.checked)} className="rounded" />
            Admin access
          </label>
          <Button type="submit" className="w-full h-12 rounded-xl bg-green-600 font-bold hover:bg-green-500">
            {isAdmin ? 'Login to Admin Panel' : 'Login'}
          </Button>
        </form>
      </div>
    </div>
  );
}

function RegisterModal({ onClose }: { onClose: () => void }) {
  const { registerFarmer } = useAuth();
  const [form, setForm] = useState({
    fullName: '', phone: '', email: '', password: '', state: 'Sokoto', lga: 'Sokoto North', community: '', preferredLanguage: 'en' as 'en' | 'ha', mainCrops: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    registerFarmer({
      ...form,
      mainCrops: form.mainCrops.split(',').map(c => c.trim()).filter(Boolean),
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 overflow-y-auto">
      <div className="w-full max-w-lg rounded-2xl bg-white p-8 shadow-2xl my-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-black text-slate-900">Register as Farmer</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="h-6 w-6" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input placeholder="Full Name" value={form.fullName} onChange={e => setForm(p => ({ ...p, fullName: e.target.value }))} required className="h-12 rounded-xl" />
          <Input placeholder="Phone Number" value={form.phone} onChange={e => setForm(p => ({ ...p, phone: e.target.value }))} required className="h-12 rounded-xl" />
          <Input placeholder="Email (Optional)" value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))} className="h-12 rounded-xl" />
          <Input type="password" placeholder="Password" value={form.password} onChange={e => setForm(p => ({ ...p, password: e.target.value }))} required className="h-12 rounded-xl" />
          <select value={form.state} onChange={e => setForm(p => ({ ...p, state: e.target.value, lga: '' }))} className="h-12 w-full rounded-xl border border-slate-200 px-4 text-sm font-medium">
            {Object.keys(NIGERIA_STATES_LGA).map(s => <option key={s} value={s}>{s}</option>)}
          </select>
          <select value={form.lga} onChange={e => setForm(p => ({ ...p, lga: e.target.value }))} className="h-12 w-full rounded-xl border border-slate-200 px-4 text-sm font-medium">
            {(NIGERIA_STATES_LGA[form.state] || []).map(l => <option key={l} value={l}>{l}</option>)}
          </select>
          <Input placeholder="Community" value={form.community} onChange={e => setForm(p => ({ ...p, community: e.target.value }))} className="h-12 rounded-xl" />
          <select value={form.preferredLanguage} onChange={e => setForm(p => ({ ...p, preferredLanguage: e.target.value as 'en' | 'ha' }))} className="h-12 w-full rounded-xl border border-slate-200 px-4 text-sm font-medium">
            <option value="en">English</option>
            <option value="ha">Hausa</option>
          </select>
          <Input placeholder="Main Crops (comma-separated)" value={form.mainCrops} onChange={e => setForm(p => ({ ...p, mainCrops: e.target.value }))} className="h-12 rounded-xl" />
          <Button type="submit" className="w-full h-12 rounded-xl bg-green-600 font-bold hover:bg-green-500">Register</Button>
        </form>
      </div>
    </div>
  );
}