import React, { useState } from 'react';
import { 
  Phone, 
  MessageSquare, 
  Smartphone, 
  Wifi, 
  WifiOff, 
  Send, 
  ChevronRight,
  Delete
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';

const USSD_CODES = [
  { code: '*789#', label: 'SAI Agro Menu' },
  { code: '*789*1#', label: 'Check Market Prices' },
  { code: '*789*2#', label: 'Weather Forecast' },
  { code: '*789*3#', label: 'Pest Alerts' },
];

const MOCK_SMS = [
  { id: 1, from: 'SAI-AGRO', text: 'ALERT: Fall Armyworm detected in Oyo. Apply biopesticides now.', date: '10:30 AM' },
  { id: 2, from: 'SAI-AGRO', text: 'MARKET: Maize price in Kano up by 5% to N28,000/100kg.', date: 'Yesterday' },
  { id: 3, from: 'SAI-AGRO', text: 'WEATHER: Heavy rain expected in Benue. Delay harvest.', date: '2 days ago' },
];

export default function Connectivity() {
  const [ussdInput, setUssdInput] = useState('');
  const [ussdScreen, setUssdScreen] = useState<'idle' | 'menu' | 'loading'>('idle');
  const [activeTab, setActiveTab] = useState<'ussd' | 'sms'>('ussd');

  const handleKeyClick = (key: string) => {
    setUssdInput(prev => prev + key);
  };

  const handleBackspace = () => {
    setUssdInput(prev => prev.slice(0, -1));
  };

  const handleDial = () => {
    if (!ussdInput.includes('*') || !ussdInput.includes('#')) {
      toast.error('Invalid USSD format');
      return;
    }
    setUssdScreen('loading');
    setTimeout(() => {
      setUssdScreen('menu');
      toast.success('USSD Request Successful');
    }, 1500);
  };

  return (
    <div className="space-y-8 pb-8">
      <div className="px-2">
        <h2 className="text-3xl font-black text-slate-900 tracking-tight">Connectivity Hub</h2>
        <p className="text-slate-500 font-medium">Access SAI Agro services without data or internet</p>
      </div>

      <div className="flex gap-2 p-1 bg-slate-100 rounded-2xl w-fit mx-2">
        <Button 
          variant={activeTab === 'ussd' ? 'default' : 'ghost'} 
          onClick={() => setActiveTab('ussd')}
          className="rounded-xl font-bold"
        >
          <Phone className="h-4 w-4 mr-2" /> USSD Simulator
        </Button>
        <Button 
          variant={activeTab === 'sms' ? 'default' : 'ghost'} 
          onClick={() => setActiveTab('sms')}
          className="rounded-xl font-bold"
        >
          <MessageSquare className="h-4 w-4 mr-2" /> SMS Alerts
        </Button>
      </div>

      <div className="grid gap-8 lg:grid-cols-2">
        {activeTab === 'ussd' ? (
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
            <Card className="border-none shadow-2xl bg-slate-900 text-white overflow-hidden max-w-md mx-auto rounded-[3rem] p-6 border-8 border-slate-800">
              <div className="space-y-6">
                {/* Phone Notch/Status Bar */}
                <div className="flex justify-between items-center text-[10px] font-bold text-slate-500 px-4">
                  <span>9:41</span>
                  <div className="flex gap-1">
                    <Wifi className="h-3 w-3" />
                    <Smartphone className="h-3 w-3" />
                  </div>
                </div>

                {/* USSD Screen */}
                <div className="bg-slate-800 rounded-3xl aspect-[9/10] flex flex-col items-center justify-center p-8 text-center border border-slate-700 shadow-inner relative overflow-hidden">
                  <AnimatePresence mode="wait">
                    {ussdScreen === 'idle' && (
                      <motion.div key="idle" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                        <div className="text-2xl font-black mb-2 text-slate-300">Dial a code</div>
                        <div className="text-4xl font-black text-green-500 tracking-widest">{ussdInput || '...'}</div>
                      </motion.div>
                    )}

                    {ussdScreen === 'loading' && (
                      <motion.div key="loading" className="flex flex-col items-center">
                        <div className="h-12 w-12 border-4 border-green-500 border-t-transparent rounded-full animate-spin mb-4" />
                        <div className="text-sm font-bold text-slate-400">Requesting...</div>
                      </motion.div>
                    )}

                    {ussdScreen === 'menu' && (
                      <motion.div key="menu" className="w-full space-y-4">
                        <div className="text-xs font-black uppercase text-green-500 tracking-widest">SAI AGRO MENU</div>
                        <div className="text-left space-y-2">
                          <p className="text-sm font-medium">1. Weather Advisory</p>
                          <p className="text-sm font-medium">2. Market Intelligence</p>
                          <p className="text-sm font-medium">3. Pest & Disease Alert</p>
                          <p className="text-sm font-medium">4. My Farm Status</p>
                        </div>
                        <Button 
                          onClick={() => setUssdScreen('idle')} 
                          className="w-full bg-green-600 hover:bg-green-500 text-white font-black rounded-xl"
                        >
                          Exit
                        </Button>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Keypad */}
                <div className="grid grid-cols-3 gap-4 px-4 pb-4">
                  {['1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '0', '#'].map(key => (
                    <button 
                      key={key}
                      onClick={() => handleKeyClick(key)}
                      className="h-14 w-14 rounded-full bg-slate-800 flex items-center justify-center text-xl font-black hover:bg-slate-700 active:scale-95 transition-all mx-auto"
                    >
                      {key}
                    </button>
                  ))}
                  <button onClick={handleDial} className="h-14 w-14 rounded-full bg-green-600 flex items-center justify-center text-xl font-black hover:bg-green-500 active:scale-95 transition-all mx-auto col-start-2">
                    <Phone className="h-6 w-6 fill-white" />
                  </button>
                  <button onClick={handleBackspace} className="h-14 w-14 rounded-full bg-slate-800 flex items-center justify-center text-xl font-black hover:bg-slate-700 active:scale-95 transition-all mx-auto">
                    <Delete className="h-6 w-6" />
                  </button>
                </div>
              </div>
            </Card>
          </motion.div>
        ) : (
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
            <Card className="border-none shadow-xl bg-white rounded-3xl overflow-hidden h-full">
              <CardHeader className="bg-slate-50 border-b border-slate-100">
                <CardTitle className="text-xl font-black flex items-center gap-2">
                  <MessageSquare className="h-5 w-5 text-green-600" />
                  SMS Notifications
                </CardTitle>
                <CardDescription className="text-xs font-bold uppercase tracking-widest text-slate-400">Offline Alert History</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-[500px]">
                  <div className="p-4 space-y-4">
                    {MOCK_SMS.map(sms => (
                      <div key={sms.id} className="flex gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-100 relative group transition-all hover:shadow-md">
                        <div className="h-10 w-10 rounded-xl bg-green-100 text-green-700 flex items-center justify-center flex-shrink-0">
                          <Send className="h-5 w-5" />
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between items-start mb-1">
                            <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest">{sms.from}</span>
                            <span className="text-[10px] font-bold text-slate-400">{sms.date}</span>
                          </div>
                          <p className="text-sm font-medium text-slate-900 leading-relaxed">{sms.text}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
                <div className="p-4 bg-slate-50 border-t border-slate-100">
                  <div className="flex gap-2">
                    <Input placeholder="Compose message..." className="rounded-xl border-none bg-white font-medium" />
                    <Button size="icon" className="rounded-xl bg-green-600 hover:bg-green-500 shrink-0">
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        <div className="space-y-6">
          <Card className="border-none shadow-xl bg-gradient-to-br from-green-900 to-green-800 text-white p-8 rounded-3xl">
            <h3 className="text-2xl font-black mb-4">Why Offline Access?</h3>
            <p className="text-slate-200 font-medium leading-relaxed mb-6">
              Over 60% of smallholder farmers in Nigeria operate in regions with poor internet connectivity. SAI Agro Hub ensures critical advisory is always available.
            </p>
            <div className="space-y-4">
              <div className="flex items-center gap-4 p-4 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/10">
                <div className="h-10 w-10 rounded-xl bg-green-500/20 text-green-400 flex items-center justify-center">
                  <WifiOff className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-sm font-black">PWA Technology</p>
                  <p className="text-xs text-slate-300">Install and use the app fully offline.</p>
                </div>
              </div>
              <div className="flex items-center gap-4 p-4 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/10">
                <div className="h-10 w-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                  <Phone className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-sm font-black">USSD Services</p>
                  <p className="text-xs text-slate-300">Dial *789# for instant audio/text advice.</p>
                </div>
              </div>
            </div>
          </Card>

          <Card className="border-none shadow-xl bg-white p-8 rounded-3xl">
            <h3 className="text-xl font-black text-slate-900 mb-6 tracking-tight">Quick USSD Codes</h3>
            <div className="space-y-3">
              {USSD_CODES.map(item => (
                <div key={item.code} className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 border border-slate-100 group hover:border-green-200 transition-all cursor-pointer" onClick={() => setUssdInput(item.code)}>
                  <div>
                    <p className="text-sm font-black text-slate-900">{item.code}</p>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">{item.label}</p>
                  </div>
                  <ChevronRight className="h-4 w-4 text-slate-300 group-hover:text-green-500 group-hover:translate-x-1 transition-all" />
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
