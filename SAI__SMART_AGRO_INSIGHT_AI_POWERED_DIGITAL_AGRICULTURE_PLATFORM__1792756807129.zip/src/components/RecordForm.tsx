import React from 'react';
import { Plus, XCircle, Pen, Save } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { motion } from 'framer-motion';
import type { FarmerRecord } from '@/lib/share';
import { CROP_OPTIONS } from '@/lib/share';

const STATUS_OPTIONS: FarmerRecord['status'][] = ['Active', 'Harvested', 'Pending'];

export interface FormData {
  farmer_name: string;
  location: string;
  crop: string;
  farm_size: string;
  planting_date: string;
  expected_harvest: string;
  yield_estimate: string;
  phone: string;
  status: FarmerRecord['status'];
}

export function emptyForm(): FormData {
  return {
    farmer_name: '',
    location: '',
    crop: '',
    farm_size: '',
    planting_date: '',
    expected_harvest: '',
    yield_estimate: '',
    phone: '',
    status: 'Active',
  };
}

interface RecordFormProps {
  isAdding: boolean;
  editingId: string | null;
  formData: FormData;
  onSubmit: (e: React.FormEvent) => void;
  onChange: (data: FormData) => void;
  onCancel: () => void;
}

export default function RecordForm({
  isAdding,
  editingId,
  formData,
  onSubmit,
  onChange,
  onCancel,
}: RecordFormProps) {
  if (!isAdding) return null;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="lg:col-span-1"
    >
      <Card className="border-none shadow-2xl shadow-slate-200/60 sticky top-8">
        <CardHeader>
          <CardTitle className="text-xl font-black tracking-tight flex items-center gap-2">
            {editingId ? (
              <>
                <Pen className="h-5 w-5 text-green-600" /> Edit Record
              </>
            ) : (
              <>
                <Plus className="h-5 w-5 text-green-600" /> New Farmer
              </>
            )}
          </CardTitle>
          <CardDescription className="text-xs font-bold uppercase tracking-widest">
            {editingId ? 'Update farmer details' : 'Register a new farmer'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <Label className="text-xs font-black uppercase text-slate-400 tracking-widest">
                Farmer Name *
              </Label>
              <Input
                placeholder="Full name"
                className="h-11 rounded-xl bg-slate-50 border-none font-medium"
                value={formData.farmer_name}
                onChange={(e) => onChange({ ...formData, farmer_name: e.target.value })}
                required
              />
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs font-black uppercase text-slate-400 tracking-widest">
                Location
              </Label>
              <Input
                placeholder="Village, LGA, State"
                className="h-11 rounded-xl bg-slate-50 border-none font-medium"
                value={formData.location}
                onChange={(e) => onChange({ ...formData, location: e.target.value })}
              />
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs font-black uppercase text-slate-400 tracking-widest">
                Crop Type *
              </Label>
              <Select
                onValueChange={(v) => onChange({ ...formData, crop: v })}
                value={formData.crop}
              >
                <SelectTrigger className="h-11 rounded-xl bg-slate-50 border-none font-medium">
                  <SelectValue placeholder="Select a crop" />
                </SelectTrigger>
                <SelectContent className="rounded-xl">
                  {CROP_OPTIONS.map((type) => (
                    <SelectItem key={type} value={type} className="rounded-lg">
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs font-black uppercase text-slate-400 tracking-widest">
                  Farm Size
                </Label>
                <Input
                  type="text"
                  placeholder="e.g. 2.5 Ha"
                  className="h-11 rounded-xl bg-slate-50 border-none font-medium"
                  value={formData.farm_size}
                  onChange={(e) => onChange({ ...formData, farm_size: e.target.value })}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-black uppercase text-slate-400 tracking-widest">
                  Yield Estimate
                </Label>
                <Input
                  type="text"
                  placeholder="e.g. 500 kg"
                  className="h-11 rounded-xl bg-slate-50 border-none font-medium"
                  value={formData.yield_estimate}
                  onChange={(e) => onChange({ ...formData, yield_estimate: e.target.value })}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs font-black uppercase text-slate-400 tracking-widest">
                  Planting Date *
                </Label>
                <Input
                  type="date"
                  className="h-11 rounded-xl bg-slate-50 border-none font-medium"
                  value={formData.planting_date}
                  onChange={(e) => onChange({ ...formData, planting_date: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-black uppercase text-slate-400 tracking-widest">
                  Expected Harvest
                </Label>
                <Input
                  type="date"
                  className="h-11 rounded-xl bg-slate-50 border-none font-medium"
                  value={formData.expected_harvest}
                  onChange={(e) => onChange({ ...formData, expected_harvest: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs font-black uppercase text-slate-400 tracking-widest">
                Phone Number
              </Label>
              <Input
                type="tel"
                placeholder="+234 800 000 0000"
                className="h-11 rounded-xl bg-slate-50 border-none font-medium"
                value={formData.phone}
                onChange={(e) => onChange({ ...formData, phone: e.target.value })}
              />
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs font-black uppercase text-slate-400 tracking-widest">
                Status
              </Label>
              <Select
                onValueChange={(v) =>
                  onChange({ ...formData, status: v as FarmerRecord['status'] })
                }
                value={formData.status}
              >
                <SelectTrigger className="h-11 rounded-xl bg-slate-50 border-none font-medium">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent className="rounded-xl">
                  {STATUS_OPTIONS.map((s) => (
                    <SelectItem key={s} value={s} className="rounded-lg">
                      {s}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex gap-2 pt-4">
              <Button
                type="submit"
                className="flex-1 h-12 rounded-xl bg-green-600 font-black text-white shadow-lg shadow-green-600/20"
              >
                <Save className="h-4 w-4 mr-2" />
                {editingId ? 'Update' : 'Save'}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={onCancel}
                className="h-12 rounded-xl border-slate-200 font-bold"
              >
                <XCircle className="h-4 w-4 mr-2" />
                Cancel
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
}