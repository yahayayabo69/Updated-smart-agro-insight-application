import { useState } from 'react';
import { X, Share2, Download, QrCode, Smartphone, Link2, CheckCircle2, MessageSquare, Twitter, Facebook, Send } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';

interface ShareDownloadModalProps {
  open: boolean;
  onClose: () => void;
}

export function ShareDownloadModal({ open, onClose }: ShareDownloadModalProps) {
  const [copied, setCopied] = useState(false);
  const url = window.location.origin;
  const title = 'SAI Smart Agro Insight';
  const text = 'Check out SAI Smart Agro Insight - Digital advisory for Nigerian farmers!';

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      toast.success('Link copied to clipboard!');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error('Could not copy link');
    }
  };

  const handleNativeShare = async () => {
    try {
      await navigator.share({ title, text, url });
      toast.success('Shared successfully!');
      onClose();
    } catch {
      // User cancelled or share not available
    }
  };

  const socialLinks = [
    { name: 'WhatsApp', icon: MessageSquare, color: 'bg-green-500 hover:bg-green-600', href: `https://wa.me/?text=${encodeURIComponent(text + ' ' + url)}` },
    { name: 'Twitter / X', icon: Twitter, color: 'bg-slate-800 hover:bg-slate-900', href: `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}` },
    { name: 'Facebook', icon: Facebook, color: 'bg-blue-600 hover:bg-blue-700', href: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}` },
    { name: 'SMS', icon: Send, color: 'bg-blue-500 hover:bg-blue-600', href: `sms:?body=${encodeURIComponent(text + ' ' + url)}` },
  ];

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl font-black text-slate-900">
            <Share2 className="h-5 w-5 text-green-600" />
            Share & Install SAI
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          {/* Install / Download Section */}
          <section>
            <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wider mb-3">Install the App</h3>
            <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 space-y-3">
              <p className="text-xs text-slate-500 leading-relaxed">
                Install SAI Smart Agro Insight on your device for offline access and instant notifications.
              </p>
              <Button
                onClick={() => {
                  const ev = (window as any).__beforeinstallprompt;
                  if (ev) {
                    ev.prompt();
                    ev.userChoice.then((result: any) => {
                      if (result.outcome === 'accepted') toast.success('App installed!');
                    });
                  } else {
                    toast.info('Use your browser menu to install this app.');
                  }
                }}
                className="w-full rounded-xl bg-green-600 text-sm font-bold hover:bg-green-700 shadow-lg shadow-green-200"
              >
                <Download className="h-4 w-4 mr-2" /> Install App
              </Button>

              {/* Browser-specific instructions */}
              <div className="space-y-2 pt-1">
                <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">How to install:</p>
                <InstallInstruction
                  browser="Chrome / Edge (Android & Desktop)"
                  steps={['Tap the ⋮ menu (top right)', 'Select "Install App" or "Add to Home Screen"', 'Confirm to install']}
                />
                <InstallInstruction
                  browser="Safari (iOS / iPhone)"
                  steps={['Tap the Share button (square with arrow)', 'Scroll down and tap "Add to Home Screen"', 'Tap "Add" to confirm']}
                />
              </div>
            </div>
          </section>

          {/* QR Code Section */}
          <section>
            <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wider mb-3">Scan to Open</h3>
            <div className="rounded-xl border border-slate-200 bg-white p-4 flex flex-col items-center">
              <div className="bg-white p-3 rounded-xl border-2 border-dashed border-green-200">
                <QrCode className="h-24 w-24 text-green-600" />
              </div>
              <p className="mt-2 text-[11px] font-semibold text-slate-400 text-center">
                Scan with your phone camera to open SAI
              </p>
              <a
                href={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(url)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-2 text-xs font-bold text-green-600 hover:text-green-700 underline"
              >
                Download QR Code
              </a>
            </div>
          </section>

          {/* Native Share */}
          <section>
            <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wider mb-3">Quick Share</h3>
            <Button
              onClick={handleNativeShare}
              variant="outline"
              className="w-full rounded-xl border-green-300 bg-green-50 text-green-700 font-bold hover:bg-green-100"
            >
              <Share2 className="h-4 w-4 mr-2" /> Share via Native Share
            </Button>
          </section>

          {/* Copy Link */}
          <section>
            <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wider mb-3">Copy Link</h3>
            <div className="flex gap-2">
              <div className="flex-1 flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm text-slate-500">
                <Link2 className="h-4 w-4 shrink-0" />
                <span className="truncate">{url}</span>
              </div>
              <Button
                onClick={handleCopy}
                className={`rounded-xl font-bold transition-all ${
                  copied
                    ? 'bg-green-600 text-white'
                    : 'bg-slate-800 text-white hover:bg-slate-900'
                }`}
              >
                {copied ? <CheckCircle2 className="h-4 w-4" /> : <Link2 className="h-4 w-4" />}
              </Button>
            </div>
          </section>

          {/* Social Channels */}
          <section>
            <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wider mb-3">Social Channels</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {socialLinks.map((s) => (
                <a
                  key={s.name}
                  href={s.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`${s.color} flex flex-col items-center justify-center gap-1.5 rounded-xl py-3 text-white transition-all active:scale-[0.98]`}
                >
                  <s.icon className="h-5 w-5" />
                  <span className="text-[10px] font-bold">{s.name}</span>
                </a>
              ))}
            </div>
          </section>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function InstallInstruction({ browser, steps }: { browser: string; steps: string[] }) {
  return (
    <div>
      <p className="text-[11px] font-bold text-slate-600 mb-1">{browser}</p>
      <ol className="space-y-0.5">
        {steps.map((step, i) => (
          <li key={i} className="flex items-start gap-1.5 text-[11px] text-slate-500">
            <span className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-green-100 text-[9px] font-black text-green-700">
              {i + 1}
            </span>
            {step}
          </li>
        ))}
      </ol>
    </div>
  );
}
