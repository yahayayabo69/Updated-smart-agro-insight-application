import React, { useState, useEffect } from 'react';
import {
  Plus,
  Trash2,
  ClipboardList,
  Calendar as CalendarIcon,
  MapPin,
  Leaf,
  CheckCircle2,
  CloudOff,
  Download,
  Pen,
  Search,
  Filter,
  Users,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { motion } from 'framer-motion';
import { useLocalStorage } from '@/hooks/use-local-storage';
import type { FarmerRecord } from '@/lib/share';
import { STORAGE_KEY, exportToCSV } from '@/lib/share';
import RecordForm, { emptyForm, type FormData } from '@/components/RecordForm';

function generateId() {
  return `farm-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

export default function Records() {
  const [records, setRecords] = useLocalStorage<FarmerRecord[]>(STORAGE_KEY, []);
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<FarmerRecord['status'] | 'All'>('All');
  const [formData, setFormData] = useState<FormData>(emptyForm());

  useEffect(() => {
    if (!isAdding && !editingId) {
      setFormData(emptyForm());
    }
  }, [isAdding, editingId]);

  const filteredRecords = records
    .filter((r) => {
      if (statusFilter !== 'All' && r.status !== statusFilter) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        return (
          r.farmer_name.toLowerCase().includes(q) ||
          r.crop.toLowerCase().includes(q) ||
          r.location.toLowerCase().includes(q) ||
          r.phone.includes(q)
        );
      }
      return true;
    })
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.farmer_name || !formData.crop || !formData.planting_date) {
      toast.error('Please fill in Farmer Name, Crop, and Planting Date.');
      return;
    }

    if (editingId) {
      setRecords(records.map((r) => (r.id === editingId ? { ...r, ...formData, id: editingId } : r)));
      toast.success('Record updated successfully');
      setEditingId(null);
    } else {
      const newRecord: FarmerRecord = {
        ...formData,
        id: generateId(),
        created_at: new Date().toISOString(),
      };
      setRecords([newRecord, ...records]);
      toast.success('Record saved successfully');
    }

    setFormData(emptyForm());
    setIsAdding(false);
  };

  const handleEdit = (record: FarmerRecord) => {
    setFormData({
      farmer_name: record.farmer_name,
      location: record.location,
      crop: record.crop,
      farm_size: record.farm_size,
      planting_date: record.planting_date,
      expected_harvest: record.expected_harvest,
      yield_estimate: record.yield_estimate,
      phone: record.phone,
      status: record.status,
    });
    setEditingId(record.id);
    setIsAdding(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = (id: string) => {
    setRecords(records.filter((r) => r.id !== id));
    toast.success('Record deleted');
  };

  const handleCancel = () => {
    setFormData(emptyForm());
    setIsAdding(false);
    setEditingId(null);
  };

  const stats = {
    total: records.length,
    active: records.filter((r) => r.status === 'Active').length,
    harvested: records.filter((r) => r.status === 'Harvested').length,
    pending: records.filter((r) => r.status === 'Pending').length,
  };

  return (
    <div className="space-y-8 pb-8">
      {/* Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between px-2">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">Farmer Records</h2>
          <p className="text-slate-500 font-medium">Track and manage your registered farmers</p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={() => {
              if (editingId) handleCancel();
              setIsAdding(!isAdding);
            }}
            className="rounded-xl bg-green-600 font-bold h-11 px-6 shadow-lg shadow-green-600/20"
          >
            {isAdding ? (
              <><ClipboardList className="h-4 w-4 mr-2" /> Close</>
            ) : (
              <><Plus className="h-4 w-4 mr-2" /> Add Farmer</>
            )}
          </Button>
          <Button
            onClick={() => exportToCSV(records)}
            variant="outline"
            className="rounded-xl font-bold h-11 px-6 border-slate-200"
          >
            <Download className="h-4 w-4 mr-2" /> Export CSV
          </Button>
        </div>
      </div>

      {/* Stats Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 px-2">
        {[
          { label: 'Total', value: stats.total, color: 'bg-green-100 text-green-700' },
          { label: 'Active', value: stats.active, color: 'bg-blue-100 text-blue-700' },
          { label: 'Harvested', value: stats.harvested, color: 'bg-amber-100 text-amber-700' },
          { label: 'Pending', value: stats.pending, color: 'bg-slate-100 text-slate-700' },
        ].map((stat) => (
          <div
            key={stat.label}
            className="rounded-2xl bg-white p-4 shadow-md shadow-slate-200/50 border border-slate-100"
          >
            <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-1">{stat.label}</p>
            <p className={cn('text-2xl font-black', stat.color)}>{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Search & Filter */}
      <div className="flex flex-col sm:flex-row gap-3 px-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <Input
            placeholder="Search farmers, crops, or location..."
            className="h-11 rounded-xl bg-white border-slate-200 pl-10 font-medium"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Select
          value={statusFilter}
          onValueChange={(v) => setStatusFilter(v as FarmerRecord['status'] | 'All')}
        >
          <SelectTrigger className="h-11 w-full sm:w-44 rounded-xl bg-white border-slate-200 font-medium">
            <Filter className="h-4 w-4 mr-2 text-slate-400" />
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent className="rounded-xl">
            <SelectItem value="All" className="rounded-lg">All Statuses</SelectItem>
            {(['Active', 'Harvested', 'Pending'] as FarmerRecord['status'][]).map((s) => (
              <SelectItem key={s} value={s} className="rounded-lg">{s}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid gap-8 lg:grid-cols-3">
        {/* Form Section */}
        <RecordForm
          isAdding={isAdding}
          editingId={editingId}
          formData={formData}
          onSubmit={handleSubmit}
          onChange={setFormData}
          onCancel={handleCancel}
        />

        {/* Records List */}
        <div className={cn('space-y-6', isAdding ? 'lg:col-span-2' : 'lg:col-span-3')}>
          {!navigator.onLine && (
            <div className="flex items-center gap-3 rounded-2xl bg-amber-50 p-4 border border-amber-200">
              <CloudOff className="h-6 w-6 text-amber-600" />
              <div>
                <h4 className="font-bold text-amber-900">Offline Mode</h4>
                <p className="text-xs text-amber-700">Records are saved locally on this device and will persist.</p>
              </div>
            </div>
          )}

          {filteredRecords.length === 0 ? (
            <div className="flex flex-col items-center justify-center rounded-3xl bg-white p-20 shadow-xl shadow-slate-200/50 text-center">
              <div className="mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-slate-50 text-slate-300">
                <Users className="h-10 w-10" />
              </div>
              <h3 className="text-xl font-black text-slate-900 mb-2">
                {searchQuery || statusFilter !== 'All' ? 'No matching records' : 'No farmers registered yet'}
              </h3>
              <p className="text-sm text-slate-500 max-w-xs mx-auto mb-8">
                {searchQuery || statusFilter !== 'All'
                  ? 'Try adjusting your search or filter.'
                  : 'Start by adding a farmer to begin tracking their farming activities.'}
              </p>
              <Button onClick={() => setIsAdding(true)} variant="outline" className="rounded-xl font-bold border-slate-200">
                <Plus className="h-4 w-4 mr-2" /> Add Your First Farmer
              </Button>
            </div>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2">
              {filteredRecords.map((record) => (
                <motion.div
                  key={record.id}
                  layout
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  <Card className="group overflow-hidden border-none bg-white shadow-xl shadow-slate-200/50 hover:shadow-2xl transition-all">
                    <div className="flex h-full flex-col">
                      {/* Card Header */}
                      <div className="flex items-center justify-between bg-slate-50/50 p-6 border-b border-slate-50">
                        <div className="flex items-center gap-3">
                          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-green-100 text-green-700 font-black shadow-sm">
                            {record.farmer_name.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <h3 className="font-black text-slate-900 tracking-tight">{record.farmer_name}</h3>
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1">
                              <MapPin className="h-3 w-3" /> {record.location || 'No location set'}
                            </p>
                          </div>
                        </div>
                        <div className="flex gap-1">
                          <Button
                            variant="ghost" size="sm"
                            onClick={() => handleEdit(record)}
                            className="h-8 w-8 rounded-lg text-slate-300 hover:bg-blue-50 hover:text-blue-600 p-0"
                          >
                            <Pen className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost" size="sm"
                            onClick={() => handleDelete(record.id)}
                            className="h-8 w-8 rounded-lg text-slate-300 hover:bg-red-50 hover:text-red-600 p-0"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>

                      <CardContent className="flex-1 p-6 space-y-4">
                        <div className="flex items-center justify-between">
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-100 font-bold text-xs">
                            <Leaf className="h-3 w-3 mr-1" /> {record.crop}
                          </Badge>
                          <Badge
                            className={cn(
                              'text-[10px] font-bold uppercase tracking-wider border-none',
                              record.status === 'Active' && 'bg-blue-100 text-blue-700',
                              record.status === 'Harvested' && 'bg-amber-100 text-amber-700',
                              record.status === 'Pending' && 'bg-slate-100 text-slate-700',
                            )}
                          >
                            {record.status}
                          </Badge>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-1">
                            <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Farm Size</p>
                            <p className="text-sm font-bold text-slate-900">{record.farm_size || 'N/A'}</p>
                          </div>
                          <div className="space-y-1">
                            <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Yield Est.</p>
                            <p className="text-sm font-bold text-slate-900">{record.yield_estimate || 'N/A'}</p>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-1">
                            <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest flex items-center gap-1">
                              <CalendarIcon className="h-3 w-3" /> Planted
                            </p>
                            <p className="text-sm font-bold text-slate-900">
                              {record.planting_date ? new Date(record.planting_date).toLocaleDateString() : 'N/A'}
                            </p>
                          </div>
                          <div className="space-y-1">
                            <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest flex items-center gap-1">
                              <CalendarIcon className="h-3 w-3" /> Harvest
                            </p>
                            <p className="text-sm font-bold text-slate-900">
                              {record.expected_harvest ? new Date(record.expected_harvest).toLocaleDateString() : 'N/A'}
                            </p>
                          </div>
                        </div>

                        {record.phone && (
                          <div className="rounded-2xl bg-slate-50 p-3 border border-slate-100">
                            <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-1">Contact</p>
                            <p className="text-sm font-bold text-slate-900">{record.phone}</p>
                          </div>
                        )}

                        <div className="flex items-center gap-2 text-[10px] font-bold text-slate-400">
                          <CheckCircle2 className="h-3 w-3 text-green-500" />
                          Registered {new Date(record.created_at).toLocaleDateString()}
                        </div>
                      </CardContent>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}