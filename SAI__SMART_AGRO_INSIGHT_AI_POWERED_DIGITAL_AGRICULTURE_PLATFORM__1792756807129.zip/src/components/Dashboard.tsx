import React, { useState, useEffect } from 'react';
import { 
  Cloud, 
  TrendingUp, 
  Bell, 
  ArrowUpRight, 
  MapPin, 
  Zap,
  CheckCircle2, 
  Share2, 
  Users,
  Download,
  ShieldCheck
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MOCK_WEATHER, MOCK_MARKET_PRICES, MOCK_PEST_ALERTS } from '@/lib/mock-data';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { handleShare } from '@/lib/share';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

export default function Dashboard() {
  const [recentFarmers, setRecentFarmers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState(false);
  
  const topAlert = MOCK_PEST_ALERTS[0];
  const topMarket = MOCK_MARKET_PRICES[2]; // Yam is doing well
  
  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);
  
  const handleInstall = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      toast.success('App installed successfully!');
    }
    setDeferredPrompt(null);
    setIsInstallable(false);
  };
  
  useEffect(() => {
    const fetchRecentFarmers = async () => {
      const { data, error } = await supabase
        .from('farm_records')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(5);
      
      if (!error && data) {
        setRecentFarmers(data);
      }
      setLoading(false);
    };
    
    fetchRecentFarmers();
  }, []);
  
  return (
    <div className="space-y-8 pb-8">
      {/* Hero / Advisory Banner */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-3xl bg-green-900 p-8 text-white shadow-2xl lg:p-12"
      >
        <div className="absolute right-0 top-0 h-full w-full opacity-30 pointer-events-none lg:w-1/2">
          <img 
            src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/c3334ad1-aa6c-4426-a799-f909ae46d2b5/hero-image---sai-smart-agro-insight-6051d7d9-1782685660096.webp" 
            alt="Farmer with phone"
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-green-900 via-green-900/80 to-transparent"></div>
        </div>
        
        <div className="relative z-10 max-w-2xl">
          <Badge className="mb-4 bg-green-500/20 text-green-300 border-green-500/30 font-bold px-3 py-1">
            AI Farm Advisory • Active
          </Badge>
          <h1 className="mb-4 text-4xl font-black tracking-tight lg:text-6xl">
            Empowering Your Farm with <span className="text-green-400 italic underline decoration-amber-400">Data</span>
          </h1>
          <p className="mb-8 text-lg text-slate-200 leading-relaxed font-medium">
            Real-time insights on weather, markets, and crop health tailored for your region in Nigeria.
          </p>
          <div className="flex flex-wrap gap-4">
            <Link to="/records">
              <Button size="lg" className="h-14 rounded-2xl bg-green-500 px-8 text-lg font-bold hover:bg-green-400 shadow-lg shadow-green-500/20">
                Update Farm Logs
              </Button>
            </Link>
            <Button 
              onClick={handleShare}
              size="lg" 
              variant="outline" 
              className="h-14 rounded-2xl border-white/20 bg-white/10 px-8 text-lg font-bold backdrop-blur-sm hover:bg-white/20"
            >
              <Share2 className="mr-2 h-5 w-5" /> Share App
            </Button>
            {isInstallable && (
              <Button 
                onClick={handleInstall}
                size="lg" 
                className="h-14 rounded-2xl bg-amber-500 px-8 text-lg font-bold hover:bg-amber-400 shadow-lg shadow-amber-500/20"
              >
                <Download className="mr-2 h-5 w-5" /> Install App
              </Button>
            )}
          </div>
        </div>
      </motion.div>
      
      {/* Quick Stats Grid */}
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {/* Weather Quick Look */}
        <Card className="overflow-hidden border-none bg-white shadow-xl shadow-slate-200/50 hover:shadow-2xl transition-shadow group">
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-bold text-slate-500 uppercase tracking-widest">Local Weather</CardTitle>
            <div className="rounded-xl bg-blue-50 p-2 text-blue-600 transition-colors group-hover:bg-blue-600 group-hover:text-white">
              <Cloud className="h-5 w-5" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex items-end gap-2 mb-2">
              <span className="text-4xl font-black text-slate-900">{MOCK_WEATHER.temp}°C</span>
              <span className="text-lg font-bold text-slate-500 mb-1">{MOCK_WEATHER.condition}</span>
            </div>
            <div className="flex items-center gap-1 text-xs font-bold text-slate-400 mb-4">
              <MapPin className="h-3 w-3" />
              {MOCK_WEATHER.location}
            </div>
            <div className="rounded-xl bg-slate-50 p-3 border border-slate-100">
              <p className="text-xs font-medium italic text-slate-600 leading-relaxed">
                "{MOCK_WEATHER.advice}"
              </p>
            </div>
          </CardContent>
        </Card>
        
        {/* Market Quick Look */}
        <Card className="overflow-hidden border-none bg-white shadow-xl shadow-slate-200/50 hover:shadow-2xl transition-shadow group">
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-bold text-slate-500 uppercase tracking-widest">Market Trend</CardTitle>
            <div className="rounded-xl bg-amber-50 p-2 text-amber-600 transition-colors group-hover:bg-amber-600 group-hover:text-white">
              <TrendingUp className="h-5 w-5" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex items-end gap-2 mb-2">
              <span className="text-4xl font-black text-slate-900">₦{topMarket.price.toLocaleString()}</span>
              <span className="text-lg font-bold text-green-600 mb-1 flex items-center">
                <ArrowUpRight className="h-4 w-4 mr-0.5" />
                {topMarket.change}
              </span>
            </div>
            <div className="text-xs font-bold text-slate-400 mb-4 uppercase tracking-wider">
              {topMarket.crop} • {topMarket.location} Market
            </div>
            <Link to="/market" className="text-xs font-black text-green-600 hover:text-green-700 flex items-center gap-1">
              View All Prices <ArrowUpRight className="h-3 w-3" />
            </Link>
          </CardContent>
        </Card>
        
        {/* Alerts Quick Look */}
        <Card className="overflow-hidden border-none bg-white shadow-xl shadow-slate-200/50 hover:shadow-2xl transition-shadow group">
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-bold text-slate-500 uppercase tracking-widest">Active Alert</CardTitle>
            <div className="rounded-xl bg-red-50 p-2 text-red-600 transition-colors group-hover:bg-red-600 group-hover:text-white">
              <Bell className="h-5 w-5" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-1 mb-2">
              <Badge variant="destructive" className="w-fit text-[10px] font-black uppercase mb-1">High Severity</Badge>
              <span className="text-xl font-black text-slate-900 line-clamp-1">{topAlert.title}</span>
            </div>
            <p className="text-xs font-medium text-slate-500 mb-4 line-clamp-2 leading-relaxed">
              {topAlert.description}
            </p>
            <Link to="/alerts" className="text-xs font-black text-red-600 hover:text-red-700 flex items-center gap-1">
              Take Action <ArrowUpRight className="h-3 w-3" />
            </Link>
          </CardContent>
        </Card>
      </div>
      
      {/* Main Content Sections */}
      <div className="grid gap-8 lg:grid-cols-3">
        {/* Left Column: Recent Activity & Farmer Tracking */}
        <div className="lg:col-span-2 space-y-8">
          <div className="space-y-6">
            <div className="flex items-center justify-between px-2">
              <h2 className="text-2xl font-black text-slate-900 tracking-tight">Recent Insights</h2>
              <Button variant="ghost" className="text-sm font-bold text-green-600">See History</Button>
            </div>
            
            <div className="grid gap-4">
              {[1, 2].map((i) => (
                <Card key={i} className="border-none bg-white p-6 shadow-md shadow-slate-100">
                  <div className="flex gap-4">
                    <div className="h-20 w-20 overflow-hidden rounded-2xl bg-slate-100 flex-shrink-0">
                      <img 
                        src={i === 1 
                          ? "https://storage.googleapis.com/dala-prod-public-storage/generated-images/c3334ad1-aa6c-4426-a799-f909ae46d2b5/crop-health-illustration-6e9d8f42-1782685660227.webp"
                          : "https://storage.googleapis.com/dala-prod-public-storage/generated-images/c3334ad1-aa6c-4426-a799-f909ae46d2b5/market-intelligence-illustration-1517edd1-1782685662830.webp"
                        } 
                        alt="Thumbnail" 
                        className="h-full w-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-[10px] font-black uppercase text-green-600 tracking-widest">
                          {i === 1 ? 'Crop Management' : 'Market Watch'}
                        </span>
                        <span className="text-[10px] font-bold text-slate-400">Oct 25, 2023</span>
                      </div>
                      <h3 className="font-black text-slate-900 mb-1">
                        {i === 1 ? 'Optimizing Nitrogen for Late-Season Maize' : 'Yam Prices Surge in Benue Markets'}
                      </h3>
                      <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                        {i === 1 
                          ? 'Farmers in Oyo state are advised to adjust fertilizer application schedules based on upcoming rain patterns predicted for next week.'
                          : 'Wholesale prices for New Yam have increased by 15% due to high demand and transport logistics shifts in the South-East region.'
                        }
                      </p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
          
          {/* Farmers Details Column (as requested) */}
          <div className="space-y-4">
            <div className="flex items-center justify-between px-2">
              <h2 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
                <Users className="h-6 w-6 text-green-600" />
                Farmer Tracking
              </h2>
              <Link to="/records">
                <Button variant="ghost" className="text-sm font-bold text-green-600">Manage Records</Button>
              </Link>
            </div>
            
            <Card className="border-none bg-white shadow-xl shadow-slate-200/50 overflow-hidden">
              <Table>
                <TableHeader className="bg-slate-50">
                  <TableRow>
                    <TableHead className="text-[10px] font-black uppercase tracking-widest">Farmer Name</TableHead>
                    <TableHead className="text-[10px] font-black uppercase tracking-widest">Crop</TableHead>
                    <TableHead className="text-[10px] font-black uppercase tracking-widest">Area</TableHead>
                    <TableHead className="text-[10px] font-black uppercase tracking-widest">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center py-8 text-slate-400 font-medium">
                        Loading tracking data...
                      </TableCell>
                    </TableRow>
                  ) : recentFarmers.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center py-8 text-slate-400 font-medium">
                        No farmer records found. Start by adding one in Records.
                      </TableCell>
                    </TableRow>
                  ) : (
                    recentFarmers.map((farmer) => (
                      <TableRow key={farmer.id}>
                        <TableCell className="font-bold text-slate-900">{farmer.farmer_name}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-100">
                            {farmer.crop}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-slate-600 font-medium">{farmer.area} Ha</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1.5">
                            <div className="h-1.5 w-1.5 rounded-full bg-green-500 animate-pulse"></div>
                            <span className="text-[10px] font-bold text-slate-500 uppercase">Active</span>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </Card>
          </div>
        </div>
        
        {/* Right Column: Mini Tools/Advice */}
        <div className="space-y-6">
          <h2 className="text-2xl font-black text-slate-900 tracking-tight px-2">Smart Tools</h2>
          
          <Card className="border-none bg-gradient-to-br from-slate-900 to-slate-800 p-6 text-white shadow-2xl">
            <div className="mb-6 flex h-12 w-12 items-center justify-center rounded-2xl bg-green-500/20 text-green-400">
              <Zap className="h-6 w-6" />
            </div>
            <h3 className="text-xl font-black mb-2 leading-tight">Harvest Timer</h3>
            <p className="text-xs text-slate-400 mb-6 leading-relaxed">
              Predict the optimal harvest date based on your planting logs and localized climate trends.
            </p>
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-300">Maize (White)</span>
                <span className="font-black text-green-400">12 Days Left</span>
              </div>
              <div className="h-2 w-full rounded-full bg-slate-700 overflow-hidden">
                <div className="h-full w-[85%] bg-green-500 rounded-full shadow-[0_0_10px_rgba(34,197,94,0.5)]"></div>
              </div>
            </div>
            <Button className="mt-8 w-full rounded-xl bg-white text-slate-900 font-black hover:bg-slate-100">
              Setup Alerts
            </Button>
          </Card>
          
          <Card className="border-none bg-white p-6 shadow-xl shadow-slate-200/50">
            <h3 className="font-black text-slate-900 mb-4 flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-green-600" />
              Sustainability Tip
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed mb-4">
              Implementing crop rotation with legumes (like Beans) can naturally fix nitrogen in your soil, reducing fertilizer costs by up to 20%.
            </p>
            <div className="flex items-center gap-2">
              <div className="flex -space-x-2">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="h-6 w-6 rounded-full border-2 border-white bg-slate-200"></div>
                ))}
              </div>
              <span className="text-[10px] font-bold text-slate-400">2.4k Farmers using this tip</span>
            </div>
          </Card>
        </div>
      </div>
      
      {/* Footer / Attribution */}
      <div className="pt-12 pb-8 text-center border-t border-slate-100">
        <p className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-1">SAI Smart Agro Insight</p>
        <p className="text-xs text-slate-500 font-medium italic max-w-md mx-auto leading-relaxed">
          Empowering the next generation of Nigerian farmers. <br />
          Founded by <span className="text-slate-900 font-bold">Yahaya Abubakar</span> — A young data analyst, software developer, researcher, and innovator.
        </p>
      </div>
    </div>
  );
}
