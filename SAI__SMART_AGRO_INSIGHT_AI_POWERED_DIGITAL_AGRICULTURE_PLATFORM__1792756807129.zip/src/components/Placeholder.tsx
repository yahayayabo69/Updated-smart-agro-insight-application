import React from 'react';
export default function Placeholder({ title }: { title: string }) {
  return (
    <div className="space-y-4">
      <h2 className="text-3xl font-bold tracking-tight">{title}</h2>
      <p className="text-slate-500">Coming soon...</p>
    </div>
  );
}
