import React, { useState, useRef } from 'react';
import {
  Camera,
  ImagePlus,
  Video,
  Send,
  Loader2,
  Sparkles,
  MessageCircleQuestion,
  Languages,
  X,
} from 'lucide-react';
import { useI18n } from '@/lib/i18n';
import { askAgroAI, uploadFarmMedia } from '@/lib/ai-agro-api';
import type { AiMediaItem } from '@/types/sai';

const MAX_VIDEO_MB = 30;

const SAMPLE_QUESTIONS = [
  "Why are my maize leaves turning yellow?",
  "How do I control fall armyworm organically?",
  "What fertilizer should I use for tomatoes?",
  "When is the best time to plant this season?",
];

interface ChatMessage {
  role: 'user' | 'ai';
  text: string;
  media?: AiMediaItem[];
}

const AiAssistantInner = () => {
  const { lang, t } = useI18n();
  const [question, setQuestion] = useState('');
  const [media, setMedia] = useState<AiMediaItem[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const [langHausa, setLangHausa] = useState(lang === 'ha');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const activeLang = langHausa ? 'ha' : 'en';

  const handleFiles = async (files: FileList | null, kind: 'image' | 'video') => {
    if (!files || files.length === 0) return;
    const file = files[0];
    if (kind === 'video' && file.size > MAX_VIDEO_MB * 1024 * 1024) {
      alert(t('fileTooLarge'));
      return;
    }
    try {
      const uploaded = await uploadFarmMedia(file);
      setMedia((prev) => [...prev, { ...uploaded, type: kind }]);
    } catch (err: any) {
      alert(err.message || t('askError'));
    }
  };

  const handleSubmit = async (preset?: string) => {
    const q = (preset ?? question).trim();
    if (!q && media.length === 0) return;
    setMessages((prev) => [...prev, { role: 'user', text: q, media: media.length ? [...media] : undefined }]);
    setQuestion('');
    setLoading(true);
    try {
      const { response } = await askAgroAI({ question: q, language: activeLang, media });
      setMessages((prev) => [...prev, { role: 'ai', text: response }]);
    } catch {
      setMessages((prev) => [...prev, { role: 'ai', text: t('askError') }]);
    } finally {
      setMedia([]);
      setLoading(false);
      setTimeout(() => chatEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
    }
  };

  const removeMedia = (index: number) => {
    setMedia((prev) => prev.filter((_, i) => i !== index));
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 via-white to-white">
      <div className="mx-auto w-full max-w-3xl px-4 py-8 sm:px-6">
        {/* Header */}
        <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="flex items-center gap-2 text-2xl font-black text-slate-900">
              <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-green-600 text-white shadow-lg shadow-green-200">
                <Sparkles className="h-5 w-5" />
              </span>
              {t('askSaiTitle')}
            </h1>
            <p className="mt-1 text-sm text-slate-600">{t('askSaiSub')}</p>
          </div>
          <button
            onClick={() => setLangHausa((v) => !v)}
            className="inline-flex items-center gap-2 self-start rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-700 shadow-sm transition-all hover:border-green-300 hover:text-green-700"
          >
            <Languages className="h-4 w-4" />
            {langHausa ? 'English' : 'Hausa'}
          </button>
        </div>

        {/* Chat transcript */}
        <div className="mb-4 max-h-[420px] space-y-4 overflow-y-auto rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
          {messages.length === 0 && (
            <div className="flex flex-col items-center py-10 text-center">
              <MessageCircleQuestion className="mb-3 h-12 w-12 text-green-500" />
              <p className="text-sm font-medium text-slate-500">{t('askSaiSub')}</p>
              <p className="mt-1 text-xs text-slate-400">{t('mediaHint')}</p>
            </div>
          )}

          {messages.map((msg, i) => (
            <div
              key={i}
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed shadow-sm ${
                  msg.role === 'user'
                    ? 'rounded-br-md bg-green-600 text-white'
                    : 'rounded-bl-md border border-slate-100 bg-slate-50 text-slate-800'
                }`}
              >
                {msg.media && msg.media.length > 0 && (
                  <div className="mb-2 flex flex-wrap gap-2">
                    {msg.media.map((m, j) =>
                      m.type === 'video' ? (
                        <video
                          key={j}
                          src={m.url}
                          controls
                          className="h-24 w-32 rounded-lg border border-white/30 object-cover"
                        />
                      ) : (
                        <img
                          key={j}
                          src={m.url}
                          alt={m.name}
                          className="h-24 w-32 rounded-lg border border-white/30 object-cover"
                        />
                      )
                    )}
                  </div>
                )}
                {msg.text}
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex justify-start">
              <div className="flex items-center gap-2 rounded-2xl rounded-bl-md border border-slate-100 bg-slate-50 px-4 py-3 text-sm text-slate-500">
                <Loader2 className="h-4 w-4 animate-spin text-green-600" />
                {t('aiThinking')}
              </div>
            </div>
          )}
          <div ref={chatEndRef} />
        </div>

        {/* Media attachments preview */}
        {media.length > 0 && (
          <div className="mb-4 flex flex-wrap gap-3 rounded-2xl border border-green-200 bg-green-50/60 p-3">
            {media.map((m, i) => (
              <div key={i} className="relative">
                {m.type === 'video' ? (
                  <video src={m.url} className="h-20 w-28 rounded-xl border border-green-200 object-cover" />
                ) : (
                  <img src={m.url} alt={m.name} className="h-20 w-28 rounded-xl border border-green-200 object-cover" />
                )}
                <button
                  onClick={() => removeMedia(i)}
                  className="absolute -right-2 -top-2 flex h-6 w-6 items-center justify-center rounded-full bg-red-500 text-white shadow hover:bg-red-600"
                  aria-label={t('removeMedia')}
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Sample questions */}
        {messages.length === 0 && (
          <div className="mb-4">
            <p className="mb-2 text-[11px] font-bold uppercase tracking-widest text-slate-400">
              {t('sampleQuestions')}
            </p>
            <div className="flex flex-wrap gap-2">
              {SAMPLE_QUESTIONS.map((sq) => (
                <button
                  key={sq}
                  onClick={() => handleSubmit(sq)}
                  className="rounded-full border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-600 shadow-sm transition-all hover:border-green-400 hover:text-green-700"
                >
                  {sq}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Media action buttons */}
        <div className="mb-3 flex flex-wrap gap-2">
          <button
            onClick={() => cameraInputRef.current?.click()}
            className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-700 shadow-sm transition-all hover:border-green-400 hover:text-green-700"
          >
            <Camera className="h-4 w-4" /> {t('takePhoto')}
          </button>
          <button
            onClick={() => fileInputRef.current?.click()}
            className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-700 shadow-sm transition-all hover:border-green-400 hover:text-green-700"
          >
            <ImagePlus className="h-4 w-4" /> {t('uploadPhoto')}
          </button>
          <button
            onClick={() => videoInputRef.current?.click()}
            className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-700 shadow-sm transition-all hover:border-green-400 hover:text-green-700"
          >
            <Video className="h-4 w-4" /> {t('uploadVideo')}
          </button>
        </div>

        <input
          ref={cameraInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          className="hidden"
          onChange={(e) => handleFiles(e.target.files, 'image')}
        />
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => handleFiles(e.target.files, 'image')}
        />
        <input
          ref={videoInputRef}
          type="file"
          accept="video/*"
          className="hidden"
          onChange={(e) => handleFiles(e.target.files, 'video')}
        />

        {/* Ask input */}
        <div className="flex items-end gap-2 rounded-2xl border border-slate-200 bg-white p-2 shadow-lg shadow-slate-200/50 focus-within:border-green-400 focus-within:ring-2 focus-within:ring-green-100">
          <textarea
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSubmit();
              }
            }}
            placeholder={t('askPlaceholder')}
            rows={2}
            className="max-h-32 flex-1 resize-none bg-transparent px-3 py-2 text-sm text-slate-800 placeholder:text-slate-400 focus:outline-none"
          />
          <button
            onClick={() => handleSubmit()}
            disabled={loading || (!question.trim() && media.length === 0)}
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-green-600 text-white shadow-md shadow-green-200 transition-all hover:bg-green-700 disabled:cursor-not-allowed disabled:opacity-40"
            aria-label={t('askButton')}
          >
            {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Send className="h-5 w-5" />}
          </button>
        </div>
        <p className="mt-2 text-center text-[11px] text-slate-400">{t('mediaHint')}</p>
      </div>
    </div>
  );
};

export default AiAssistantInner;