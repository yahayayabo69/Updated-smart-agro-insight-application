import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import {
  MessageCircleQuestion,
  LayoutDashboard, 
  Cloud, 
  TrendingUp, 
  ClipboardList, 
  Bell,
  Leaf,
  Share2,
  Smartphone,
  ShieldCheck,
  Handshake,
  Languages,
  Download
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { handleShare } from '@/lib/share';
import { useI18n } from '@/lib/i18n';
import { ShareDownloadModal } from './ShareDownloadModal';

const navItems = [
  { name: 'dashboard', path: '/', icon: LayoutDashboard },
  { name: 'weather', path: '/weather', icon: Cloud },
  { name: 'market', path: '/market', icon: TrendingUp },
  { name: 'records', path: '/records', icon: ClipboardList },
  { name: 'alerts', path: '/alerts', icon: Bell },
  { name: 'partnerships', path: '/partnerships', icon: Handshake },
  { name: 'mobile', path: '/mobile', icon: Smartphone },
  { name: 'askAi', path: '/ask-sai', icon: MessageCircleQuestion },
];

export function Navigation() {
  const { lang, setLang, t } = useI18n();
  const [shareOpen, setShareOpen] = useState(false);
  
  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="fixed left-0 top-0 hidden h-screen w-64 flex-col border-r bg-white p-4 shadow-sm md:flex">
        <div className="mb-8 flex items-center gap-2 px-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-green-600 text-white shadow-lg">
            <Leaf className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">SAI</h1>
            <p className="text-[10px] font-medium text-slate-500 uppercase tracking-widest leading-none">Smart Agro</p>
          </div>
        </div>
        
        <nav className="flex-1 space-y-1">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                cn(
                  "flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold transition-all duration-200",
                  isActive 
                    ? "bg-green-50 text-green-700 shadow-[inset_0_0_0_1px_rgba(22,163,74,0.1)]" 
                    : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                )
              }
            >
              <item.icon className="h-5 w-5" />
              {t(item.name)}
            </NavLink>
          ))}
        </nav>

        {/* Language Toggle */}
        <div className="mb-4 mt-auto rounded-2xl bg-slate-900 p-4 text-white">
          <div className="flex items-center gap-2 mb-3">
            <Languages className="h-4 w-4 text-green-400" />
            <span className="text-xs font-bold text-green-400 uppercase tracking-wider">Language</span>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setLang('en')}
              className={cn(
                "flex-1 rounded-lg py-1.5 text-xs font-bold transition-all",
                lang === 'en' ? "bg-green-600 text-white" : "bg-white/10 text-slate-300 hover:bg-white/20"
              )}
            >
              English
            </button>
            <button
              onClick={() => setLang('ha')}
              className={cn(
                "flex-1 rounded-lg py-1.5 text-xs font-bold transition-all",
                lang === 'ha' ? "bg-green-600 text-white" : "bg-white/10 text-slate-300 hover:bg-white/20"
              )}
            >
              Hausa
            </button>
          </div>
        </div>
        
        <div className="rounded-2xl bg-slate-900 p-4 text-white">
          <p className="text-xs font-bold text-green-400 uppercase tracking-wider mb-1">Premium Advice</p>
          <p className="text-xs text-slate-300 leading-relaxed mb-3">Upgrade for localized USSD/SMS alerts.</p>
          <button className="w-full rounded-lg bg-green-600 py-2 text-xs font-bold transition-hover hover:bg-green-500">
            Learn More
          </button>
          <button 
            onClick={() => setShareOpen(true)}
            className="mt-2 flex w-full items-center justify-center gap-2 rounded-lg border border-white/20 bg-white/5 py-2 text-xs font-bold transition-hover hover:bg-white/10"
          >
            <Share2 className="h-3 w-3" /> Share & Install
          </button>
        </div>
        
        <div className="mt-6 space-y-2 px-2">
          <NavLink
            to="/admin/login"
            className="flex items-center justify-center gap-2 rounded-xl border border-green-200 bg-green-50 px-3 py-2 text-xs font-bold text-green-700 transition-all hover:bg-green-100"
          >
            <ShieldCheck className="h-4 w-4" /> Admin Control Panel
          </NavLink>
          <p className="text-center text-[10px] font-bold text-slate-400 uppercase tracking-widest">Founded by</p>
          <p className="text-center text-xs font-black text-slate-900 mt-1">Yahaya Abubakar</p>
        </div>
      </aside>

      {/* Mobile Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 z-50 flex w-full border-t bg-white/80 backdrop-blur-md px-2 py-2 md:hidden">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              cn(
                "flex flex-1 flex-col items-center justify-center gap-1 py-1 transition-all duration-200",
                isActive ? "text-green-600" : "text-slate-500"
              )
            }
          >
            <item.icon className="h-5 w-5" />
            <span className="text-[10px] font-bold">{t(item.name)}</span>
          </NavLink>
        ))}
        <button 
          onClick={() => setShareOpen(true)}
          className="flex flex-1 flex-col items-center justify-center gap-1 py-1 text-slate-500"
        >
          <Download className="h-5 w-5" />
          <span className="text-[10px] font-bold">Install</span>
        </button>
        <NavLink
          to="/admin/login"
          className="flex flex-1 flex-col items-center justify-center gap-1 py-1 text-slate-500 transition-all duration-200"
          title="Admin panel"
        >
          <ShieldCheck className="h-5 w-5" />
          <span className="text-[10px] font-bold">Admin</span>
        </NavLink>
      </nav>

      <ShareDownloadModal open={shareOpen} onClose={() => setShareOpen(false)} />
    </>
  );
}