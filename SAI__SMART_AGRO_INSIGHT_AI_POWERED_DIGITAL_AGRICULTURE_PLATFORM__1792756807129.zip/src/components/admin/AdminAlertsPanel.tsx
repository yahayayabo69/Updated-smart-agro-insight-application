import React, { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { Bell, Plus, Trash2, Send, Loader2, CheckCircle2, AlertTriangle, XCircle, Inbox } from 'lucide-react';
import { fetchAlerts, insertAlert, deleteAlert, EMPTY_ALERT, type AdminAlert } from './admin-api';

const SEVERITIES = ['info', 'warning', 'critical'];
const ALERT_TYPES = ['broadcast', 'weather', 'pest', 'announcement'];

const inputCls =
  'w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-green-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-green-100';

export default function AdminAlertsPanel() {
  const [alerts, setAlerts] = useState<AdminAlert[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState<AdminAlert>({ ...EMPTY_ALERT });
  const [showForm, setShowForm] = useState(false);
  const [publishing, setPublishing] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      setAlerts(await fetchAlerts());
    } catch (error: any) {
      toast.error(error.message || 'Failed to load alerts');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const publish = async () => {
    if (!form.message.trim()) {
      toast.error('Alert message is required');
      return;
    }
    setPublishing(true);
    try {
      await insertAlert({ title: form.title, message: form.message, type: form.type, severity: form.severity, location: form.location });
      toast.success('Alert published to farmers');
      setForm({ ...EMPTY_ALERT });
      setShowForm(false);
      await load();
    } catch (error: any) {
      toast.error(error.message || 'Failed to publish alert');
    } finally {
      setPublishing(false);
    }
  };

  const remove = async (a: AdminAlert) => {
    if (!window.confirm('Delete this alert?')) return;
    try {
      await deleteAlert(a.id);
      toast.success('Alert deleted');
      await load();
    } catch (error: any) {
      toast.error(error.message || 'Failed to delete alert');
    }
  };

  return (
    <section className="h-full rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="flex items-center gap-2 text-base font-bold text-slate-900">
          <Bell className="h-5 w-5 text-amber-500" /> System Alerts
        </h3>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-1.5 rounded-xl bg-green-600 px-3.5 py-2 text-xs font-bold text-white shadow-sm transition-all hover:bg-green-700 active:scale-[0.98]"
        >
          <Plus className="h-4 w-4" /> New Alert
        </button>
      </div>

      {showForm && (
        <div className="mb-4 space-y-3 rounded-xl border border-green-200 bg-green-50/60 p-4">
          <div>
            <label className="mb-1 block text-xs font-bold text-slate-600">Title (optional)</label>
            <input
              className={inputCls}
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              placeholder="e.g. Rainfall expected in Sokoto"
            />
          </div>
          <div>
            <label className="mb-1 block text-xs font-bold text-slate-600">Message</label>
            <textarea
              className={inputCls}
              rows={2}
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
              placeholder="Message for farmers..."
            />
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-600">Type</label>
              <select className={inputCls} value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
                {ALERT_TYPES.map((t) => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-600">Severity</label>
              <select className={inputCls} value={form.severity} onChange={(e) => setForm({ ...form, severity: e.target.value })}>
                {SEVERITIES.map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-600">Location</label>
              <input className={inputCls} value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="State / LGA" />
            </div>
          </div>
          <div className="flex gap-2">
            <button
              onClick={publish}
              disabled={publishing}
              className="flex items-center gap-1.5 rounded-xl bg-green-600 px-4 py-2 text-xs font-bold text-white transition-all hover:bg-green-700 active:scale-[0.98] disabled:opacity-60"
            >
              {publishing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
              Publish
            </button>
            <button onClick={() => setShowForm(false)} className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-50">
              Cancel
            </button>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-10">
          <Loader2 className="h-6 w-6 animate-spin text-green-600" />
        </div>
      ) : alerts.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-10 text-center">
          <Inbox className="mb-2 h-9 w-9 text-slate-300" />
          <p className="text-sm font-medium text-slate-500">No alerts yet</p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {alerts.map((a) => {
            const icon =
              a.severity === 'critical' ? (
                <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-500" />
              ) : a.severity === 'warning' ? (
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-500" />
              ) : (
                <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-blue-500" />
              );
            const tone =
              a.severity === 'critical'
                ? 'border-red-200 bg-red-50'
                : a.severity === 'warning'
                ? 'border-amber-200 bg-amber-50'
                : 'border-blue-200 bg-blue-50';
            return (
              <div key={a.id} className={`flex items-start gap-2 rounded-xl border p-3 ${tone}`}>
                {icon}
                <div className="flex-1">
                  {a.title && <p className="text-sm font-bold text-slate-900">{a.title}</p>}
                  <p className="text-sm font-medium text-slate-700">{a.message}</p>
                  <p className="mt-0.5 text-[11px] text-slate-500">
                    {new Date(a.created_at).toLocaleString()} · {a.type} · {a.severity}
                    {a.location ? ` · ${a.location}` : ''}
                  </p>
                </div>
                <button onClick={() => remove(a)} className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600">
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}