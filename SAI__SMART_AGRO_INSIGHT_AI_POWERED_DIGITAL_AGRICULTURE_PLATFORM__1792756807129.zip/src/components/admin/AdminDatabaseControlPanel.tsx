import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { toast } from 'sonner';
import { Database, Table2, Search, Plus, Pencil, Trash2, X, Save, Loader2, Inbox, FileJson, FileSpreadsheet, ChevronLeft, ChevronRight } from 'lucide-react';
import {
  fetchUserAccounts, upsertUserAccount, deleteUserAccount,
  fetchPlatformSettings, fetchConsultationsAdmin, fetchAuditLogs, fetchAdmins,
  fetchTableRows, insertRow, updateRow, deleteRow, logAudit, exportCSV,
} from './admin-api';

const TABLES = [
  { key: 'user_accounts', label: 'User Accounts', desc: 'Farmers, buyers & ops users' },
  { key: 'platform_settings', label: 'Platform Settings', desc: 'Global platform config' },
  { key: 'ai_consultations', label: 'AI Consultations', desc: 'Farmer questions & media' },
  { key: 'audit_logs', label: 'Audit Logs', desc: 'Admin activity trail' },
  { key: 'admins', label: 'Admins', desc: 'Authorized admin accounts' },
  { key: 'farm_records', label: 'Farm Records', desc: 'Farmer field records' },
  { key: 'market_prices', label: 'Market Prices', desc: 'Live crop pricing' },
  { key: 'alerts', label: 'Alerts', desc: 'Weather & broadcast alerts' },
  { key: 'partnerships', label: 'Partnerships', desc: 'Partner organizations' },
] as const;

type TableKey = (typeof TABLES)[number]['key'];

export const DB_TABLES = TABLES;

const inputCls = 'w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-green-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-green-100';

const fmt = (v: unknown): string => {
  if (v === null || v === undefined) return '—';
  return typeof v === 'object' ? JSON.stringify(v) : String(v);
};

export default function AdminDatabaseControlPanel({ actorName = 'admin' }: { actorName?: string }) {
  const [table, setTable] = useState<TableKey>('user_accounts');
  const [rows, setRows] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(0);
  const [editing, setEditing] = useState<Record<string, unknown> | null>(null);
  const [editKey, setEditKey] = useState('');
  const [showCreate, setShowCreate] = useState(false);
  const [newRow, setNewRow] = useState<Record<string, unknown>>({});
  const [newKeys, setNewKeys] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);
  const PAGE_SIZE = 12;

  const load = useCallback(async () => {
    setLoading(true);
    try {
      let data: Record<string, unknown>[] = [];
      if (table === 'user_accounts') data = (await fetchUserAccounts(search, 500)) as unknown as Record<string, unknown>[];
      else if (table === 'platform_settings') data = [(await fetchPlatformSettings()) as unknown as Record<string, unknown>];
      else if (table === 'ai_consultations') data = (await fetchConsultationsAdmin(500)) as unknown as Record<string, unknown>[];
      else if (table === 'audit_logs') data = (await fetchAuditLogs(500)) as unknown as Record<string, unknown>[];
      else if (table === 'admins') data = (await fetchAdmins()) as unknown as Record<string, unknown>[];
      else {
        data = await fetchTableRows(table, 500);
        const q = search.trim().toLowerCase();
        if (q) data = data.filter((r) => Object.values(r).some((v) => v !== null && v !== undefined && String(v).toLowerCase().includes(q)));
      }
      setRows(data);
      setPage(0);
    } catch (error: any) {
      toast.error(error.message || 'Failed to load table data');
    } finally {
      setLoading(false);
    }
  }, [table, search]);

  useEffect(() => { load(); }, [load]);

  const columns = useMemo(() => {
    const colSet = new Set<string>();
    rows.forEach((r) => Object.keys(r).forEach((k) => colSet.add(k)));
    return Array.from(colSet);
  }, [rows]);

  const paged = useMemo(() => rows.slice(page * PAGE_SIZE, page * PAGE_SIZE + PAGE_SIZE), [rows, page]);
  const totalPages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));

  const audit = (action: string, detail: string) => logAudit(actorName || 'admin', action, detail);

  const saveEdit = async () => {
    if (!editing || !editing.id) return;
    setSaving(true);
    try {
      const payload = { ...editing };
      delete payload.id; delete payload.created_at; delete payload.updated_at;
      await updateRow(table, String(editing.id), payload);
      await audit('update', `${table} row ${String(editing.id)} updated`);
      toast.success('Row updated');
      setEditing(null); setEditKey('');
      await load();
    } catch (error: any) {
      toast.error(error.message || 'Failed to update row');
    } finally { setSaving(false); }
  };

  const createRow = async () => {
    setSaving(true);
    try {
      const payload = { ...newRow };
      if (table === 'platform_settings') payload.id = 1;
      await insertRow(table, payload);
      await audit('insert', `new row created in ${table}`);
      toast.success('Row created');
      setShowCreate(false); setNewRow({}); setNewKeys([]);
      await load();
    } catch (error: any) {
      toast.error(error.message || 'Failed to create row');
    } finally { setSaving(false); }
  };

  const removeRow = async (row: Record<string, unknown>) => {
    if (!row.id) return;
    if (!window.confirm(`Delete this row from ${table}? This cannot be undone.`)) return;
    try {
      await deleteRow(table, String(row.id));
      await audit('delete', `${table} row ${String(row.id)} deleted`);
      toast.success('Row deleted');
      await load();
    } catch (error: any) {
      toast.error(error.message || 'Failed to delete row');
    }
  };

  const exportRows = () => rows.map((r) => {
    const o: Record<string, unknown> = {};
    Object.entries(r).forEach(([k, v]) => { o[k] = typeof v === 'object' ? JSON.stringify(v) : v; });
    return o;
  });

  const exportFile = (type: 'json' | 'csv') => {
    const data = exportRows();
    if (type === 'json') {
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = `${table}.json`; a.click();
      URL.revokeObjectURL(url);
    } else exportCSV(data, `${table}.csv`);
    toast.success(`Exported ${type.toUpperCase()}`);
  };

  const startCreate = () => {
    setNewRow({});
    setNewKeys(table === 'user_accounts' ? ['full_name', 'email', 'role', 'phone'] : ['id']);
    setShowCreate(true);
  };

  const addCreateKey = (k: string) => { if (k && !newKeys.includes(k)) setNewKeys([...newKeys, k]); };

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <h3 className="flex items-center gap-2 text-base font-bold text-slate-900">
          <Database className="h-5 w-5 text-green-600" /> Database Control
        </h3>
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search rows..."
              className="w-48 rounded-xl border border-slate-200 bg-slate-50 py-2 pl-9 pr-3 text-sm placeholder:text-slate-400 focus:border-green-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-green-100" />
          </div>
          <button onClick={() => exportFile('json')} className="flex items-center gap-1.5 rounded-xl border border-slate-200 px-3 py-2 text-xs font-bold text-slate-600 hover:bg-slate-50">
            <FileJson className="h-4 w-4" /> JSON
          </button>
          <button onClick={() => exportFile('csv')} className="flex items-center gap-1.5 rounded-xl border border-slate-200 px-3 py-2 text-xs font-bold text-slate-600 hover:bg-slate-50">
            <FileSpreadsheet className="h-4 w-4" /> CSV
          </button>
          <button onClick={startCreate} className="flex items-center gap-1.5 rounded-xl bg-green-600 px-3.5 py-2 text-xs font-bold text-white shadow-sm transition-all hover:bg-green-700 active:scale-[0.98]">
            <Plus className="h-4 w-4" /> New Row
          </button>
        </div>
      </div>

      <div className="mb-4 flex flex-wrap gap-2">
        {TABLES.map((t) => (
          <button key={t.key} onClick={() => setTable(t.key)}
            className={`flex items-center gap-1.5 rounded-xl border px-3 py-2 text-xs font-bold transition-all active:scale-[0.98] ${
              table === t.key ? 'border-green-600 bg-green-600 text-white shadow-sm' : 'border-slate-200 text-slate-600 hover:border-green-300 hover:bg-green-50'
            }`}>
            <Table2 className="h-3.5 w-3.5" /> {t.label}
          </button>
        ))}
      </div>

      <p className="mb-4 text-xs font-semibold text-slate-500">
        {TABLES.find((t) => t.key === table)?.desc} · {rows.length} rows
        {table !== 'platform_settings' && ` · page ${page + 1} of ${totalPages}`}
      </p>

      {showCreate && (
        <div className="mb-4 rounded-xl border border-green-200 bg-green-50/60 p-4">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-sm font-bold text-slate-900">New row in {table}</p>
            <button onClick={() => setShowCreate(false)} className="rounded-lg p-1 text-slate-400 hover:bg-slate-100"><X className="h-4 w-4" /></button>
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {newKeys.map((k) => (
              <div key={k}>
                <label className="mb-1 block text-[11px] font-bold uppercase tracking-wider text-slate-500">{k}</label>
                <input className={inputCls} placeholder={k} onChange={(e) => setNewRow((r) => ({ ...r, [k]: e.target.value }))} />
              </div>
            ))}
            <div>
              <label className="mb-1 block text-[11px] font-bold uppercase tracking-wider text-slate-500">+ add column</label>
              <input className={inputCls} placeholder="column_name" list="db-new-cols"
                onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addCreateKey((e.target as HTMLInputElement).value); (e.target as HTMLInputElement).value = ''; } }} />
            </div>
          </div>
          <div className="mt-3 flex gap-2">
            <button onClick={createRow} disabled={saving || newKeys.length === 0}
              className="flex items-center gap-1.5 rounded-xl bg-green-600 px-4 py-2 text-xs font-bold text-white transition-all hover:bg-green-700 active:scale-[0.98] disabled:opacity-60">
              {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />} Create Row
            </button>
            <button onClick={() => setShowCreate(false)} className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-bold text-slate-600">Cancel</button>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-12"><Loader2 className="h-6 w-6 animate-spin text-green-600" /></div>
      ) : rows.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <Inbox className="mb-2 h-9 w-9 text-slate-300" />
          <p className="text-sm font-medium text-slate-500">No rows in {table}</p>
        </div>
      ) : (
        <div className="max-h-[640px] overflow-auto rounded-xl border border-slate-100">
          <table className="w-full text-left text-sm">
            <thead className="sticky top-0 z-10 bg-slate-50">
              <tr className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                {columns.slice(0, 7).map((c) => <th key={c} className="whitespace-nowrap px-3 py-2.5">{c}</th>)}
                <th className="px-3 py-2.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paged.map((row, idx) => (
                <tr key={String(row.id ?? idx)} className="hover:bg-slate-50/60">
                  {columns.slice(0, 7).map((c) => {
                    const v = row[c];
                    const isEditing = editing?.id === row.id && editKey === c;
                    const editable = typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean';
                    return (
                      <td key={c} className="whitespace-nowrap px-3 py-2 text-slate-700">
                        {isEditing && editable ? (
                          <input autoFocus
                            className="w-32 rounded-lg border border-green-400 bg-white px-2 py-1 text-xs focus:outline-none focus:ring-2 focus:ring-green-100"
                            defaultValue={String(v ?? '')}
                            onChange={(e) => setEditing((ed) => (ed ? { ...ed, [c]: typeof v === 'number' ? Number(e.target.value) : e.target.value } : ed))}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') saveEdit();
                              if (e.key === 'Escape') { setEditing(null); setEditKey(''); }
                            }}
                          />
                        ) : typeof v === 'boolean' ? (
                          <span className={`inline-flex rounded-full px-2 py-0.5 text-[10px] font-black uppercase ${v ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-500'}`}>{String(v)}</span>
                        ) : (
                          <span className="line-clamp-1 max-w-[160px]">{fmt(v)}</span>
                        )}
                      </td>
                    );
                  })}
                  <td className="px-3 py-2 text-right">
                    {table !== 'platform_settings' && (
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => {
                            if (editing?.id === row.id) saveEdit();
                            else {
                              setEditing({ ...row });
                              const first = columns.find((c) => typeof row[c] === 'string' || typeof row[c] === 'number');
                              setEditKey(first || '');
                            }
                          }}
                          className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-slate-100 hover:text-blue-600" title="Inline edit">
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button onClick={() => removeRow(row)} className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {!loading && rows.length > 0 && table !== 'platform_settings' && (
        <div className="mt-4 flex items-center justify-between">
          <button onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={page === 0}
            className="flex items-center gap-1 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-bold text-slate-600 hover:bg-slate-50 disabled:opacity-40">
            <ChevronLeft className="h-3.5 w-3.5" /> Prev
          </button>
          <span className="text-xs font-semibold text-slate-500">{page + 1} / {totalPages}</span>
          <button onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))} disabled={page >= totalPages - 1}
            className="flex items-center gap-1 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-bold text-slate-600 hover:bg-slate-50 disabled:opacity-40">
            Next <ChevronRight className="h-3.5 w-3.5" />
          </button>
        </div>
      )}
    </div>
  );
}