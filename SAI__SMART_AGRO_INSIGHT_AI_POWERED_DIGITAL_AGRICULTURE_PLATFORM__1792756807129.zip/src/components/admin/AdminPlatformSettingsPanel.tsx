import React, { useCallback, useEffect, useState } from 'react';
import { toast } from 'sonner';
import {
  SlidersHorizontal,
  Megaphone,
  Save,
  Loader2,
  Lock,
  LockOpen,
  Power,
  TrendingUp,
  Scale,
  CheckCircle2,
  XCircle,
} from 'lucide-react';
import {
  fetchPlatformSettings,
  updatePlatformSettings,
  logAudit,
  type PlatformSettings,
} from './admin-api';

const inputCls =
  'w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-green-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-green-100';

export default function AdminPlatformSettingsPanel({ actorName = 'admin' }: { actorName?: string }) {
  const [settings, setSettings] = useState<PlatformSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [adminName, setAdminName] = useState(actorName);

  useEffect(() => {
    setAdminName(actorName);
  }, [actorName]);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      setSettings(await fetchPlatformSettings());
    } catch (error: any) {
      toast.error(error.message || 'Failed to load platform settings');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const patch = (p: Partial<PlatformSettings>) => {
    setSettings((s) => (s ? { ...s, ...p } : s));
  };

  const save = async () => {
    if (!settings) return;
    setSaving(true);
    try {
      const updated = await updatePlatformSettings({
        platform_name: settings.platform_name,
        announcement: settings.announcement,
        commission_pct: Number(settings.commission_pct) || 0,
        min_trade_mt: Number(settings.min_trade_mt) || 0,
        freeze_trading: settings.freeze_trading,
        maintenance_mode: settings.maintenance_mode,
      });
      setSettings(updated);
      await logAudit(adminName || 'admin', 'update', 'platform_settings updated');
      toast.success('Platform settings saved');
    } catch (error: any) {
      toast.error(error.message || 'Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  const toggle = async (key: 'freeze_trading' | 'maintenance_mode') => {
    if (!settings) return;
    const next = !settings[key];
    try {
      const updated = await updatePlatformSettings({ [key]: next });
      setSettings(updated);
      await logAudit(
        adminName || 'admin',
        'toggle',
        `${key} set to ${next}`
      );
      toast.success(next ? 'Enabled' : 'Disabled');
    } catch (error: any) {
      toast.error(error.message || 'Failed to update toggle');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center rounded-2xl border border-slate-200 bg-white p-12">
        <Loader2 className="h-6 w-6 animate-spin text-green-600" />
      </div>
    );
  }

  if (!settings) {
    return (
      <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center text-sm font-medium text-slate-500">
        Unable to load platform settings.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Announcement banner */}
      <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <h3 className="mb-4 flex items-center gap-2 text-base font-bold text-slate-900">
          <Megaphone className="h-5 w-5 text-amber-500" /> Announcement Banner
        </h3>
        <div className="space-y-3">
          <div>
            <label className="mb-1 block text-xs font-bold text-slate-600">Broadcast message</label>
            <textarea
              rows={3}
              className={inputCls}
              value={settings.announcement}
              onChange={(e) => patch({ announcement: e.target.value })}
              placeholder="e.g. Maize prices up 12% in Kano this week. Check the Market tab."
            />
          </div>

          {/* Live preview */}
          <div className="rounded-xl border border-amber-200 bg-gradient-to-r from-amber-50 to-orange-50 p-4">
            <div className="mb-2 flex items-center gap-2">
              <Megaphone className="h-4 w-4 text-amber-600" />
              <span className="text-xs font-black uppercase tracking-wider text-amber-700">
                Live preview · farmers see this banner
              </span>
            </div>
            <p className="text-sm font-semibold text-slate-800">
              {settings.announcement.trim()
                ? settings.announcement
                : 'No announcement active. Farmers will not see a banner.'}
            </p>
          </div>
        </div>
      </section>

      {/* Status toggles */}
      <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <h3 className="mb-4 flex items-center gap-2 text-base font-bold text-slate-900">
          <Power className="h-5 w-5 text-green-600" /> Platform Status
        </h3>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div className="flex items-center justify-between rounded-xl border border-slate-200 p-4">
            <div className="flex items-center gap-3">
              {settings.maintenance_mode ? (
                <Lock className="h-5 w-5 text-red-500" />
              ) : (
                <LockOpen className="h-5 w-5 text-green-500" />
              )}
              <div>
                <p className="text-sm font-bold text-slate-900">Maintenance Mode</p>
                <p className="text-[11px] text-slate-500">
                  {settings.maintenance_mode ? 'Blocking farmer access' : 'App fully online'}
                </p>
              </div>
            </div>
            <button
              onClick={() => toggle('maintenance_mode')}
              className={`relative h-7 w-12 rounded-full transition-colors ${
                settings.maintenance_mode ? 'bg-red-500' : 'bg-slate-200'
              }`}
              aria-label="Toggle maintenance mode"
            >
              <span
                className={`absolute top-0.5 h-6 w-6 rounded-full bg-white shadow transition-all ${
                  settings.maintenance_mode ? 'left-[22px]' : 'left-0.5'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between rounded-xl border border-slate-200 p-4">
            <div className="flex items-center gap-3">
              {settings.freeze_trading ? (
                <XCircle className="h-5 w-5 text-red-500" />
              ) : (
                <CheckCircle2 className="h-5 w-5 text-emerald-500" />
              )}
              <div>
                <p className="text-sm font-bold text-slate-900">Freeze Trading</p>
                <p className="text-[11px] text-slate-500">
                  {settings.freeze_trading ? 'Buy/sell suspended' : 'Trading live'}
                </p>
              </div>
            </div>
            <button
              onClick={() => toggle('freeze_trading')}
              className={`relative h-7 w-12 rounded-full transition-colors ${
                settings.freeze_trading ? 'bg-red-500' : 'bg-slate-200'
              }`}
              aria-label="Toggle trading freeze"
            >
              <span
                className={`absolute top-0.5 h-6 w-6 rounded-full bg-white shadow transition-all ${
                  settings.freeze_trading ? 'left-[22px]' : 'left-0.5'
                }`}
              />
            </button>
          </div>
        </div>
      </section>

      {/* Financials */}
      <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <h3 className="mb-4 flex items-center gap-2 text-base font-bold text-slate-900">
          <SlidersHorizontal className="h-5 w-5 text-blue-500" /> Trading & Fees
        </h3>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label className="mb-1 flex items-center gap-1.5 text-xs font-bold text-slate-600">
              <TrendingUp className="h-3.5 w-3.5 text-blue-500" /> Commission rate (%)
            </label>
            <input
              type="number"
              step="0.1"
              className={inputCls}
              value={settings.commission_pct}
              onChange={(e) => patch({ commission_pct: Number(e.target.value) })}
            />
          </div>
          <div>
            <label className="mb-1 flex items-center gap-1.5 text-xs font-bold text-slate-600">
              <Scale className="h-3.5 w-3.5 text-blue-500" /> Minimum trade (metric tons)
            </label>
            <input
              type="number"
              step="0.5"
              className={inputCls}
              value={settings.min_trade_mt}
              onChange={(e) => patch({ min_trade_mt: Number(e.target.value) })}
            />
          </div>
          <div>
            <label className="mb-1 block text-xs font-bold text-slate-600">Platform name</label>
            <input
              className={inputCls}
              value={settings.platform_name}
              onChange={(e) => patch({ platform_name: e.target.value })}
            />
          </div>
        </div>
        <div className="mt-4 flex justify-end">
          <button
            onClick={save}
            disabled={saving}
            className="flex items-center gap-1.5 rounded-xl bg-green-600 px-4 py-2 text-xs font-bold text-white shadow-sm transition-all hover:bg-green-700 active:scale-[0.98] disabled:opacity-60"
          >
            {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
            Save Settings
          </button>
        </div>
      </section>
    </div>
  );
}