import { supabase } from '@/integrations/supabase/client';

export type AdminTab = 'overview' | 'farmers' | 'partners' | 'updates' | 'consultations';

export interface AdminFarmer {
  id: string;
  farmer_name: string;
  location: string;
  crop: string;
  farm_size: string;
  planting_date: string;
  expected_harvest: string;
  yield_estimate: string;
  phone: string;
  status: string;
  state: string;
  verified: boolean;
  notes: string;
  created_at: string;
  updated_at: string;
}

export interface AdminPartner {
  id: string;
  org_name: string;
  partnership_type: string;
  contact_person: string;
  contact_email: string;
  contact_phone: string;
  state: string;
  description: string;
  status: string;
  tier: string;
  created_at: string;
}

export interface AdminAlert {
  id: string;
  title: string;
  message: string;
  type: string;
  severity: string;
  location: string;
  created_at: string;
}

export interface AdminPrice {
  id: string;
  crop: string;
  crop_category: string;
  price: number;
  unit: string;
  location: string;
  state: string;
  zone: string;
  trend: string;
  change: string;
  verified: boolean;
  updated_at: string;
  created_at: string;
}

export const EMPTY_FARMER: AdminFarmer = {
  id: '',
  farmer_name: '',
  location: '',
  crop: '',
  farm_size: '',
  planting_date: '',
  expected_harvest: '',
  yield_estimate: '',
  phone: '',
  status: 'Pending',
  state: '',
  verified: false,
  notes: '',
  created_at: '',
  updated_at: '',
};

export const EMPTY_ALERT: AdminAlert = {
  id: '',
  title: '',
  message: '',
  type: 'broadcast',
  severity: 'info',
  location: '',
  created_at: '',
};

export const EMPTY_PRICE: AdminPrice = {
  id: '',
  crop: '',
  crop_category: 'grains',
  price: 0,
  unit: '100kg bag',
  location: '',
  state: '',
  zone: '',
  trend: 'stable',
  change: '0.0%',
  verified: true,
  updated_at: '',
  created_at: '',
};

async function run<T>(fn: () => Promise<{ data: T | null; error: { message: string } | null }>, fallback: T): Promise<T> {
  const { data, error } = await fn();
  if (error) throw error;
  return (data ?? fallback) as T;
}

export async function fetchFarmers(): Promise<AdminFarmer[]> {
  return run<AdminFarmer[]>(async () => {
    const res = await supabase.from('farm_records').select('*').order('created_at', { ascending: false }).limit(500);
    return { data: (res.data ?? []) as AdminFarmer[], error: res.error };
  }, []);
}

export async function upsertFarmer(farmer: AdminFarmer): Promise<void> {
  const payload = {
    farmer_name: farmer.farmer_name,
    location: farmer.location,
    crop: farmer.crop,
    farm_size: farmer.farm_size,
    planting_date: farmer.planting_date,
    expected_harvest: farmer.expected_harvest,
    yield_estimate: farmer.yield_estimate,
    phone: farmer.phone,
    status: farmer.status,
    state: farmer.state,
    verified: farmer.verified,
    notes: farmer.notes,
  };
  const { error } = farmer.id
    ? await supabase.from('farm_records').update(payload).eq('id', farmer.id)
    : await supabase.from('farm_records').insert([payload]);
  if (error) throw error;
}

export async function deleteFarmer(id: string): Promise<void> {
  const { error } = await supabase.from('farm_records').delete().eq('id', id);
  if (error) throw error;
}

export async function fetchPartners(): Promise<AdminPartner[]> {
  return run<AdminPartner[]>(async () => {
    const res = await supabase.from('partnerships').select('*').order('created_at', { ascending: false }).limit(500);
    return { data: (res.data ?? []) as AdminPartner[], error: res.error };
  }, []);
}

export async function updatePartner(id: string, patch: Partial<AdminPartner>): Promise<void> {
  const { error } = await supabase.from('partnerships').update(patch).eq('id', id);
  if (error) throw error;
}

export async function deletePartner(id: string): Promise<void> {
  const { error } = await supabase.from('partnerships').delete().eq('id', id);
  if (error) throw error;
}

export async function fetchAlerts(): Promise<AdminAlert[]> {
  return run<AdminAlert[]>(async () => {
    const res = await supabase.from('alerts').select('*').order('created_at', { ascending: false }).limit(300);
    return { data: (res.data ?? []) as AdminAlert[], error: res.error };
  }, []);
}

export async function insertAlert(alert: Omit<AdminAlert, 'id' | 'created_at'>): Promise<void> {
  const { error } = await supabase.from('alerts').insert([alert]);
  if (error) throw error;
}

export async function deleteAlert(id: string): Promise<void> {
  const { error } = await supabase.from('alerts').delete().eq('id', id);
  if (error) throw error;
}

export async function fetchPrices(): Promise<AdminPrice[]> {
  return run<AdminPrice[]>(async () => {
    const res = await supabase.from('market_prices').select('*').order('crop').limit(500);
    return { data: (res.data ?? []) as AdminPrice[], error: res.error };
  }, []);
}

export async function upsertPrice(price: AdminPrice): Promise<void> {
  const payload = {
    crop: price.crop,
    crop_category: price.crop_category,
    price: price.price,
    unit: price.unit,
    location: price.location,
    state: price.state,
    zone: price.zone,
    trend: price.trend,
    change: price.change,
    verified: price.verified,
  };
  const { error } = price.id
    ? await supabase.from('market_prices').update(payload).eq('id', price.id)
    : await supabase.from('market_prices').insert([payload]);
  if (error) throw error;
}

export async function deletePrice(id: string): Promise<void> {
  const { error } = await supabase.from('market_prices').delete().eq('id', id);
  if (error) throw error;
}

export interface AdminUserAccount {
  id: string;
  auth_id: string | null;
  full_name: string;
  email: string | null;
  phone: string | null;
  role: string;
  org: string | null;
  location: string | null;
  verified: boolean;
  active: boolean;
  joined: string;
  meta: Record<string, unknown> | null;
  created_at: string;
}

export interface AuditLog {
  id: string;
  actor: string;
  action: string;
  detail: string;
  time: string;
  created_at: string;
}

export interface PlatformSettings {
  id: number;
  platform_name: string;
  announcement: string;
  commission_pct: number;
  min_trade_mt: number;
  freeze_trading: boolean;
  maintenance_mode: boolean;
  updated_at: string;
}

export interface AdminEntry {
  id: string;
  email: string;
  name: string;
  role: 'super_admin' | 'admin';
  created_at: string;
  updated_at: string;
}

export interface ConsultationRow {
  id: string;
  question: string;
  language: string;
  media_type: string;
  media_urls: string[];
  media_names: string[];
  media_sizes: number[];
  ai_response: string;
  status: string;
  created_at: string;
}

/* ---------- Platform Settings ---------- */

export async function fetchPlatformSettings(): Promise<PlatformSettings> {
  const res = await supabase.from('platform_settings').select('*').eq('id', 1).maybeSingle();
  if (res.error) throw res.error;
  if (!res.data) {
    const { data: created, error: insertError } = await supabase
      .from('platform_settings')
      .insert([{ id: 1 }])
      .select('*')
      .single();
    if (insertError) throw insertError;
    return created as unknown as PlatformSettings;
  }
  return res.data as unknown as PlatformSettings;
}

export async function updatePlatformSettings(patch: Partial<PlatformSettings>): Promise<PlatformSettings> {
  const { data, error } = await supabase
    .from('platform_settings')
    .update(patch)
    .eq('id', 1)
    .select('*')
    .single();
  if (error) throw error;
  return data as unknown as PlatformSettings;
}

/* ---------- User Accounts ---------- */

export async function fetchUserAccounts(search = '', limit = 200): Promise<AdminUserAccount[]> {
  let query = supabase.from('user_accounts').select('*').order('created_at', { ascending: false }).limit(limit);
  if (search.trim()) {
    const q = `%${search.trim()}%`;
    query = query.or(`full_name.ilike.${q},email.ilike.${q},phone.ilike.${q},location.ilike.${q}`);
  }
  const res = await query;
  if (res.error) throw res.error;
  return (res.data ?? []) as unknown as AdminUserAccount[];
}

export async function upsertUserAccount(account: AdminUserAccount): Promise<void> {
  const payload = {
    full_name: account.full_name,
    email: account.email,
    phone: account.phone,
    role: account.role,
    org: account.org,
    location: account.location,
    verified: account.verified,
    active: account.active,
  };
  const { error } = account.id
    ? await supabase.from('user_accounts').update(payload).eq('id', account.id)
    : await supabase.from('user_accounts').insert([payload]);
  if (error) throw error;
}

export async function deleteUserAccount(id: string): Promise<void> {
  const { error } = await supabase.from('user_accounts').delete().eq('id', id);
  if (error) throw error;
}

/* ---------- AI Consultations (admin) ---------- */

export async function fetchConsultationsAdmin(limit = 100): Promise<ConsultationRow[]> {
  return run<ConsultationRow[]>(async () => {
    const res = await supabase.from('ai_consultations').select('*').order('created_at', { ascending: false }).limit(limit);
    return { data: (res.data ?? []) as ConsultationRow[], error: res.error };
  }, []);
}

export async function saveConsultationResponse(id: string, response: string, status = 'reviewed'): Promise<void> {
  const { error } = await supabase
    .from('ai_consultations')
    .update({ ai_response: response, status })
    .eq('id', id);
  if (error) throw error;
}

export async function deleteConsultation(id: string): Promise<void> {
  const { error } = await supabase.from('ai_consultations').delete().eq('id', id);
  if (error) throw error;
}

/* ---------- Audit Logs ---------- */

export async function logAudit(actor: string, action: string, detail: string): Promise<void> {
  const { error } = await supabase.from('audit_logs').insert([
    { actor, action, detail, time: new Date().toISOString() },
  ]);
  if (error) console.error('audit_log insert failed:', error.message);
}

export async function fetchAuditLogs(limit = 200): Promise<AuditLog[]> {
  return run<AuditLog[]>(async () => {
    const res = await supabase.from('audit_logs').select('*').order('created_at', { ascending: false }).limit(limit);
    return { data: (res.data ?? []) as AuditLog[], error: res.error };
  }, []);
}

/* ---------- Admins ---------- */

export async function fetchAdmins(): Promise<AdminEntry[]> {
  return run<AdminEntry[]>(async () => {
    const res = await supabase.from('admins').select('*').order('created_at', { ascending: false });
    return { data: (res.data ?? []) as AdminEntry[], error: res.error };
  }, []);
}

/* ---------- Database Explorer helpers ---------- */

export async function fetchTableRows(
  table: string,
  limit = 100
): Promise<Record<string, unknown>[]> {
  const res = await supabase.from(table as never).select('*').limit(limit);
  if (res.error) throw res.error;
  return (res.data ?? []) as Record<string, unknown>[];
}

export async function insertRow(
  table: string,
  payload: Record<string, unknown>
): Promise<void> {
  const { error } = await supabase.from(table as never).insert([payload]);
  if (error) throw error;
}

export async function updateRow(
  table: string,
  id: string,
  payload: Record<string, unknown>
): Promise<void> {
  const { error } = await supabase.from(table as never).update(payload).eq('id', id);
  if (error) throw error;
}

export async function deleteRow(table: string, id: string): Promise<void> {
  const { error } = await supabase.from(table as never).delete().eq('id', id);
  if (error) throw error;
}

const CSV_NEWLINE = String.fromCharCode(10);

function needsCsvQuoting(s: string): boolean {
  return s.indexOf(',') !== -1 || s.indexOf('"') !== -1 || s.indexOf(String.fromCharCode(13)) !== -1 || s.indexOf(String.fromCharCode(10)) !== -1;
}

export function exportCSV(rows: Record<string, unknown>[], filename: string): void {
  if (rows.length === 0) return;
  const headers = Object.keys(rows[0]);
  const escape = (v: unknown) => {
    const s = String(v ?? '');
    return needsCsvQuoting(s) ? '"' + s.split('"').join('""') + '"' : s;
  };
  const csv = [headers.join(','), ...rows.map((r) => headers.map((h) => escape(r[h])).join(','))].join(CSV_NEWLINE);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}