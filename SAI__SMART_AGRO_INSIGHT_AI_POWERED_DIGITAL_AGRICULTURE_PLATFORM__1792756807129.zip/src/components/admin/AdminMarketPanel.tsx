import React, { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { TrendingUp, Plus, Trash2, Pencil, X, Loader2, CheckCircle2, Inbox } from 'lucide-react';
import { fetchPrices, upsertPrice, deletePrice, EMPTY_PRICE, type AdminPrice } from './admin-api';

const ZONES = ['North West', 'North Central', 'North East', 'South West', 'South East', 'South South'];
const CATEGORIES = ['grains', 'tubers', 'cash_crops', 'vegetables'];

const inputCls =
  'w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-green-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-green-100';

export default function AdminMarketPanel() {
  const [prices, setPrices] = useState<AdminPrice[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState<AdminPrice>({ ...EMPTY_PRICE });
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<AdminPrice | null>(null);

  const load = async () => {
    setLoading(true);
    try {
      setPrices(await fetchPrices());
    } catch (error: any) {
      toast.error(error.message || 'Failed to load market prices');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const openAdd = () => {
    setEditing(null);
    setForm({ ...EMPTY_PRICE });
    setShowForm(true);
  };

  const openEdit = (p: AdminPrice) => {
    setEditing(p);
    setForm({ ...p });
    setShowForm(true);
  };

  const save = async () => {
    if (!form.crop.trim() || !form.price) {
      toast.error('Crop and price are required');
      return;
    }
    try {
      await upsertPrice(form);
      toast.success(editing ? 'Price updated' : 'Market price added');
      setShowForm(false);
      await load();
    } catch (error: any) {
      toast.error(error.message || 'Failed to save market price');
    }
  };

  const remove = async (p: AdminPrice) => {
    if (!window.confirm(`Delete price entry for ${p.crop}?`)) return;
    try {
      await deletePrice(p.id);
      toast.success('Price entry deleted');
      await load();
    } catch (error: any) {
      toast.error(error.message || 'Failed to delete price');
    }
  };

  return (
    <section className="h-full rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="flex items-center gap-2 text-base font-bold text-slate-900">
          <TrendingUp className="h-5 w-5 text-green-600" /> Market Updates
        </h3>
        <button
          onClick={openAdd}
          className="flex items-center gap-1.5 rounded-xl bg-green-600 px-3.5 py-2 text-xs font-bold text-white shadow-sm transition-all hover:bg-green-700 active:scale-[0.98]"
        >
          <Plus className="h-4 w-4" /> Add Price
        </button>
      </div>

      {showForm && (
        <div className="mb-4 space-y-3 rounded-xl border border-green-200 bg-green-50/60 p-4">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-600">Crop</label>
              <input className={inputCls} value={form.crop} onChange={(e) => setForm({ ...form, crop: e.target.value })} placeholder="e.g. Maize" />
            </div>
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-600">Category</label>
              <select className={inputCls} value={form.crop_category} onChange={(e) => setForm({ ...form, crop_category: e.target.value })}>
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-600">Price (NGN)</label>
              <input type="number" className={inputCls} value={form.price || ''} onChange={(e) => setForm({ ...form, price: Number(e.target.value) })} />
            </div>
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-600">Unit</label>
              <input className={inputCls} value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} placeholder="100kg bag" />
            </div>
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-600">State</label>
              <input className={inputCls} value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} placeholder="e.g. Kano" />
            </div>
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-600">Zone</label>
              <select className={inputCls} value={form.zone} onChange={(e) => setForm({ ...form, zone: e.target.value })}>
                {ZONES.map((z) => (
                  <option key={z} value={z}>{z}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-600">Market / Location</label>
              <input className={inputCls} value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="e.g. Dawanau Kano" />
            </div>
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-600">Trend</label>
              <select className={inputCls} value={form.trend} onChange={(e) => setForm({ ...form, trend: e.target.value })}>
                <option value="up">Up</option>
                <option value="down">Down</option>
                <option value="stable">Stable</option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-600">Change %</label>
              <input className={inputCls} value={form.change} onChange={(e) => setForm({ ...form, change: e.target.value })} placeholder="+2.5%" />
            </div>
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-600">Verified</label>
              <label className="flex cursor-pointer items-center gap-2 rounded-xl border border-slate-200 bg-white px-3.5 py-2.5">
                <input type="checkbox" checked={form.verified} onChange={(e) => setForm({ ...form, verified: e.target.checked })} className="h-4 w-4 accent-green-600" />
                <span className="text-sm font-semibold text-slate-700">Verified price</span>
              </label>
            </div>
          </div>
          <div className="flex gap-2">
            <button
              onClick={save}
              className="flex items-center gap-1.5 rounded-xl bg-green-600 px-4 py-2 text-xs font-bold text-white transition-all hover:bg-green-700 active:scale-[0.98]"
            >
              <CheckCircle2 className="h-3.5 w-3.5" /> {editing ? 'Save Changes' : 'Add Price'}
            </button>
            <button onClick={() => setShowForm(false)} className="flex items-center gap-1 rounded-xl border border-slate-200 px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-50">
              <X className="h-3.5 w-3.5" /> Cancel
            </button>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-10">
          <Loader2 className="h-6 w-6 animate-spin text-green-600" />
        </div>
      ) : prices.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-10 text-center">
          <Inbox className="mb-2 h-9 w-9 text-slate-300" />
          <p className="text-sm font-medium text-slate-500">No market prices yet</p>
        </div>
      ) : (
        <table className="w-full text-left">
          <thead>
            <tr className="text-[10px] font-black uppercase tracking-widest text-slate-400">
              <th className="py-2 pr-3">Crop</th>
              <th className="py-2 pr-3">Price</th>
              <th className="py-2 pr-3">Location</th>
              <th className="py-2 pr-3">Trend</th>
              <th className="py-2 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {prices.map((p) => (
              <tr key={p.id} className="text-sm">
                <td className="py-2.5 pr-3">
                  <p className="font-semibold text-slate-900">{p.crop}</p>
                  <p className="text-[11px] text-slate-400">{p.crop_category}</p>
                </td>
                <td className="py-2.5 pr-3 font-bold text-slate-900">
                  ₦{Number(p.price).toLocaleString()}
                  <span className="block text-[10px] font-medium text-slate-400">{p.unit}</span>
                </td>
                <td className="py-2.5 pr-3">
                  <p className="text-slate-700">{p.location || '-'}</p>
                  <p className="text-[11px] text-slate-400">{p.zone}</p>
                </td>
                <td className="py-2.5 pr-3">
                  <span
                    className={`rounded-full px-2 py-0.5 text-[10px] font-black uppercase ${
                      p.trend === 'up'
                        ? 'bg-green-100 text-green-700'
                        : p.trend === 'down'
                        ? 'bg-red-100 text-red-600'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {p.trend} {p.change}
                  </span>
                </td>
                <td className="py-2.5 text-right">
                  <div className="flex items-center justify-end gap-1">
                    <button onClick={() => openEdit(p)} className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-slate-100 hover:text-blue-600">
                      <Pencil className="h-4 w-4" />
                    </button>
                    <button onClick={() => remove(p)} className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </section>
  );
}