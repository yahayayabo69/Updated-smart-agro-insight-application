import React, { useEffect, useMemo, useState } from 'react';
import { toast } from 'sonner';
import {
  Handshake,
  Building2,
  CheckCircle2,
  XCircle,
  Trash2,
  Loader2,
  Mail,
  Phone,
  MapPin,
  Star,
  Inbox,
} from 'lucide-react';
import { fetchPartners, updatePartner, deletePartner, type AdminPartner } from './admin-api';

const TYPE_LABELS: Record<string, string> = {
  agribusiness: 'Agribusiness',
  cooperative: 'Cooperative',
  buyer: 'Buyer / Off-taker',
  ngo: 'NGO / Development',
  government: 'Government',
};

const TIERS = ['standard', 'premium', 'strategic'];

function typeChip(t: string): string {
  return (
    {
      agribusiness: 'bg-blue-100 text-blue-700',
      cooperative: 'bg-green-100 text-green-700',
      buyer: 'bg-purple-100 text-purple-700',
      ngo: 'bg-amber-100 text-amber-700',
      government: 'bg-slate-100 text-slate-700',
    }[t] || 'bg-slate-100 text-slate-600'
  );
}

export default function AdminPartnersPanel() {
  const [partners, setPartners] = useState<AdminPartner[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'pending' | 'approved' | 'rejected' | 'all'>('pending');

  const load = async () => {
    setLoading(true);
    try {
      setPartners(await fetchPartners());
    } catch (error: any) {
      toast.error(error.message || 'Failed to load partners');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const counts = useMemo(
    () => ({
      pending: partners.filter((p) => p.status === 'pending').length,
      approved: partners.filter((p) => p.status === 'approved').length,
      rejected: partners.filter((p) => p.status === 'rejected').length,
      all: partners.length,
    }),
    [partners]
  );

  const filtered = partners.filter((p) => tab === 'all' || p.status === tab);

  const setStatus = async (p: AdminPartner, status: string) => {
    try {
      await updatePartner(p.id, { status });
      toast.success(`Partnership ${status}`);
      await load();
    } catch (error: any) {
      toast.error(error.message || 'Failed to update partnership');
    }
  };

  const setTier = async (p: AdminPartner, tier: string) => {
    try {
      await updatePartner(p.id, { tier });
      toast.success(`Tier updated to ${tier}`);
      await load();
    } catch (error: any) {
      toast.error(error.message || 'Failed to update tier');
    }
  };

  const remove = async (p: AdminPartner) => {
    if (!window.confirm(`Delete partnership record for ${p.org_name}?`)) return;
    try {
      await deletePartner(p.id);
      toast.success('Partnership removed');
      await load();
    } catch (error: any) {
      toast.error(error.message || 'Failed to delete partnership');
    }
  };

  return (
    <div className="space-y-5">
      {/* Status tabs */}
      <div className="flex flex-wrap gap-2">
        {(['pending', 'approved', 'rejected', 'all'] as const).map((key) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={`rounded-xl px-4 py-2 text-xs font-black uppercase tracking-wider transition-all ${
              tab === key
                ? 'bg-green-600 text-white shadow-sm'
                : 'border border-slate-200 bg-white text-slate-600 hover:border-green-300 hover:text-green-700'
            }`}
          >
            {key} ({counts[key]})
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex items-center justify-center rounded-2xl border border-slate-200 bg-white py-16">
          <Loader2 className="h-6 w-6 animate-spin text-green-600" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-2xl border border-slate-200 bg-white py-16 text-center">
          <Inbox className="mb-3 h-10 w-10 text-slate-300" />
          <p className="text-sm font-medium text-slate-500">No {tab === 'all' ? '' : tab + ' '}partnerships found</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {filtered.map((p) => (
            <div key={p.id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition-shadow hover:shadow-md">
              <div className="mb-3 flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-green-100 text-green-700">
                    <Building2 className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-slate-900">{p.org_name}</p>
                    <p className="text-[11px] text-slate-500">
                      {TYPE_LABELS[p.partnership_type] || p.partnership_type} · {p.state || 'No state'}
                    </p>
                  </div>
                </div>
                <span className={`shrink-0 rounded-full px-3 py-1 text-[10px] font-black uppercase tracking-wider ${typeChip(p.partnership_type)}`}>
                  {TYPE_LABELS[p.partnership_type] || p.partnership_type}
                </span>
              </div>

              <p className="mb-4 text-[13px] leading-relaxed text-slate-600 line-clamp-2">{p.description || 'No description provided.'}</p>

              <div className="mb-4 space-y-1.5 text-xs text-slate-500">
                <p className="flex items-center gap-2"><Mail className="h-3.5 w-3.5" /> {p.contact_email || 'No email'}</p>
                <p className="flex items-center gap-2"><Phone className="h-3.5 w-3.5" /> {p.contact_phone || 'No phone'}</p>
                <p className="flex items-center gap-2"><MapPin className="h-3.5 w-3.5" /> {p.contact_person || 'No contact person'}</p>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 pt-3">
                <div className="flex items-center gap-1.5">
                  <Star className="h-3.5 w-3.5 text-amber-500" />
                  <select
                    value={p.tier}
                    onChange={(e) => setTier(p, e.target.value)}
                    className="rounded-lg border border-slate-200 bg-white px-2 py-1 text-[11px] font-bold text-slate-600 focus:border-green-500 focus:outline-none"
                  >
                    {TIERS.map((t) => (
                      <option key={t} value={t}>{t}</option>
                    ))}
                  </select>
                </div>
                <div className="flex items-center gap-1.5">
                  {p.status === 'pending' && (
                    <>
                      <button
                        onClick={() => setStatus(p, 'approved')}
                        className="flex items-center gap-1 rounded-lg bg-green-600 px-3 py-1.5 text-[11px] font-black text-white transition-all hover:bg-green-700 active:scale-[0.98]"
                      >
                        <CheckCircle2 className="h-3.5 w-3.5" /> Approve
                      </button>
                      <button
                        onClick={() => setStatus(p, 'rejected')}
                        className="flex items-center gap-1 rounded-lg border border-red-200 px-3 py-1.5 text-[11px] font-black text-red-600 transition-all hover:bg-red-50"
                      >
                        <XCircle className="h-3.5 w-3.5" /> Reject
                      </button>
                    </>
                  )}
                  {p.status === 'approved' && (
                    <button
                      onClick={() => setStatus(p, 'pending')}
                      className="rounded-lg border border-amber-200 px-3 py-1.5 text-[11px] font-black text-amber-600 transition-all hover:bg-amber-50"
                    >
                      Move to Pending
                    </button>
                  )}
                  {p.status === 'rejected' && (
                    <button
                      onClick={() => setStatus(p, 'pending')}
                      className="rounded-lg border border-slate-200 px-3 py-1.5 text-[11px] font-black text-slate-600 transition-all hover:bg-slate-50"
                    >
                      Reopen Application
                    </button>
                  )}
                  <button
                    onClick={() => remove(p)}
                    className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600"
                    title="Delete"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>

              <div className="mt-3 flex items-center justify-between">
                <span className={`flex items-center gap-1 rounded-full px-2.5 py-1 text-[10px] font-black uppercase tracking-wider ${
                  p.status === 'approved'
                    ? 'bg-green-100 text-green-700'
                    : p.status === 'rejected'
                    ? 'bg-red-100 text-red-600'
                    : 'bg-amber-100 text-amber-700'
                }`}>
                  {p.status}
                </span>
                <Handshake className="h-4 w-4 text-slate-300" />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}