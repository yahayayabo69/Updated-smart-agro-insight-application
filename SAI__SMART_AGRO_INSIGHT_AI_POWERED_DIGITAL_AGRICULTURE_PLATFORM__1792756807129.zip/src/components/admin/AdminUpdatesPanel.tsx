import React, { useEffect, useState } from 'react';
import { toast } from 'sonner';
import {
  Bell,
  Megaphone,
  TrendingUp,
  Plus,
  Trash2,
  Pencil,
  X,
  Send,
  Loader2,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Inbox,
} from 'lucide-react';
import {
  fetchAlerts,
  insertAlert,
  deleteAlert,
  fetchPrices,
  upsertPrice,
  deletePrice,
  EMPTY_ALERT,
  EMPTY_PRICE,
  type AdminAlert,
  type AdminPrice,
} from './admin-api';

const SEVERITIES = ['info', 'warning', 'critical'];
const ALERT_TYPES = ['broadcast', 'weather', 'pest', 'announcement'];
const ZONES = [
  'North West',
  'North Central',
  'North East',
  'South West',
  'South East',
  'South South',
];
const CATEGORIES = ['grains', 'tubers', 'cash_crops', 'vegetables'];

const inputCls =
  'w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-green-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-green-100';

export default function AdminUpdatesPanel() {
  const [alerts, setAlerts] = useState<AdminAlert[]>([]);
  const [prices, setPrices] = useState<AdminPrice[]>([]);
  const [loading, setLoading] = useState(true);
  const [alertForm, setAlertForm] = useState<AdminAlert>({ ...EMPTY_ALERT });
  const [showAlertForm, setShowAlertForm] = useState(false);
  const [priceForm, setPriceForm] = useState<AdminPrice>({ ...EMPTY_PRICE });
  const [showPriceForm, setShowPriceForm] = useState(false);
  const [editingPrice, setEditingPrice] = useState<AdminPrice | null>(null);
  const [publishing, setPublishing] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const [a, p] = await Promise.all([fetchAlerts(), fetchPrices()]);
      setAlerts(a);
      setPrices(p);
    } catch (error: any) {
      toast.error(error.message || 'Failed to load updates');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const publishAlert = async () => {
    if (!alertForm.message.trim()) {
      toast.error('Alert message is required');
      return;
    }
    setPublishing(true);
    try {
      await insertAlert({
        title: alertForm.title,
        message: alertForm.message,
        type: alertForm.type,
        severity: alertForm.severity,
        location: alertForm.location,
      });
      toast.success('Alert published to farmers');
      setAlertForm({ ...EMPTY_ALERT });
      setShowAlertForm(false);
      await load();
    } catch (error: any) {
      toast.error(error.message || 'Failed to publish alert');
    } finally {
      setPublishing(false);
    }
  };

  const removeAlert = async (a: AdminAlert) => {
    if (!window.confirm(`Delete this alert?`)) return;
    try {
      await deleteAlert(a.id);
      toast.success('Alert deleted');
      await load();
    } catch (error: any) {
      toast.error(error.message || 'Failed to delete alert');
    }
  };

  const openAddPrice = () => {
    setEditingPrice(null);
    setPriceForm({ ...EMPTY_PRICE });
    setShowPriceForm(true);
  };

  const openEditPrice = (p: AdminPrice) => {
    setEditingPrice(p);
    setPriceForm({ ...p });
    setShowPriceForm(true);
  };

  const savePrice = async () => {
    if (!priceForm.crop.trim() || !priceForm.price) {
      toast.error('Crop and price are required');
      return;
    }
    try {
      await upsertPrice(priceForm);
      toast.success(editingPrice ? 'Price updated' : 'Market price added');
      setShowPriceForm(false);
      await load();
    } catch (error: any) {
      toast.error(error.message || 'Failed to save market price');
    }
  };

  const removePrice = async (p: AdminPrice) => {
    if (!window.confirm(`Delete price entry for ${p.crop}?`)) return;
    try {
      await deletePrice(p.id);
      toast.success('Price entry deleted');
      await load();
    } catch (error: any) {
      toast.error(error.message || 'Failed to delete price');
    }
  };

  return (
    <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
      {/* ---------- Alerts ---------- */}
      <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="flex items-center gap-2 text-base font-bold text-slate-900">
            <Bell className="h-5 w-5 text-amber-500" /> System Alerts
          </h3>
          <button
            onClick={() => setShowAlertForm(!showAlertForm)}
            className="flex items-center gap-1.5 rounded-xl bg-green-600 px-3.5 py-2 text-xs font-bold text-white shadow-sm transition-all hover:bg-green-700 active:scale-[0.98]"
          >
            <Plus className="h-4 w-4" /> New Alert
          </button>
        </div>

        {showAlertForm && (
          <div className="mb-4 space-y-3 rounded-xl border border-green-200 bg-green-50/60 p-4">
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-600">Title (optional)</label>
              <input
                className={inputCls}
                value={alertForm.title}
                onChange={(e) => setAlertForm({ ...alertForm, title: e.target.value })}
                placeholder="e.g. Rainfall expected in Sokoto"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-bold text-slate-600">Message</label>
              <textarea
                className={inputCls}
                rows={2}
                value={alertForm.message}
                onChange={(e) => setAlertForm({ ...alertForm, message: e.target.value })}
                placeholder="Message for farmers..."
              />
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              <div>
                <label className="mb-1 block text-xs font-bold text-slate-600">Type</label>
                <select
                  className={inputCls}
                  value={alertForm.type}
                  onChange={(e) => setAlertForm({ ...alertForm, type: e.target.value })}
                >
                  {ALERT_TYPES.map((t) => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="mb-1 block text-xs font-bold text-slate-600">Severity</label>
                <select
                  className={inputCls}
                  value={alertForm.severity}
                  onChange={(e) => setAlertForm({ ...alertForm, severity: e.target.value })}
                >
                  {SEVERITIES.map((s) => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="mb-1 block text-xs font-bold text-slate-600">Location</label>
                <input
                  className={inputCls}
                  value={alertForm.location}
                  onChange={(e) => setAlertForm({ ...alertForm, location: e.target.value })}
                  placeholder="State / LGA"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={publishAlert}
                disabled={publishing}
                className="flex items-center gap-1.5 rounded-xl bg-green-600 px-4 py-2 text-xs font-bold text-white transition-all hover:bg-green-700 active:scale-[0.98] disabled:opacity-60"
              >
                {publishing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
                Publish
              </button>
              <button
                onClick={() => setShowAlertForm(false)}
                className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-50"
              >
                Cancel
              </button>
            </div>
          </div>
        )}

        {loading ? (
          <div className="flex items-center justify-center py-10">
            <Loader2 className="h-6 w-6 animate-spin text-green-600" />
          </div>
        ) : alerts.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-10 text-center">
            <Inbox className="mb-2 h-9 w-9 text-slate-300" />
            <p className="text-sm font-medium text-slate-500">No alerts yet</p>
          </div>
        ) : (
          <div className="max-h-[560px] space-y-2.5 overflow-y-auto pr-1">
            {alerts.map((a) => {
              const icon =
                a.severity === 'critical' ? (
                  <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-500" />
                ) : a.severity === 'warning' ? (
                  <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-500" />
                ) : (
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-blue-500" />
                );
              const tone =
                a.severity === 'critical'
                  ? 'border-red-200 bg-red-50'
                  : a.severity === 'warning'
                  ? 'border-amber-200 bg-amber-50'
                  : 'border-blue-200 bg-blue-50';
              return (
                <div key={a.id} className={`flex items-start gap-2 rounded-xl border p-3 ${tone}`}>
                  {icon}
                  <div className="flex-1">
                    {a.title && <p className="text-sm font-bold text-slate-900">{a.title}</p>}
                    <p className="text-sm font-medium text-slate-700">{a.message}</p>
                    <p className="mt-0.5 text-[11px] text-slate-500">
                      {new Date(a.created_at).toLocaleString()} · {a.type} · {a.severity}
                      {a.location ? ` · ${a.location}` : ''}
                    </p>
                  </div>
                  <button
                    onClick={() => removeAlert(a)}
                    className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* ---------- Market Prices ---------- */}
      <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="flex items-center gap-2 text-base font-bold text-slate-900">
            <TrendingUp className="h-5 w-5 text-green-600" /> Market Updates
          </h3>
          <button
            onClick={openAddPrice}
            className="flex items-center gap-1.5 rounded-xl bg-green-600 px-3.5 py-2 text-xs font-bold text-white shadow-sm transition-all hover:bg-green-700 active:scale-[0.98]"
          >
            <Plus className="h-4 w-4" /> Add Price
          </button>
        </div>

        {showPriceForm && (
          <div className="mb-4 space-y-3 rounded-xl border border-green-200 bg-green-50/60 p-4">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label className="mb-1 block text-xs font-bold text-slate-600">Crop</label>
                <input
                  className={inputCls}
                  value={priceForm.crop}
                  onChange={(e) => setPriceForm({ ...priceForm, crop: e.target.value })}
                  placeholder="e.g. Maize"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-bold text-slate-600">Category</label>
                <select
                  className={inputCls}
                  value={priceForm.crop_category}
                  onChange={(e) => setPriceForm({ ...priceForm, crop_category: e.target.value })}
                >
                  {CATEGORIES.map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="mb-1 block text-xs font-bold text-slate-600">Price (NGN)</label>
                <input
                  type="number"
                  className={inputCls}
                  value={priceForm.price || ''}
                  onChange={(e) => setPriceForm({ ...priceForm, price: Number(e.target.value) })}
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-bold text-slate-600">Unit</label>
                <input
                  className={inputCls}
                  value={priceForm.unit}
                  onChange={(e) => setPriceForm({ ...priceForm, unit: e.target.value })}
                  placeholder="100kg bag"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-bold text-slate-600">State</label>
                <input
                  className={inputCls}
                  value={priceForm.state}
                  onChange={(e) => setPriceForm({ ...priceForm, state: e.target.value })}
                  placeholder="e.g. Kano"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-bold text-slate-600">Zone</label>
                <select
                  className={inputCls}
                  value={priceForm.zone}
                  onChange={(e) => setPriceForm({ ...priceForm, zone: e.target.value })}
                >
                  {ZONES.map((z) => (
                    <option key={z} value={z}>{z}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="mb-1 block text-xs font-bold text-slate-600">Market / Location</label>
                <input
                  className={inputCls}
                  value={priceForm.location}
                  onChange={(e) => setPriceForm({ ...priceForm, location: e.target.value })}
                  placeholder="e.g. Dawanau Kano"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-bold text-slate-600">Trend</label>
                <select
                  className={inputCls}
                  value={priceForm.trend}
                  onChange={(e) => setPriceForm({ ...priceForm, trend: e.target.value })}
                >
                  <option value="up">Up</option>
                  <option value="down">Down</option>
                  <option value="stable">Stable</option>
                </select>
              </div>
              <div>
                <label className="mb-1 block text-xs font-bold text-slate-600">Change %</label>
                <input
                  className={inputCls}
                  value={priceForm.change}
                  onChange={(e) => setPriceForm({ ...priceForm, change: e.target.value })}
                  placeholder="+2.5%"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-bold text-slate-600">Verified</label>
                <label className="flex cursor-pointer items-center gap-2 rounded-xl border border-slate-200 bg-white px-3.5 py-2.5">
                  <input
                    type="checkbox"
                    checked={priceForm.verified}
                    onChange={(e) => setPriceForm({ ...priceForm, verified: e.target.checked })}
                    className="h-4 w-4 accent-green-600"
                  />
                  <span className="text-sm font-semibold text-slate-700">Verified price</span>
                </label>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={savePrice}
                className="flex items-center gap-1.5 rounded-xl bg-green-600 px-4 py-2 text-xs font-bold text-white transition-all hover:bg-green-700 active:scale-[0.98]"
              >
                <CheckCircle2 className="h-3.5 w-3.5" /> {editingPrice ? 'Save Changes' : 'Add Price'}
              </button>
              <button
                onClick={() => setShowPriceForm(false)}
                className="flex items-center gap-1 rounded-xl border border-slate-200 px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-50"
              >
                <X className="h-3.5 w-3.5" /> Cancel
              </button>
            </div>
          </div>
        )}

        {loading ? (
          <div className="flex items-center justify-center py-10">
            <Loader2 className="h-6 w-6 animate-spin text-green-600" />
          </div>
        ) : prices.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-10 text-center">
            <Inbox className="mb-2 h-9 w-9 text-slate-300" />
            <p className="text-sm font-medium text-slate-500">No market prices yet</p>
          </div>
        ) : (
          <div className="max-h-[560px] overflow-y-auto pr-1">
            <table className="w-full text-left">
              <thead className="sticky top-0 bg-white">
                <tr className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                  <th className="py-2 pr-3">Crop</th>
                  <th className="py-2 pr-3">Price</th>
                  <th className="py-2 pr-3">Location</th>
                  <th className="py-2 pr-3">Trend</th>
                  <th className="py-2 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {prices.map((p) => (
                  <tr key={p.id} className="text-sm">
                    <td className="py-2.5 pr-3">
                      <p className="font-semibold text-slate-900">{p.crop}</p>
                      <p className="text-[11px] text-slate-400">{p.crop_category}</p>
                    </td>
                    <td className="py-2.5 pr-3 font-bold text-slate-900">
                      ₦{Number(p.price).toLocaleString()}
                      <span className="block text-[10px] font-medium text-slate-400">{p.unit}</span>
                    </td>
                    <td className="py-2.5 pr-3">
                      <p className="text-slate-700">{p.location || '-'}</p>
                      <p className="text-[11px] text-slate-400">{p.zone}</p>
                    </td>
                    <td className="py-2.5 pr-3">
                      <span
                        className={`rounded-full px-2 py-0.5 text-[10px] font-black uppercase ${
                          p.trend === 'up'
                            ? 'bg-green-100 text-green-700'
                            : p.trend === 'down'
                            ? 'bg-red-100 text-red-600'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {p.trend} {p.change}
                      </span>
                    </td>
                    <td className="py-2.5 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => openEditPrice(p)}
                          className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-slate-100 hover:text-blue-600"
                        >
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => removePrice(p)}
                          className="rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}