import React, { useCallback, useEffect, useState } from 'react';
import { toast } from 'sonner';
import {
  MessageCircleQuestion,
  RefreshCw,
  Loader2,
  CheckCircle2,
  Video,
  Image,
  Inbox,
  Send,
  Trash2,
} from 'lucide-react';
import {
  fetchConsultationsAdmin,
  saveConsultationResponse,
  deleteConsultation,
  logAudit,
} from '@/components/admin/admin-api';

interface ConsultationRow {
  id: string;
  question: string;
  language: string;
  media_type: string;
  media_urls: string[];
  media_names: string[];
  ai_response: string | null;
  status: string;
  created_at: string;
}

export default function AdminConsultationPanel() {
  const [consultations, setConsultations] = useState<ConsultationRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [replyDrafts, setReplyDrafts] = useState<Record<string, string>>({});
  const [replyingId, setReplyingId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      setConsultations(await fetchConsultationsAdmin(80));
    } catch (error: any) {
      toast.error(error.message || 'Failed to load consultations');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const submitReply = async (id: string) => {
    const response = (replyDrafts[id] || '').trim();
    if (!response) {
      toast.error('Write an answer before sending');
      return;
    }
    setReplyingId(id);
    try {
      await saveConsultationResponse(id, response, 'reviewed');
      await logAudit('Admin', 'answered inquiry', `Replied to consultation ${id}`);
      toast.success('Answer published to farmer');
      setReplyDrafts((d) => ({ ...d, [id]: '' }));
      await load();
    } catch (error: any) {
      toast.error(error.message || 'Failed to save answer');
    } finally {
      setReplyingId(null);
    }
  };

  const remove = async (id: string) => {
    try {
      await deleteConsultation(id);
      await logAudit('Admin', 'deleted inquiry', `Removed consultation ${id}`);
      toast.success('Inquiry removed');
      await load();
    } catch (error: any) {
      toast.error(error.message || 'Failed to delete');
    }
  };

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="flex items-center gap-2 text-base font-bold text-slate-900">
          <MessageCircleQuestion className="h-5 w-5 text-green-600" />
          Farmer Questions ({consultations.length})
        </h2>
        <button
          onClick={load}
          disabled={loading}
          className="flex items-center gap-2 rounded-xl border border-slate-200 px-4 py-2 text-sm font-bold text-slate-600 transition-all hover:bg-slate-50"
        >
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
          Refresh
        </button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-6 w-6 animate-spin text-green-600" />
        </div>
      ) : consultations.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <Inbox className="mb-3 h-10 w-10 text-slate-300" />
          <p className="text-sm font-medium text-slate-500">
            No consultations yet. Farmers will see their questions here once they ask SAI.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {consultations.map((c) => (
            <div key={c.id} className="rounded-xl border border-slate-100 bg-slate-50/50 p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <p className="text-sm font-semibold text-slate-900">{c.question}</p>
                  <p className="mt-1 text-[11px] text-slate-500">
                    {new Date(c.created_at).toLocaleString()} · {c.language === 'ha' ? 'Hausa' : 'English'} ·{' '}
                    {c.media_type}
                  </p>
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  <span
                    className={`rounded-full px-3 py-1 text-[11px] font-black uppercase tracking-wider ${
                      c.status === 'answered' || c.status === 'reviewed'
                        ? 'bg-green-100 text-green-700'
                        : 'bg-amber-100 text-amber-700'
                    }`}
                  >
                    {c.status}
                  </span>
                  <button
                    onClick={() => remove(c.id)}
                    className="rounded-lg p-1.5 text-slate-400 transition-all hover:bg-red-50 hover:text-red-500"
                    title="Delete inquiry"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>

              {c.media_urls && c.media_urls.length > 0 && (
                <div className="mt-3 flex flex-wrap gap-2">
                  {c.media_urls.map((url, idx) => {
                    const name = c.media_names?.[idx] || `media-${idx}`;
                    const looksVideo = /video|\.mp4|\.webm|\.mov|\.mkv/i.test(name);
                    return looksVideo ? (
                      <a
                        key={idx}
                        href={url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 rounded-lg bg-purple-50 px-3 py-2 text-xs font-bold text-purple-700 transition-all hover:bg-purple-100"
                      >
                        <Video className="h-4 w-4" /> {name}
                      </a>
                    ) : (
                      <a
                        key={idx}
                        href={url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="relative block h-16 w-16 overflow-hidden rounded-lg border border-slate-200 transition-all hover:scale-105"
                      >
                        <Image className="absolute inset-0 m-auto h-5 w-5 text-slate-300" />
                        <img src={url} alt={name} className="relative h-full w-full object-cover" />
                      </a>
                    );
                  })}
                </div>
              )}

              {c.ai_response ? (
                <div className="mt-3 rounded-xl border border-green-100 bg-green-50 p-3">
                  <p className="mb-1 text-[10px] font-black uppercase tracking-wider text-green-700">
                    Published Answer
                  </p>
                  <p className="whitespace-pre-wrap text-sm text-slate-800">{c.ai_response}</p>
                </div>
              ) : (
                <div className="mt-3 flex gap-2">
                  <textarea
                    value={replyDrafts[c.id] || ''}
                    onChange={(e) => setReplyDrafts((d) => ({ ...d, [c.id]: e.target.value }))}
                    placeholder="Write the farmer's answer here…"
                    rows={2}
                    className="flex-1 resize-none rounded-xl border border-slate-200 bg-white p-3 text-sm outline-none transition-all focus:border-green-400 focus:ring-2 focus:ring-green-100"
                  />
                  <button
                    onClick={() => submitReply(c.id)}
                    disabled={replyingId === c.id}
                    className="flex items-center gap-2 self-end rounded-xl bg-green-600 px-4 py-2 text-xs font-bold text-white transition-all hover:bg-green-700 active:scale-[0.98] disabled:opacity-50"
                  >
                    {replyingId === c.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                    Send
                  </button>
                </div>
              )}

              {!c.ai_response && (
                <div className="mt-2 flex justify-end">
                  <button
                    onClick={() => submitReply(c.id)}
                    className="flex items-center gap-2 rounded-xl border border-green-200 bg-green-50 px-3 py-1.5 text-[11px] font-bold text-green-700 transition-all hover:bg-green-100"
                  >
                    <CheckCircle2 className="h-3.5 w-3.5" /> Mark Answered
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}