import { useMemo } from 'react';
import { motion } from 'framer-motion';
import type { FarmerRecord, Language } from '@/types/agro';
import { CROPS, WEATHER_DATA, PEST_DATABASE, GEO_ZONES, MARKETS } from '@/data/nigeriaAgroData';
import { Sun, CloudRain, Thermometer, Droplet, Wind, Bug, CalendarDays, TrendingUp, BarChart3, Share2, Printer, Leaf, ShieldCheck } from 'lucide-react';

const STATE_TO_ZONE: Record<string, string> = {
  Sokoto: 'Sahel', Kebbi: 'Sahel', Zamfara: 'Sahel', Katsina: 'Sahel', Jigawa: 'Sahel', Yobe: 'Sahel', Borno: 'Sahel',
  Kaduna: 'Sudan Savanna', Kano: 'Sudan Savanna', Bauchi: 'Sudan Savanna', Gombe: 'Sudan Savanna', Nasarawa: 'Sudan Savanna',
  Niger: 'Guinea Savanna', Kwara: 'Guinea Savanna', Plateau: 'Guinea Savanna', Benue: 'Guinea Savanna', 'FCT Abuja': 'Guinea Savanna',
  Ebonyi: 'High Guinea', Enugu: 'High Guinea', Anambra: 'High Guinea', Imo: 'High Guinea', Abia: 'High Guinea', 'Cross River': 'High Guinea',
  Lagos: 'Rainforest', Ogun: 'Rainforest', Ondo: 'Rainforest', Edo: 'Rainforest', Delta: 'Rainforest', Rivers: 'Rainforest', 'Akwa Ibom': 'Rainforest',
  Bayelsa: 'Mangrove/Coastal',
};

function getZone(state: string): string {
  for (const [zones, zone] of Object.entries(STATE_TO_ZONE)) {
    if (zones.includes(state)) return zone;
  }
  return 'Guinea Savanna';
}

function getAdvisory(farmer: FarmerRecord) {
  const zone = getZone(farmer.state);
  const weather = WEATHER_DATA[zone];
  const cropDef = CROPS.find(c => c.name === farmer.primaryCrop);
  const pests = cropDef ? PEST_DATABASE.filter(p => p.affectedCrops.includes(farmer.primaryCrop)) : [];
  const marketPrices = MARKETS.filter(m => m.crop === farmer.primaryCrop);
  const daysToHarvest = cropDef ? cropDef.daysToHarvest : 6;
  const harvestMonths = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const plantMonth = farmer.plantingDate ? new Date(farmer.plantingDate).getMonth() : 3;
  const harvestMonthIdx = Math.min(plantMonth + daysToHarvest, 11);
  const estimatedYield = cropDef ? cropDef.yieldPerHectare : 'Varies';
  const potentialRevenue = marketPrices.length > 0 && farmer.farmSizeHectares > 0
    ? `₦${Math.round(marketPrices[0].pricePerTon * farmer.farmSizeHectares * 0.5).toLocaleString()} - ₦${Math.round(marketPrices[0].pricePerTon * farmer.farmSizeHectares).toLocaleString()}`
    : 'N/A';

  return { weather, cropDef, pests, marketPrices, harvestMonth: harvestMonths[harvestMonthIdx], estimatedYield, potentialRevenue, zone };
}

export function AiAgroEngine({ farmer, language }: { farmer: FarmerRecord | null; language: Language }) {
  const advisory = useMemo(() => farmer ? getAdvisory(farmer) : null, [farmer]);

  const t = {
    en: {
      title: 'AI Agro-Engine',
      subtitle: 'Automated intelligent analysis for your farm — weather, production planning, pest control, and market intelligence.',
      noFarmer: 'No farmer selected',
      noFarmerMsg: 'Register or select a farmer to see AI-powered advisory.',
      weather: 'Microclimate & Weather',
      rainWindow: 'Rain Window',
      advisory: 'Advisory',
      production: 'Production & Harvest Plan',
      pestControl: 'Pest & Disease Detection',
      market: 'Market Intelligence',
      yield: 'Estimated Yield',
      revenue: 'Potential Revenue',
      fertilizer: 'Fertilizer Schedule',
      organic: 'Organic Treatment',
      chemical: 'Chemical Treatment',
      share: 'Share Advisory',
      print: 'Print Report',
      trendUp: 'Trending Up',
      trendDown: 'Trending Down',
      stable: 'Stable',
      demand: 'Demand',
      severity: 'Severity',
      low: 'Low', medium: 'Medium', high: 'High',
    },
    ha: {
      title: 'Injiniyar AI ta Noma',
      subtitle: 'Bincike mai hankali na otomatiki don faranka — yanayi, tsarin samarwa, kula da cututtuka, da kasida.',
      noFarmer: 'Ba a zaɓar manoma ba',
      noFarmerMsg: 'Ƙaddama ko zaɓi manoma don ganin shawarwarci na AI.',
      weather: 'Yanayi da Yanayi',
      rainWindow: 'Rukunin Ruwa',
      advisory: 'Shawara',
      production: 'Tsarin Samarwa da Girbi',
      pestControl: 'Gano Cututtuka',
      market: 'Kasida',
      yield: 'An ƙididdige Samuwa',
      revenue: 'Kuɗin Da ake Zaton',
      fertilizer: 'Kwanakin Gyada',
      organic: 'Magani na Halitta',
      chemical: 'Magani na Sinadarai',
      share: 'Raba Shawara',
      print: 'Bugawa',
      trendUp: 'Ya Karu',
      trendDown: 'Ya Rage',
      stable: 'Yana Tsaye',
      demand: 'Buƙata',
      severity: 'Matukar Matsala',
      low: 'Ƙarami', medium: 'Tsakiya', high: 'Mafi Girma',
    },
  }[language];

  if (!farmer || !advisory) {
    return (
      <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-16 text-center">
        <Leaf className="mb-4 h-12 w-12 text-slate-300" />
        <h3 className="text-lg font-semibold text-slate-600">{t.noFarmer}</h3>
        <p className="mt-1 text-sm text-slate-400">{t.noFarmerMsg}</p>
      </div>
    );
  }

  const { weather, cropDef, pests, marketPrices, harvestMonth, estimatedYield, potentialRevenue, zone } = advisory;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="rounded-2xl border border-emerald-200 bg-gradient-to-br from-emerald-50 to-white p-6">
        <h2 className="text-xl font-bold text-emerald-900">{t.title}</h2>
        <p className="text-sm text-emerald-700 mt-1">{farmer.fullName} · {farmer.state} · {farmer.primaryCrop}</p>
        <div className="mt-3 flex gap-2">
          <button onClick={() => window.print()} className="flex items-center gap-1 rounded-md border border-emerald-300 bg-white px-3 py-1.5 text-xs font-medium text-emerald-700 hover:bg-emerald-50">
            <Printer className="h-3.5 w-3.5" />{t.print}
          </button>
          <button onClick={() => { navigator.clipboard?.writeText(`${t.title}: ${farmer.primaryCrop} advisory for ${farmer.state}`); }} className="flex items-center gap-1 rounded-md border border-emerald-300 bg-white px-3 py-1.5 text-xs font-medium text-emerald-700 hover:bg-emerald-50">
            <Share2 className="h-3.5 w-3.5" />{t.share}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weather Card */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="flex items-center gap-2 mb-4">
            <CloudRain className="h-5 w-5 text-blue-500" />
            <h3 className="font-semibold text-slate-900">{t.weather}</h3>
            <span className="ml-auto rounded-full bg-blue-100 px-2.5 py-0.5 text-xs font-medium text-blue-700">{zone}</span>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="flex items-center gap-2 rounded-lg bg-orange-50 p-3">
              <Thermometer className="h-4 w-4 text-orange-500" />
              <div><p className="text-xs text-slate-500">Temperature</p><p className="text-sm font-bold text-slate-900">{weather.temperature}</p></div>
            </div>
            <div className="flex items-center gap-2 rounded-lg bg-blue-50 p-3">
              <Droplet className="h-4 w-4 text-blue-500" />
              <div><p className="text-xs text-slate-500">Humidity</p><p className="text-sm font-bold text-slate-900">{weather.humidity}</p></div>
            </div>
            <div className="flex items-center gap-2 rounded-lg bg-green-50 p-3">
              <CloudRain className="h-4 w-4 text-green-500" />
              <div><p className="text-xs text-slate-500">Rainfall</p><p className="text-sm font-bold text-slate-900">{weather.rainfall}</p></div>
            </div>
            <div className="flex items-center gap-2 rounded-lg bg-sky-50 p-3">
              <Wind className="h-4 w-4 text-sky-500" />
              <div><p className="text-xs text-slate-500">Wind</p><p className="text-sm font-bold text-slate-900">{weather.windSpeed}</p></div>
            </div>
          </div>
          <div className="mt-3 rounded-lg bg-blue-50 p-3">
            <p className="text-xs font-semibold text-blue-700 mb-1">{t.rainWindow}</p>
            <p className="text-sm text-blue-900">{weather.rainWindow}</p>
          </div>
          <div className="mt-2 rounded-lg bg-amber-50 p-3">
            <p className="text-xs font-semibold text-amber-700 mb-1">{t.advisory}</p>
            <p className="text-sm text-amber-900">{weather.advisory}</p>
          </div>
        </motion.div>

        {/* Production Plan */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="flex items-center gap-2 mb-4">
            <CalendarDays className="h-5 w-5 text-emerald-500" />
            <h3 className="font-semibold text-slate-900">{t.production}</h3>
          </div>
          <div className="space-y-3">
            {[
              { phase: language === 'en' ? 'Land Preparation' : 'Shirye-shiryen Ƙasa', month: 'Week 1-2' },
              { phase: language === 'en' ? 'Planting' : 'Shuka', month: 'Week 3' },
              { phase: language === 'en' ? 'First Weeding' : 'Gaggarawa Ta Farko', month: 'Week 4-6' },
              { phase: language === 'en' ? 'Fertilizer Application' : 'Amfani da Gyada', month: cropDef ? `Week ${Math.ceil(cropDef.daysToHarvest * 4)} (${cropDef.fertilizerFormula})` : 'Week 6-8' },
              { phase: language === 'en' ? 'Second Weeding' : 'Gaggarawa Ta Biyu', month: 'Week 8-10' },
              { phase: language === 'en' ? 'Harvest Target' : 'Kwanakin Girbi', month: harvestMonth },
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="flex h-6 w-6 items-center justify-center rounded-full bg-emerald-100 text-xs font-bold text-emerald-700">{i + 1}</div>
                <div className="flex-1"><p className="text-sm font-medium text-slate-800">{item.phase}</p></div>
                <span className="rounded-full bg-slate-100 px-2.5 py-0.5 text-xs text-slate-600">{item.month}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 grid grid-cols-2 gap-3">
            <div className="rounded-lg bg-emerald-50 p-3">
              <p className="text-xs text-emerald-600">{t.yield}</p>
              <p className="text-lg font-bold text-emerald-900">{estimatedYield}/ha</p>
            </div>
            <div className="rounded-lg bg-amber-50 p-3">
              <p className="text-xs text-amber-600">{t.revenue}</p>
              <p className="text-lg font-bold text-amber-900">{potentialRevenue}</p>
            </div>
          </div>
        </motion.div>

        {/* Pest Control */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
          className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm lg:col-span-2">
          <div className="flex items-center gap-2 mb-4">
            <Bug className="h-5 w-5 text-red-500" />
            <h3 className="font-semibold text-slate-900">{t.pestControl}</h3>
            {pests.length === 0 && <span className="ml-auto text-xs text-slate-400">{language === 'en' ? 'No major pests detected' : 'Babu cututtuka'}</span>}
          </div>
          {pests.length === 0 ? (
            <p className="text-sm text-slate-500">{language === 'en' ? 'No specific pest threats identified for this crop.' : 'Babu takurawan cututtuka da aka gano.'}</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {pests.map((pest, i) => (
                <div key={i} className="rounded-xl border border-slate-100 bg-slate-50 p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold text-slate-900">{pest.pestName}</h4>
                    <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                      pest.severity === 'high' ? 'bg-red-100 text-red-700' : pest.severity === 'medium' ? 'bg-amber-100 text-amber-700' : 'bg-green-100 text-green-700'
                    }`}>{t[pest.severity]}</span>
                  </div>
                  <p className="text-xs text-slate-500 mb-2">{language === 'en' ? 'Symptoms:' : 'Alamu:'} {pest.symptoms.slice(0, 2).join(', ')}</p>
                  <div className="space-y-2">
                    <div className="rounded-lg bg-green-50 p-2.5">
                      <p className="text-[10px] font-semibold uppercase text-green-600 mb-0.5">{t.organic}</p>
                      <p className="text-xs text-green-900">{pest.organicTreatment}</p>
                    </div>
                    <div className="rounded-lg bg-blue-50 p-2.5">
                      <p className="text-[10px] font-semibold uppercase text-blue-600 mb-0.5">{t.chemical}</p>
                      <p className="text-xs text-blue-900">{pest.chemicalTreatment}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </motion.div>

        {/* Market Intelligence */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}
          className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm lg:col-span-2">
          <div className="flex items-center gap-2 mb-4">
            <BarChart3 className="h-5 w-5 text-indigo-500" />
            <h3 className="font-semibold text-slate-900">{t.market}</h3>
            <span className="ml-auto text-xs text-slate-400">{marketPrices.length} markets</span>
          </div>
          {marketPrices.length === 0 ? (
            <p className="text-sm text-slate-500">{language === 'en' ? 'No market data available for this crop yet.' : 'Babu bayanan kasida don wannan shuka.'}</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-200">
                    <th className="text-left py-2 px-3 text-xs font-semibold text-slate-500 uppercase">{language === 'en' ? 'Market' : 'Kasida'}</th>
                    <th className="text-left py-2 px-3 text-xs font-semibold text-slate-500 uppercase">{language === 'en' ? 'Location' : 'Wuri'}</th>
                    <th className="text-right py-2 px-3 text-xs font-semibold text-slate-500 uppercase">₦/100kg</th>
                    <th className="text-right py-2 px-3 text-xs font-semibold text-slate-500 uppercase">7d Δ</th>
                    <th className="text-center py-2 px-3 text-xs font-semibold text-slate-500 uppercase">{t.demand}</th>
                    <th className="text-left py-2 px-3 text-xs font-semibold text-slate-500 uppercase">{language === 'en' ? 'Broker' : 'Mai Sayarwa'}</th>
                  </tr>
                </thead>
                <tbody>
                  {marketPrices.map((m, i) => (
                    <tr key={i} className="border-b border-slate-50 hover:bg-slate-50">
                      <td className="py-2.5 px-3 font-medium text-slate-800">{m.marketName}</td>
                      <td className="py-2.5 px-3 text-slate-500">{m.location}</td>
                      <td className="py-2.5 px-3 text-right font-bold text-slate-900">₦{m.pricePer100kg.toLocaleString()}</td>
                      <td className="py-2.5 px-3 text-right">
                        <span className={`flex items-center justify-end gap-1 ${m.priceDelta7d >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {m.priceDelta7d >= 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingUp className="h-3 w-3 rotate-180" />}
                          {m.priceDelta7d > 0 ? '+' : ''}{m.priceDelta7d}%
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                          m.demandIndex === 'high' ? 'bg-green-100 text-green-700' : m.demandIndex === 'medium' ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-600'
                        }`}>{m.demandIndex.charAt(0).toUpperCase() + m.demandIndex.slice(1)}</span>
                      </td>
                      <td className="py-2.5 px-3 text-xs text-slate-500">{m.brokerContact}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}