import React, { useState, useEffect } from 'react';
import { 
  WifiOff, 
  Smartphone, 
  MessageSquare, 
  Hash, 
  Zap, 
  Database, 
  CheckCircle2,
  RefreshCw,
  Phone,
  ChevronRight,
  Delete,
  Signal,
  Wifi,
  Send,
  BellRing,
  AlertTriangle
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';

interface UssdOption {
  id: string;
  label: string;
  next: string;
}

interface UssdMenuItem {
  title: string;
  options: UssdOption[];
  text?: string;
}

const USSD_MENU: Record<string, UssdMenuItem> = {
  main: {
    title: 'SAI AGRO MENU',
    options: [
      { id: '1', label: 'Weather Advisory', next: 'weather' },
      { id: '2', label: 'Market Intelligence', next: 'market' },
      { id: '3', label: 'Pest & Disease Alert', next: 'pest' },
      { id: '4', label: 'My Farm Status', next: 'farm' },
    ]
  },
  weather: {
    title: 'WEATHER ADVISORY',
    text: `Heavy rain expected in Northern region. Delay Groundnut harvest by 3 days.`,
    options: [{ id: '0', label: 'Back', next: 'main' }]
  },
  market: {
    title: 'MARKET PRICES',
    text: `Groundnut: N28,000/100kg (+2%)
Garlic: N15,500/bag (Stable)`,
    options: [{ id: '0', label: 'Back', next: 'main' }]
  },
  pest: {
    title: 'PEST ALERT',
    text: `No active threats in your zone. Monitor for Fall Armyworm.`,
    options: [{ id: '0', label: 'Back', next: 'main' }]
  },
  farm: {
    title: 'MY FARM STATUS',
    text: `Yahaya Abubakar's Farm
Location: Kano
Registered Crops: 2`,
    options: [{ id: '0', label: 'Back', next: 'main' }]
  }
};

const MOCK_SMS = [
  { id: 1, from: 'SAI-AGRO', text: 'ALERT: Fall Armyworm detected in Oyo. Apply biopesticides now.', date: '10:30 AM' },
  { id: 2, from: 'SAI-AGRO', text: 'MARKET: Maize price in Kano up by 5% to N28,000/100kg.', date: 'Yesterday' },
  { id: 3, from: 'SAI-AGRO', text: 'WEATHER: Heavy rain expected in Benue. Delay harvest.', date: '2 days ago' },
];

export default function MobileServices() {
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [ussdInput, setUssdInput] = useState('');
  const [ussdState, setUssdState] = useState<'idle' | 'loading' | 'menu'>('idle');
  const [currentMenu, setCurrentMenu] = useState<string>('main');
  const [lastSync, setLastSync] = useState(new Date().toLocaleString());
  const [activeTab, setActiveTab] = useState<'pwa' | 'ussd' | 'sms'>('ussd');

  useEffect(() => {
    const handleOnline = () => {
      setIsOffline(false);
      toast.success('Back Online: Synchronizing records...');
      setLastSync(new Date().toLocaleString());
    };
    const handleOffline = () => {
      setIsOffline(true);
      toast.warning('Offline Mode Active: Data saved locally');
    };
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleKeyClick = (key: string) => {
    if (ussdState === 'menu') {
      const menu = USSD_MENU[currentMenu];
      if (menu && menu.options) {
        const option = menu.options.find(opt => opt.id === key);
        if (option) {
          setUssdState('loading');
          setTimeout(() => {
            setCurrentMenu(option.next);
            setUssdState('menu');
          }, 800);
        }
      }
      return;
    }
    setUssdInput(prev => prev + key);
  };

  const handleDial = () => {
    if (ussdInput === '*347*123#') {
      setUssdState('loading');
      setTimeout(() => {
        setUssdState('menu');
        setCurrentMenu('main');
        toast.success('USSD Session Started');
      }, 1500);
    } else if (ussdInput.length > 0) {
      toast.error('Invalid USSD Code for SAI Services');
    }
  };

  const handleExit = () => {
    setUssdState('idle');
    setUssdInput('');
    setCurrentMenu('main');
  };

  const activeMenu = USSD_MENU[currentMenu] || USSD_MENU.main;

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between px-2">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">Connectivity Hub</h2>
          <p className="text-slate-500 font-medium">Bridging the digital divide for rural farmers</p>
        </div>
        <div className="flex items-center gap-3 bg-white p-2 rounded-2xl shadow-sm border border-slate-100">
          <Badge variant={isOffline ? "destructive" : "secondary"} className="rounded-lg font-black uppercase tracking-wider px-3">
            {isOffline ? <WifiOff className="h-3 w-3 mr-2" /> : <Database className="h-3 w-3 mr-2" />}
            {isOffline ? 'Offline' : 'Online Sync'}
          </Badge>
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest hidden sm:inline">
            Last Sync: {lastSync}
          </span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 p-1 bg-slate-200/50 rounded-2xl w-fit mx-2">
        <Button 
          variant={activeTab === 'ussd' ? 'default' : 'ghost'} 
          onClick={() => setActiveTab('ussd')}
          className="rounded-xl font-bold h-10"
        >
          <Hash className="h-4 w-4 mr-2" /> USSD Simulator
        </Button>
        <Button 
          variant={activeTab === 'sms' ? 'default' : 'ghost'} 
          onClick={() => setActiveTab('sms')}
          className="rounded-xl font-bold h-10"
        >
          <MessageSquare className="h-4 w-4 mr-2" /> SMS History
        </Button>
        <Button 
          variant={activeTab === 'pwa' ? 'default' : 'ghost'} 
          onClick={() => setActiveTab('pwa')}
          className="rounded-xl font-bold h-10"
        >
          <Smartphone className="h-4 w-4 mr-2" /> PWA Offline
        </Button>
      </div>

      <div className="grid gap-8 lg:grid-cols-12">
        {/* Main Content Area */}
        <div className="lg:col-span-8 space-y-8">
          {activeTab === 'ussd' && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="grid gap-8 md:grid-cols-2">
              {/* Phone Simulator */}
              <div className="mx-auto w-full max-w-[320px]">
                <Card className="border-[12px] border-slate-800 bg-slate-900 rounded-[3rem] shadow-2xl overflow-hidden aspect-[9/18.5] relative">
                  <div className="p-4 flex flex-col h-full">
                    {/* Status Bar */}
                    <div className="flex justify-between items-center text-[10px] font-bold text-slate-400 px-2 pt-2 mb-6">
                      <span>9:41</span>
                      <div className="flex gap-1 items-center">
                        <Signal className="h-3 w-3" />
                        <span className="uppercase tracking-tighter">SAI Net</span>
                        <Wifi className="h-3 w-3" />
                      </div>
                    </div>

                    {/* Screen content */}
                    <div className="flex-1 bg-slate-800/50 rounded-2xl border border-white/5 p-6 flex flex-col items-center justify-center text-center relative overflow-hidden">
                      <AnimatePresence mode="wait">
                        {ussdState === 'idle' && (
                          <motion.div key="idle" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="w-full">
                            <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4">Service Provider: SAI</p>
                            <div className="text-3xl font-black text-green-500 tracking-tighter">{ussdInput || "Dial Code"}</div>
                          </motion.div>
                        )}

                        {ussdState === 'loading' && (
                          <motion.div key="loading" className="flex flex-col items-center">
                            <RefreshCw className="h-10 w-10 text-green-500 animate-spin mb-4" />
                            <p className="text-sm font-bold text-slate-400 uppercase tracking-widest">Requesting...</p>
                          </motion.div>
                        )}

                        {ussdState === 'menu' && (
                          <motion.div key="menu" initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="w-full text-left">
                            <h4 className="text-[10px] font-black text-green-500 uppercase tracking-[0.2em] mb-4 text-center border-b border-white/10 pb-2">
                              {activeMenu.title}
                            </h4>
                            {activeMenu.text && (
                              <p className="text-xs font-medium text-slate-200 mb-6 leading-relaxed whitespace-pre-line">
                                {activeMenu.text}
                              </p>
                            )}
                            <div className="space-y-2">
                              {activeMenu.options.map(opt => (
                                <div key={opt.id} className="text-xs font-bold text-slate-300 py-1 px-2 rounded-lg bg-white/5">
                                  {opt.id}. {opt.label}
                                </div>
                              ))}
                            </div>
                            <Button 
                              size="sm" 
                              onClick={handleExit}
                              className="mt-8 w-full bg-slate-700 hover:bg-slate-600 text-[10px] font-black uppercase tracking-widest rounded-xl"
                            >
                              Exit Service
                            </Button>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>

                    {/* Keypad */}
                    <div className="grid grid-cols-3 gap-3 p-4">
                      {['1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '0', '#'].map(key => (
                        <button 
                          key={key} 
                          onClick={() => handleKeyClick(key)}
                          className="aspect-square rounded-full bg-slate-800 text-white font-black text-lg hover:bg-slate-700 active:scale-95 transition-all"
                        >
                          {key}
                        </button>
                      ))}
                      <div className="col-start-2">
                        <button 
                          onClick={handleDial} 
                          className="aspect-square w-full rounded-full bg-green-600 flex items-center justify-center hover:bg-green-500 active:scale-95 transition-all shadow-lg shadow-green-900/40"
                        >
                          <Phone className="h-6 w-6 text-white fill-current" />
                        </button>
                      </div>
                      <div>
                         <button 
                          onClick={() => setUssdInput(prev => prev.slice(0, -1))} 
                          className="aspect-square w-full rounded-full bg-slate-800 flex items-center justify-center hover:bg-slate-700 active:scale-95 transition-all"
                        >
                          <Delete className="h-5 w-5 text-slate-400" />
                        </button>
                      </div>
                    </div>
                  </div>
                </Card>
              </div>

              {/* Details & Status */}
              <div className="space-y-6">
                <Card className="border-none shadow-xl bg-white p-6 rounded-3xl">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="h-10 w-10 rounded-xl bg-amber-100 flex items-center justify-center">
                      <AlertTriangle className="h-5 w-5 text-amber-600" />
                    </div>
                    <div>
                      <h3 className="text-lg font-black text-slate-900">System Notice</h3>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Yahaya Abubakar, Founder</p>
                    </div>
                  </div>
                  <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 space-y-3">
                    <p className="text-sm font-medium text-slate-600 leading-relaxed">
                      The real USSD code <strong className="text-slate-900">*347*123#</strong> is currently in <span className="text-amber-600 font-bold uppercase text-[10px] tracking-widest">Beta Testing</span>.
                    </p>
                    <p className="text-xs text-slate-500">
                      If you see "Service Not Available" on your physical phone, it is because we are finalizing the gateway registration with Nigerian telcos (MTN, Airtel, Glo).
                    </p>
                    <div className="flex items-center gap-2 pt-2">
                      <Badge className="bg-green-100 text-green-700 hover:bg-green-100 border-none">Simulation Active</Badge>
                      <Badge variant="outline" className="border-slate-200 text-slate-400">v0.4.1</Badge>
                    </div>
                  </div>
                </Card>

                <Card className="border-none shadow-xl bg-white p-6 rounded-3xl">
                  <h4 className="text-sm font-black uppercase tracking-widest text-slate-400 mb-4">Quick Dial Menu</h4>
                  <div className="space-y-2">
                    {[
                      { label: 'Check Balance', code: '*347*123#' },
                      { label: 'Market Prices', code: '*347*123*1#' },
                      { label: 'Weather Report', code: '*347*123*2#' }
                    ].map(item => (
                      <button 
                        key={item.label}
                        onClick={() => { setUssdInput(item.code); setUssdState('idle'); }}
                        className="w-full flex items-center justify-between p-4 rounded-2xl bg-slate-50 hover:bg-green-50 group transition-all"
                      >
                        <div className="text-left">
                          <p className="text-sm font-black text-slate-900">{item.code}</p>
                          <p className="text-[10px] font-bold text-slate-400 uppercase">{item.label}</p>
                        </div>
                        <ChevronRight className="h-4 w-4 text-slate-300 group-hover:text-green-600 group-hover:translate-x-1 transition-all" />
                      </button>
                    ))}
                  </div>
                </Card>
              </div>
            </motion.div>
          )}

          {activeTab === 'sms' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
               <Card className="border-none shadow-xl bg-white rounded-3xl overflow-hidden h-[600px] flex flex-col">
                  <CardHeader className="bg-slate-50 border-b border-slate-100 px-8 py-6">
                    <CardTitle className="text-xl font-black flex items-center gap-3">
                      <MessageSquare className="h-6 w-6 text-green-600" />
                      SMS Alert Log
                    </CardTitle>
                    <CardDescription className="text-xs font-bold uppercase tracking-widest text-slate-400">Direct connectivity history</CardDescription>
                  </CardHeader>
                  <CardContent className="p-0 flex-1 overflow-hidden">
                    <ScrollArea className="h-full">
                      <div className="p-8 space-y-4">
                        {MOCK_SMS.map(sms => (
                          <div key={sms.id} className="flex gap-6 p-6 rounded-3xl bg-slate-50 border border-slate-100 group transition-all hover:shadow-lg hover:shadow-slate-200/50">
                            <div className="h-12 w-12 rounded-2xl bg-green-100 text-green-700 flex items-center justify-center flex-shrink-0">
                              <Send className="h-6 w-6" />
                            </div>
                            <div className="flex-1">
                              <div className="flex justify-between items-start mb-2">
                                <span className="text-xs font-black uppercase text-slate-400 tracking-[0.2em]">{sms.from}</span>
                                <span className="text-[10px] font-bold text-slate-400 bg-white px-2 py-0.5 rounded-full border border-slate-100">{sms.date}</span>
                              </div>
                              <p className="text-sm font-medium text-slate-900 leading-relaxed">{sms.text}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                  <div className="p-6 bg-slate-50 border-t border-slate-100">
                    <Button className="w-full rounded-2xl bg-white text-slate-900 font-black border shadow-sm hover:bg-slate-50">
                      <RefreshCw className="h-4 w-4 mr-2" /> Refresh Logs
                    </Button>
                  </div>
               </Card>
            </motion.div>
          )}

          {activeTab === 'pwa' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8">
              <Card className="overflow-hidden border-none shadow-xl bg-white group">
                <div className="relative h-64 w-full overflow-hidden">
                  <img 
                    src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/c3334ad1-aa6c-4426-a799-f909ae46d2b5/offline-synchronization-service-890c8ac5-1782693345242.webp" 
                    alt="Offline Sync" 
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/90 via-slate-900/40 to-transparent" />
                  <div className="absolute bottom-8 left-8">
                    <Badge className="bg-green-500 text-white font-black uppercase tracking-widest mb-3 border-none">Core Tech</Badge>
                    <h3 className="text-3xl font-black text-white tracking-tight">PWA Offline Engine</h3>
                  </div>
                </div>
                <CardContent className="p-8">
                  <div className="grid gap-8 md:grid-cols-2">
                    <div className="space-y-6">
                      <p className="text-slate-600 font-medium leading-relaxed">
                        SAI uses <strong className="text-slate-900">Progressive Web App</strong> technology to ensure you never lose access to your farm data, even in the middle of a field with zero signal.
                      </p>
                      <div className="space-y-3">
                        {[
                          'Local database storage (IndexedDB)',
                          'Asset caching for instant loads',
                          'Automatic background sync to Supabase',
                          'Add to Home Screen capability'
                        ].map((item, i) => (
                          <div key={i} className="flex items-center gap-3 text-sm font-bold text-slate-700">
                            <CheckCircle2 className="h-5 w-5 text-green-600" /> {item}
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className="bg-slate-50 rounded-[2rem] p-8 border border-slate-100 flex flex-col justify-between">
                       <div>
                          <h5 className="text-xs font-black uppercase text-slate-400 tracking-widest mb-4">Sync Control</h5>
                          <div className="flex items-center justify-between p-4 bg-white rounded-2xl border mb-4">
                            <div className="space-y-0.5">
                              <p className="text-sm font-black">Automatic Sync</p>
                              <p className="text-[10px] text-slate-500 font-bold uppercase">Works on 2G/3G/WiFi</p>
                            </div>
                            <Switch defaultChecked />
                          </div>
                       </div>
                       <Button className="w-full rounded-2xl bg-green-600 font-black h-12 shadow-lg shadow-green-600/20">
                         <RefreshCw className="h-4 w-4 mr-2" /> Force Manual Sync
                       </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </div>

        {/* Sidebar Info */}
        <div className="lg:col-span-4 space-y-6">
          <Card className="border-none shadow-xl bg-slate-900 text-white p-8 rounded-[2.5rem]">
            <h3 className="text-2xl font-black mb-4 tracking-tight">Why Connectivity Hub?</h3>
            <p className="text-slate-400 font-medium leading-relaxed mb-8">
              In Nigeria, over 60% of smallholder farmers lack stable internet. SAI ensures equity by providing three distinct access layers.
            </p>
            
            <div className="space-y-6">
              {[
                { icon: Smartphone, title: 'Smart Layer', desc: 'Full app via WiFi/4G' },
                { icon: Zap, title: 'Light Layer', desc: 'Offline PWA mode' },
                { icon: Hash, title: 'Deep Layer', desc: 'USSD/SMS for basic phones' }
              ].map((item, i) => (
                <div key={i} className="flex items-start gap-4 p-4 rounded-2xl bg-white/5 border border-white/5">
                  <div className="h-10 w-10 rounded-xl bg-green-500/20 flex items-center justify-center flex-shrink-0">
                    <item.icon className="h-5 w-5 text-green-400" />
                  </div>
                  <div>
                    <p className="text-sm font-black text-white">{item.title}</p>
                    <p className="text-xs text-slate-500 font-medium">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="border-none shadow-xl bg-green-50 p-8 rounded-[2.5rem] border border-green-100">
            <div className="h-12 w-12 rounded-2xl bg-green-600 flex items-center justify-center mb-6">
              <BellRing className="h-6 w-6 text-white" />
            </div>
            <h3 className="text-xl font-black text-green-900 mb-4">SMS Alert Subscription</h3>
            <p className="text-sm font-medium text-green-800/70 mb-6">
              Enter your mobile number to receive critical pest and weather alerts via SMS.
            </p>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label className="text-[10px] font-black uppercase text-green-800/50 ml-1">Nigeria (+234)</Label>
                <input 
                  type="tel" 
                  placeholder="803 000 0000" 
                  className="w-full bg-white border-green-200 rounded-2xl py-3 px-4 text-sm font-bold focus:outline-none focus:ring-2 focus:ring-green-500/20 transition-all"
                />
              </div>
              <Button className="w-full rounded-2xl bg-green-700 text-white font-black h-12 hover:bg-green-800">
                Activate SMS Alerts
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}