import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import type { Language } from '@/types/agro';
import { Leaf, Globe, Menu, X, Bell, ChevronDown } from 'lucide-react';

const NAV_ITEMS_EN = [
  { id: 'onboarding', label: 'Farmer Onboarding' },
  { id: 'engine', label: 'AI Farm Engine' },
  { id: 'market', label: 'Market Intelligence' },
  { id: 'ussd', label: 'USSD Simulator' },
  { id: 'admin', label: 'Admin Dashboard' },
];

const NAV_ITEMS_HA = [
  { id: 'onboarding', label: 'Rajistar Manoma' },
  { id: 'engine', label: 'Injiniyar Noma AI' },
  { id: 'market', label: 'Kasuwancin Kasida' },
  { id: 'ussd', label: 'Simulator USSD' },
  { id: 'admin', label: 'Gudanar Gida' },
];

const ALERTS_EN = ['🌾 Maize prices surge 12% in Lagos markets', '⚠️ Fall Armyworm alert: Benue & Taraba states', '📊 New rice spot prices updated for Wadata Makurdi'];
const ALERTS_HA = ['🌾 Farashin ruma ya karu da 12% a kasuwannin Legas', '⚠️ Labarin Fall Armyworm: Benue da Taraba', '📊 Sabbin farashin gono an sabunta su don Wadata Makurdi'];

export function Navbar({ language, setLanguage, activeTab, setActiveTab }: {
  language: Language;
  setLanguage: (l: Language) => void;
  activeTab: string;
  setActiveTab: (t: string) => void;
}) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const items = language === 'en' ? NAV_ITEMS_EN : NAV_ITEMS_HA;
  const alerts = language === 'en' ? ALERTS_EN : ALERTS_HA;
  const [alertIdx, setAlertIdx] = useState(0);

  return (
    <header className="sticky top-0 z-50 border-b border-emerald-100 bg-white/95 backdrop-blur-sm">
      {/* Alert Ticker */}
      <div className="bg-emerald-800 text-emerald-50 overflow-hidden">
        <div className="flex items-center px-4 py-1.5 text-xs">
          <Bell className="mr-2 h-3 w-3 flex-shrink-0" />
          <AnimatePresence mode="wait">
            <motion.p
              key={alertIdx}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
              className="truncate"
            >
              {alerts[alertIdx]}
            </motion.p>
          </AnimatePresence>
          <button
            onClick={() => setAlertIdx((alertIdx + 1) % alerts.length)}
            className="ml-auto flex-shrink-0 hover:text-emerald-200"
          >
            <ChevronDown className="h-3 w-3" />
          </button>
        </div>
      </div>

      {/* Main Nav */}
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
        <div className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-700">
            <Leaf className="h-5 w-5 text-white" />
          </div>
          <div className="hidden sm:block">
            <h1 className="text-sm font-bold text-emerald-900 leading-tight">NaijaAgro Intelligence</h1>
            <p className="text-[10px] text-emerald-600 leading-tight">{language === 'en' ? 'Dandalin Manoma' : 'Platform na Manoma'}</p>
          </div>
        </div>

        {/* Desktop Tabs */}
        <div className="hidden md:flex items-center gap-1">
          {items.map(item => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${
                activeTab === item.id
                  ? 'bg-emerald-100 text-emerald-800'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* Right Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setLanguage(language === 'en' ? 'ha' : 'en')}
            className="flex items-center gap-1 rounded-md border border-slate-200 px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
          >
            <Globe className="h-3.5 w-3.5" />
            {language === 'en' ? 'Hausa' : 'English'}
          </button>
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden rounded-md p-2 text-slate-600 hover:bg-slate-100"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="md:hidden overflow-hidden border-t border-slate-100"
          >
            <div className="flex flex-col gap-1 p-3">
              {items.map(item => (
                <button
                  key={item.id}
                  onClick={() => { setActiveTab(item.id); setMobileOpen(false); }}
                  className={`rounded-md px-3 py-2 text-left text-sm font-medium transition-colors ${
                    activeTab === item.id
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
