import React, { useState, useEffect } from 'react';
import { 
  Handshake, 
  Building, 
  Users, 
  Briefcase, 
  Landmark, 
  Scale,
  CheckCircle2,
  Loader2,
  AlertTriangle,
  Mail,
  Phone,
  MapPin,
  Star,
  FileText
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DEFAULT_PARTNERSHIPS, type PartnershipRecord, fetchPartnerships, submitPartnership } from '@/lib/mock-data';
import { useI18n } from '@/lib/i18n';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

const PARTNER_TYPES = [
  { key: 'agribusiness', icon: Building, labelKey: 'partnerAgribusiness', color: 'bg-blue-50 text-blue-700 border-blue-200' },
  { key: 'cooperative', icon: Users, labelKey: 'partnerCooperatives', color: 'bg-green-50 text-green-700 border-green-200' },
  { key: 'buyer', icon: Briefcase, labelKey: 'partnerBuyers', color: 'bg-purple-50 text-purple-700 border-purple-200' },
  { key: 'ngo', icon: Handshake, labelKey: 'partnerNGOs', color: 'bg-amber-50 text-amber-700 border-amber-200' },
  { key: 'government', icon: Landmark, labelKey: 'partnerGovernment', color: 'bg-slate-50 text-slate-700 border-slate-200' },
];

const TYPE_DESCRIPTIONS: Record<string, string> = {
  agribusiness: 'partnerAgriDesc',
  cooperative: 'partnerCoopDesc',
  buyer: 'partnerBuyerDesc',
  ngo: 'partnerNgosDesc',
  government: 'partnerGovDesc',
};

export default function Partnership() {
  const { t } = useI18n();
  const [partners, setPartners] = useState<PartnershipRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('directory');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [showForm, setShowForm] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Form state
  const [formOrgName, setFormOrgName] = useState('');
  const [formType, setFormType] = useState('agribusiness');
  const [formContactPerson, setFormContactPerson] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formState, setFormState] = useState('');
  const [formDesc, setFormDesc] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const data = await fetchPartnerships();
      setPartners(data.length > 0 ? data : DEFAULT_PARTNERSHIPS);
    } catch {
      setPartners(DEFAULT_PARTNERSHIPS);
    } finally {
      setLoading(false);
    }
  };

  const filtered = selectedType === 'all' ? partners : partners.filter(p => p.partnershipType === selectedType);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await submitPartnership({
        orgName: formOrgName,
        partnershipType: formType as PartnershipRecord['partnershipType'],
        contactPerson: formContactPerson,
        contactEmail: formEmail,
        contactPhone: formPhone,
        state: formState,
        description: formDesc,
      });
      toast.success(t('partnershipSubmitted'));
      setShowForm(false);
      setFormOrgName('');
      setFormContactPerson('');
      setFormEmail('');
      setFormPhone('');
      setFormState('');
      setFormDesc('');
      loadData();
    } catch (error: any) {
      toast.error(error.message || t('partnershipError'));
    } finally {
      setSubmitting(false);
    }
  };

  const statusBadge = (status: string) => {
    if (status === 'approved') return <Badge className="bg-green-100 text-green-700 hover:bg-green-100 border-none text-[10px] font-bold uppercase"><CheckCircle2 className="h-3 w-3 mr-1" />Approved</Badge>;
    if (status === 'pending') return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 border-none text-[10px] font-bold uppercase"><Loader2 className="h-3 w-3 mr-1 animate-spin" />Pending</Badge>;
    return <Badge className="bg-red-100 text-red-700 hover:bg-red-100 border-none text-[10px] font-bold uppercase"><AlertTriangle className="h-3 w-3 mr-1" />Rejected</Badge>;
  };

  return (
    <div className="space-y-8 pb-8">
      {/* Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between px-2">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">{t('partnerships')}</h2>
          <p className="text-slate-500 font-medium">Connect with Nigeria's agricultural ecosystem</p>
        </div>
        <Button onClick={() => setShowForm(!showForm)} className="rounded-xl bg-green-600 font-bold h-11 px-6 shadow-lg shadow-green-600/20">
          {showForm ? 'Cancel' : t('applyPartnership')}
        </Button>
      </div>

      {/* Application Form */}
      {showForm && (
        <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xl shadow-slate-100/50">
          <h3 className="text-lg font-black text-slate-900 mb-1">{t('applyPartnership')}</h3>
          <p className="text-sm text-slate-500 mb-6">Fill in your organization details below.</p>
          <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div className="md:col-span-2">
              <Label className="text-sm font-semibold text-slate-700">{t('partnershipType')}</Label>
              <Select value={formType} onValueChange={setFormType}>
                <SelectTrigger className="mt-1 h-11 rounded-xl bg-slate-50 border-none font-medium">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PARTNER_TYPES.map(pt => (
                    <SelectItem key={pt.key} value={pt.key}>{t(pt.labelKey)}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-sm font-semibold text-slate-700">{t('orgName')}</Label>
              <Input required value={formOrgName} onChange={e => setFormOrgName(e.target.value)} className="mt-1 h-11 rounded-xl bg-slate-50 border-none font-medium" placeholder="Organization name" />
            </div>
            <div>
              <Label className="text-sm font-semibold text-slate-700">{t('contactPerson')}</Label>
              <Input required value={formContactPerson} onChange={e => setFormContactPerson(e.target.value)} className="mt-1 h-11 rounded-xl bg-slate-50 border-none font-medium" placeholder="Full name" />
            </div>
            <div>
              <Label className="text-sm font-semibold text-slate-700">{t('contactEmail')}</Label>
              <Input required type="email" value={formEmail} onChange={e => setFormEmail(e.target.value)} className="mt-1 h-11 rounded-xl bg-slate-50 border-none font-medium" placeholder="email@example.com" />
            </div>
            <div>
              <Label className="text-sm font-semibold text-slate-700">{t('contactPhone')}</Label>
              <Input required value={formPhone} onChange={e => setFormPhone(e.target.value)} className="mt-1 h-11 rounded-xl bg-slate-50 border-none font-medium" placeholder="+234 ..." />
            </div>
            <div>
              <Label className="text-sm font-semibold text-slate-700">{t('state')}</Label>
              <Input required value={formState} onChange={e => setFormState(e.target.value)} className="mt-1 h-11 rounded-xl bg-slate-50 border-none font-medium" placeholder="State" />
            </div>
            <div className="md:col-span-2">
              <Label className="text-sm font-semibold text-slate-700">{t('description')}</Label>
              <Textarea required value={formDesc} onChange={e => setFormDesc(e.target.value)} className="mt-1 min-h-[100px] rounded-xl bg-slate-50 border-none font-medium resize-y" placeholder="Describe your organization and what you're looking for..." />
            </div>
            <div className="md:col-span-2">
              <button
                type="submit"
                disabled={submitting}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-green-600 py-3 text-sm font-bold text-white shadow-lg shadow-green-200 transition-all hover:bg-green-700 active:scale-[0.98] disabled:opacity-60"
              >
                {submitting ? <><Loader2 className="h-4 w-4 animate-spin" /> Submitting...</> : <><FileText className="h-4 w-4" /> {t('submitApplication')}</>}
              </button>
            </div>
          </form>
        </motion.div>
      )}

      {/* Partner Type Tabs */}
      <div className="flex flex-wrap gap-2">
        <Button
          variant={selectedType === 'all' ? 'default' : 'outline'}
          className={`rounded-xl font-bold text-sm ${selectedType === 'all' ? 'bg-green-600 shadow-lg shadow-green-600/20' : 'border-slate-200'}`}
          onClick={() => setActiveTab('directory')}
        >
          {t('partnershipDirectory')}
        </Button>
        {PARTNER_TYPES.map(pt => (
          <Button
            key={pt.key}
            variant={selectedType === pt.key ? 'default' : 'outline'}
            className={`rounded-xl font-bold text-sm ${selectedType === pt.key ? 'bg-green-600 shadow-lg shadow-green-600/20' : 'border-slate-200'}`}
            onClick={() => setSelectedType(selectedType === pt.key ? 'all' : pt.key)}
          >
            <pt.icon className="h-4 w-4 mr-1.5" />
            {t(pt.labelKey)}
          </Button>
        ))}
      </div>

      {/* Partner Type Cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {PARTNER_TYPES.map(pt => {
          const count = partners.filter(p => p.partnershipType === pt.key).length;
          return (
            <Card key={pt.key} className={`border-2 transition-all hover:shadow-lg cursor-pointer ${selectedType === pt.key ? 'border-green-500 shadow-md' : 'border-transparent'}`} onClick={() => setSelectedType(selectedType === pt.key ? 'all' : pt.key)}>
              <CardHeader className="pb-3">
                <div className="flex items-center gap-3">
                  <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${pt.color}`}>
                    <pt.icon className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-sm font-black text-slate-900">{t(pt.labelKey)}</CardTitle>
                    <CardDescription className="text-[10px] font-bold">{count} partners</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-slate-500 leading-relaxed">{t(TYPE_DESCRIPTIONS[pt.key])}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Directory */}
      <Card className="border-none bg-white shadow-2xl shadow-slate-200/60 overflow-hidden">
        <CardHeader className="border-b border-slate-50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-xl font-black tracking-tight">{t('partnershipDirectory')}</CardTitle>
              <CardDescription className="text-xs font-bold uppercase tracking-widest text-slate-400">{filtered.length} organizations</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <div className="flex items-center justify-center py-16">
              <Loader2 className="h-8 w-8 animate-spin text-green-600" />
            </div>
          ) : filtered.length === 0 ? (
            <div className="py-12 text-center">
              <p className="text-sm font-semibold text-slate-400">{t('noData')}</p>
            </div>
          ) : (
            <div className="divide-y divide-slate-50">
              {filtered.map((partner, idx) => (
                <motion.div key={partner.id || idx} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.03 }}>
                  <div className="flex flex-col gap-3 p-6 transition-colors hover:bg-green-50/30 sm:flex-row sm:items-center sm:justify-between">
                    <div className="flex items-start gap-4 flex-1">
                      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-green-50 text-green-600">
                        <Star className="h-5 w-5" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="text-sm font-black text-slate-900">{partner.orgName}</h4>
                          {statusBadge(partner.status)}
                        </div>
                        <div className="flex flex-wrap items-center gap-3 mt-1 text-xs text-slate-500">
                          <span className="flex items-center gap-1"><Mail className="h-3 w-3" /> {partner.contactEmail}</span>
                          <span className="flex items-center gap-1"><Phone className="h-3 w-3" /> {partner.contactPhone}</span>
                          <span className="flex items-center gap-1"><MapPin className="h-3 w-3" /> {partner.state}</span>
                        </div>
                        <p className="text-xs text-slate-400 mt-1 line-clamp-1">{partner.description}</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm" className="shrink-0 rounded-xl border-slate-200 font-bold text-xs h-9">
                      {t('viewAllPartners')}
                    </Button>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
