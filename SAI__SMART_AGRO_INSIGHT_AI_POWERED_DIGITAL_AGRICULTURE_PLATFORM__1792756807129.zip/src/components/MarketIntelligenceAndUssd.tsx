import React, { useState } from 'react';
import { TrendingUp, Globe, Phone, MessageSquare, Download, Search, ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { MOCK_MARKET_PRICES as marketPrices } from '@/lib/mock-data';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

export function MarketIntelligenceAndUssd() {
  const [searchQuery, setSearchQuery] = useState('');
  const [ussdCode, setUssdCode] = useState('');
  const [ussdStep, setUssdStep] = useState(0);
  const [ussdResult, setUssdResult] = useState<string | null>(null);

  const filteredPrices = marketPrices.filter(p =>
    p.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.unit.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleUssdSubmit = () => {
    if (!ussdCode) return;
    if (ussdCode === '*384*724#') {
      setUssdResult('SAI Menu:\
1. Check Market Prices\
2. Weather Forecast\
3. Pest Alert\
4. Contact Extension Agent\
\
Reply with option number.');
      setUssdStep(1);
    } else if (ussdStep === 1 && ['1', '2', '3', '4'].includes(ussdCode)) {
      const topPrices = marketPrices.slice(0, 3).map(p => `${p.location}: ₦${p.price.toLocaleString()} (${p.unit})`).join('\
');
      const responses: Record<string, string> = {
        '1': `Top Market Prices:\
${topPrices}`,
        '2': 'Weather for Sokoto: Sunny, 34°C. Advice: Water crops early morning.',
        '3': 'ALERT: Fall Armyworm detected in Sokoto North LGA. Scout your fields immediately.',
        '4': 'Extension Agent: +234 803 SAI NOMA\
Available Mon-Fri, 8am-5pm WAT.',
      };
      setUssdResult(responses[ussdCode] || 'Invalid option. Dial *384*724# again.');
      setUssdStep(2);
    } else {
      setUssdResult('USSD session expired. Dial *384*724# to restart.');
      setUssdStep(0);
    }
    setUssdCode('');
  };

  return (
    <div className="space-y-8 pb-8">
      {/* Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between px-2">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight flex items-center gap-3">
            <TrendingUp className="h-8 w-8 text-green-600" />
            Market Intelligence &amp; USSD
          </h2>
          <p className="text-slate-500 font-medium">Real-time prices and mobile access for all phones</p>
        </div>
        <Button variant="outline" className="rounded-xl font-bold h-11 px-6 border-slate-200">
          <Download className="h-4 w-4 mr-2" /> Export Report
        </Button>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 px-2">
        {[
          { label: 'Markets Tracked', value: new Set(marketPrices.map(p => p.location)).size, icon: Globe, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: 'Price Updates', value: marketPrices.length, icon: TrendingUp, color: 'text-green-600', bg: 'bg-green-50' },
          { label: 'Registered Farmers', value: marketPrices.length * 47, icon: Phone, color: 'text-purple-600', bg: 'bg-purple-50' },
          { label: 'USSD Active', value: '24/7', icon: MessageSquare, color: 'text-amber-600', bg: 'bg-amber-50' },
        ].map((stat) => (
          <Card key={stat.label} className="border-none shadow-lg shadow-slate-200/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-3">
                <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest">{stat.label}</span>
                <div className={cn('h-8 w-8 rounded-lg flex items-center justify-center', stat.bg)}>
                  <stat.icon className={cn('h-4 w-4', stat.color)} />
                </div>
              </div>
              <p className="text-3xl font-black text-slate-900">{stat.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="prices" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-slate-100 rounded-xl p-1">
          {['prices', 'ussd', 'trends'].map(tab => (
            <TabsTrigger key={tab} value={tab} className="rounded-lg font-bold capitalize data-[state=active]:bg-white data-[state=active]:shadow-sm">
              {tab === 'prices' ? 'Market Prices' : tab === 'ussd' ? 'USSD Simulator' : 'Price Trends'}
            </TabsTrigger>
          ))}
        </TabsList>

        {/* Market Prices Tab */}
        <TabsContent value="prices" className="mt-6 space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <Input
              placeholder="Search markets or units..."
              className="h-11 rounded-xl bg-white border-slate-200 pl-10 font-medium"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
            />
          </div>
          <Card className="border-none shadow-xl shadow-slate-200/50 overflow-hidden">
            <Table>
              <TableHeader className="bg-slate-50">
                <TableRow>
                  <TableHead className="text-[10px] font-black uppercase tracking-widest">Market</TableHead>
                  <TableHead className="text-[10px] font-black uppercase tracking-widest">Price</TableHead>
                  <TableHead className="text-[10px] font-black uppercase tracking-widest">Unit</TableHead>
                  <TableHead className="text-[10px] font-black uppercase tracking-widest">Trend</TableHead>
                  <TableHead className="text-[10px] font-black uppercase tracking-widest">Verified</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPrices.length === 0 ? (
                  <TableRow><TableCell colSpan={5} className="text-center py-8 text-slate-400 font-medium">No matching prices found</TableCell></TableRow>
                ) : filteredPrices.map(p => (
                  <TableRow key={p.id}>
                    <TableCell className="font-bold text-slate-900">{p.location}</TableCell>
                    <TableCell className="font-bold text-slate-900">₦{p.price.toLocaleString()}</TableCell>
                    <TableCell className="text-slate-600 font-medium">{p.unit}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={cn(
                        'text-[10px] font-black uppercase flex items-center gap-1',
                        p.trend === 'up' ? 'bg-green-50 text-green-700 border-green-100' :
                        p.trend === 'down' ? 'bg-red-50 text-red-700 border-red-100' :
                        'bg-slate-50 text-slate-700 border-slate-100'
                      )}>
                        {p.trend === 'up' ? <ArrowUpRight className="h-3 w-3" /> : p.trend === 'down' ? <ArrowDownRight className="h-3 w-3" /> : <Minus className="h-3 w-3" />}
                        {p.trend}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className={cn(
                        'text-[10px] font-black uppercase',
                        p.verified ? 'bg-green-50 text-green-700 border-green-100' : 'bg-amber-50 text-amber-700 border-amber-100'
                      )}>
                        {p.verified ? 'Yes' : 'Pending'}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>

        {/* USSD Simulator Tab */}
        <TabsContent value="ussd" className="mt-6 space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="border-none shadow-xl shadow-slate-200/50">
              <CardHeader>
                <CardTitle className="text-lg font-black flex items-center gap-2">
                  <Phone className="h-5 w-5 text-green-600" /> USSD Simulator
                </CardTitle>
                <CardDescription className="text-xs font-bold uppercase tracking-widest text-slate-400">
                  Dial *384*724# to access SAI services on any phone
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="rounded-2xl bg-slate-900 p-6 text-green-400 font-mono text-sm min-h-[200px]">
                  {ussdStep === 0 && (
                    <div className="space-y-3">
                      <p className="text-green-300 font-bold">SAI Mobile Services</p>
                      <p>Dial code:</p>
                      <form onSubmit={(e) => { e.preventDefault(); handleUssdSubmit(); }} className="flex gap-2">
                        <Input
                          placeholder="*384*724#"
                          value={ussdCode}
                          onChange={e => setUssdCode(e.target.value)}
                          className="bg-slate-800 border-slate-700 text-green-400 font-mono h-10 rounded-lg"
                        />
                        <Button size="sm" className="bg-green-600 hover:bg-green-500 h-10 rounded-lg font-bold">Dial</Button>
                      </form>
                    </div>
                  )}
                  {ussdStep > 0 && (
                    <div className="space-y-3">
                      <p className="text-green-300 font-bold">USSD Session Active</p>
                      <pre className="whitespace-pre-wrap text-green-300 leading-relaxed">{ussdResult}</pre>
                      {ussdStep === 1 && (
                        <form onSubmit={(e) => { e.preventDefault(); handleUssdSubmit(); }} className="flex gap-2 mt-4">
                          <Input
                            placeholder="Enter option (1-4)"
                            value={ussdCode}
                            onChange={e => setUssdCode(e.target.value)}
                            className="bg-slate-800 border-slate-700 text-green-400 font-mono h-10 rounded-lg"
                          />
                          <Button size="sm" className="bg-green-600 hover:bg-green-500 h-10 rounded-lg font-bold">Send</Button>
                        </form>
                      )}
                      {ussdStep === 2 && (
                        <Button onClick={() => { setUssdStep(0); setUssdResult(null); }} variant="outline" className="mt-4 border-green-600 text-green-400 hover:bg-green-900/30 rounded-lg font-bold">
                          New Session
                        </Button>
                      )}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-xl shadow-slate-200/50">
              <CardHeader>
                <CardTitle className="text-lg font-black flex items-center gap-2">
                  <MessageSquare className="h-5 w-5 text-blue-600" /> How USSD Works
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {[
                  { step: '1', title: 'Dial Code', desc: 'Dial *384*724# from any mobile phone (no internet needed)' },
                  { step: '2', title: 'Select Service', desc: 'Choose from market prices, weather, pest alerts, or contact agents' },
                  { step: '3', title: 'Get Response', desc: 'Receive instant information via SMS or screen display' },
                  { step: '4', title: 'Follow Up', desc: 'Save agent contacts for personalized advisory support' },
                ].map(item => (
                  <div key={item.step} className="flex gap-4 items-start">
                    <div className="flex-shrink-0 h-8 w-8 rounded-full bg-green-100 text-green-700 flex items-center justify-center font-black text-sm">
                      {item.step}
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm">{item.title}</h4>
                      <p className="text-xs text-slate-500 leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Trends Tab */}
        <TabsContent value="trends" className="mt-6 space-y-4">
          <Card className="border-none shadow-xl shadow-slate-200/50">
            <CardHeader>
              <CardTitle className="text-lg font-black">Price Movement Overview</CardTitle>
              <CardDescription className="text-xs font-bold uppercase tracking-widest text-slate-400">
                Current trends across all tracked markets
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {marketPrices.map(p => (
                  <motion.div key={p.id} whileHover={{ scale: 1.02 }} className="rounded-2xl border p-5 bg-white shadow-md shadow-slate-100">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-bold text-slate-900 text-sm truncate">{p.location}</h4>
                      <Badge variant="outline" className={cn(
                        'text-[10px] font-black uppercase',
                        p.trend === 'up' ? 'bg-green-50 text-green-700 border-green-100' :
                        p.trend === 'down' ? 'bg-red-50 text-red-700 border-red-100' :
                        'bg-slate-50 text-slate-700 border-slate-100'
                      )}>{p.trend}</Badge>
                    </div>
                    <p className="text-2xl font-black text-slate-900">₦{p.price.toLocaleString()}</p>
                    <p className="text-xs text-slate-400 font-medium mt-1">{p.unit}</p>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}