import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { ShieldCheck, Mail, Lock, Loader2, Leaf, UserPlus, Eye, EyeOff, Sparkles } from 'lucide-react';

export function AdminLogin() {
  const navigate = useNavigate();
  const location = useLocation();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  // Prefill email from signup redirect
  useEffect(() => {
    const state = location.state as { prefillEmail?: string } | null;
    if (state?.prefillEmail) {
      setEmail(state.prefillEmail);
      // Clear state so it doesn't persist on refresh
      navigate(location.pathname, { state: {}, replace: true });
    }
  }, [location, navigate]);

  const completeLogin = async (targetEmail: string) => {
    const { data: adminRow, error: adminError } = await supabase
      .from('admins')
      .select('*')
      .eq('email', targetEmail)
      .single();

    if (adminError || !adminRow) {
      toast.error('Access denied. You are not registered as an admin.');
      return false;
    }

    toast.success(`Welcome back, ${adminRow.name}!`);
    navigate('/admin');
    return true;
  };

  const quickDemoLogin = async () => {
    setLoading(true);
    try {
      const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
      if (!sessionError && sessionData.session) {
        const ok = await completeLogin(sessionData.session.user.email || '');
        if (ok) return;
      }
      // Fall back to demo admin sign-in with a seeded demo account
      const demoEmail = 'admin@demo.sai.app';
      const demoPassword = 'DemoAdmin@2025';
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: demoEmail,
        password: demoPassword,
      });

      if (signInError && !/invalid login credentials/i.test(signInError.message)) {
        // No demo account yet — try to create one (best effort, seeded via migration)
        await supabase.auth.signUp({ email: demoEmail, password: demoPassword });
      }

      const ok = await completeLogin(demoEmail);
      if (ok) return;

      // Last resort: session-only demo view
      toast.success('Demo mode: exploring the dashboard');
      navigate('/admin');
    } catch (error: any) {
      toast.error(error.message || 'Demo login failed');
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;

      // Verify admin status
      const { data: adminRow, error: adminError } = await supabase
        .from('admins')
        .select('*')
        .eq('email', email)
        .single();

      if (adminError || !adminRow) {
        toast.error('Access denied. You are not registered as an admin.');
        await supabase.auth.signOut();
        return;
      }

      toast.success(`Welcome back, ${adminRow.name}!`);
      navigate('/admin');
    } catch (error: any) {
      toast.error(error.message || 'Login failed. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-green-50 via-white to-emerald-50 p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-green-600 shadow-lg shadow-green-200">
            <ShieldCheck className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-2xl font-black text-slate-900">SAI Admin</h1>
          <p className="mt-1 text-sm text-slate-500">Smart Agro-Insights Control Panel</p>
        </div>

        {/* Login Card */}
        <div className="rounded-2xl border border-slate-200 bg-white p-8 shadow-xl shadow-slate-100/50">
          <form onSubmit={handleLogin} className="space-y-5">
            <div className="text-center mb-2">
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">First time? Register below</p>
            </div>

            <div>
              <label className="mb-1.5 block text-sm font-semibold text-slate-700">
                Email Address
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="admin@example.com"
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 py-3 pl-10 pr-4 text-sm font-medium text-slate-900 placeholder:text-slate-400 focus:border-green-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-green-100"
                />
              </div>
            </div>

            <div>
              <label className="mb-1.5 block text-sm font-semibold text-slate-700">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 py-3 pl-10 pr-10 text-sm font-medium text-slate-900 placeholder:text-slate-400 focus:border-green-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-green-100"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-green-600 py-3 text-sm font-bold text-white shadow-lg shadow-green-200 transition-all hover:bg-green-700 active:scale-[0.98] disabled:opacity-60"
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Signing in…
                </>
              ) : (
                <>
                  <ShieldCheck className="h-4 w-4" />
                  Sign In to Admin
                </>
              )}
            </button>
          </form>

          <button
            onClick={quickDemoLogin}
            disabled={loading}
            className="mb-3 flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-green-400 bg-green-50/60 py-2.5 text-sm font-bold text-green-700 transition-all hover:bg-green-100 active:scale-[0.98] disabled:opacity-60"
          >
            <Sparkles className="h-4 w-4" /> Quick Login as Demo Admin
          </button>

          <div className="relative mb-3">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-200" />
            </div>
            <div className="relative flex justify-center">
              <span className="bg-white px-3 text-[10px] font-bold uppercase tracking-wider text-slate-400">or</span>
            </div>
          </div>

          <div className="mt-3 space-y-3">
            <button
              onClick={() => navigate('/admin/signup')}
              className="flex w-full items-center justify-center gap-2 rounded-xl border border-green-300 bg-green-50 py-2.5 text-sm font-bold text-green-700 transition-all hover:bg-green-100 active:scale-[0.98]"
            >
              <UserPlus className="h-4 w-4" /> Register New Admin Account
            </button>
            <button
              onClick={() => navigate('/')}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-green-600"
            >
              <Leaf className="h-3.5 w-3.5" />
              Back to App
            </button>
          </div>
        </div>

        <p className="mt-6 text-center text-[11px] text-slate-400">
          Authorized personnel only. All access is logged.
        </p>
      </div>
    </div>
  );
}

export default AdminLogin;