import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import {
  ShieldCheck,
  Users,
  Leaf,
  Cloud,
  TrendingUp,
  Bell,
  Smartphone,
  ClipboardList,
  LogOut,
  Loader2,
  AlertTriangle,
  CheckCircle2,
  Database,
  SlidersHorizontal,
  ScrollText,
  Activity,
  GitPullRequest,
  Layers3,
  MessageCircleQuestion,
  Download,
  Radio,
} from 'lucide-react';
import AdminUpdatesPanel from '@/components/admin/AdminUpdatesPanel';
import AdminMarketPanel from '@/components/admin/AdminMarketPanel';
import AdminAlertsPanel from '@/components/admin/AdminAlertsPanel';
import AdminConsultationPanel from '@/components/admin/AdminConsultationPanel';
import AdminDatabaseControlPanel from '@/components/admin/AdminDatabaseControlPanel';
import AdminPlatformSettingsPanel from '@/components/admin/AdminPlatformSettingsPanel';
import { fetchAuditLogs, type AuditLog } from '@/components/admin/admin-api';

interface FarmerRecord {
  id: string;
  name: string;
  farmer_name?: string;
  created_at: string;
}

interface SystemAlert {
  id: string;
  message: string;
  severity: string;
  created_at: string;
}

type TabKey = 'overview' | 'database' | 'platform' | 'consultations' | 'market' | 'updates' | 'alerts' | 'audit';

const TABS: { key: TabKey; label: string; icon: React.ReactNode }[] = [
  { key: 'overview', label: 'Overview', icon: <Activity className="h-4 w-4" /> },
  { key: 'database', label: 'Database Control', icon: <Database className="h-4 w-4" /> },
  { key: 'platform', label: 'Platform Settings', icon: <SlidersHorizontal className="h-4 w-4" /> },
  { key: 'consultations', label: 'AI Inquiries', icon: <MessageCircleQuestion className="h-4 w-4" /> },
  { key: 'market', label: 'Market & Pricing', icon: <TrendingUp className="h-4 w-4" /> },
  { key: 'updates', label: 'Alerts & Updates', icon: <Bell className="h-4 w-4" /> },
  { key: 'audit', label: 'Audit Logs', icon: <ScrollText className="h-4 w-4" /> },
];

function AdminDashboardInner() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [adminName, setAdminName] = useState('');
  const [adminRole, setAdminRole] = useState('');
  const [adminEmail, setAdminEmail] = useState('');
  const [farmerCount, setFarmerCount] = useState(0);
  const [weatherAlerts, setWeatherAlerts] = useState(0);
  const [marketUpdates, setMarketUpdates] = useState(0);
  const [userCount, setUserCount] = useState(0);
  const [pendingConsultations, setPendingConsultations] = useState(0);
  const [recentFarmers, setRecentFarmers] = useState<FarmerRecord[]>([]);
  const [systemAlerts, setSystemAlerts] = useState<SystemAlert[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [activeTab, setActiveTab] = useState<TabKey>('overview');
  const [dbLive, setDbLive] = useState(false);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate('/admin/login');
        return;
      }

      const { data: adminRow, error: adminError } = await supabase
        .from('admins')
        .select('*')
        .eq('email', session.user.email)
        .single();

      if (adminError || !adminRow) {
        toast.error('Access denied. Not registered as admin.');
        await supabase.auth.signOut();
        navigate('/admin/login');
        return;
      }

      setAdminName(adminRow.name || session.user.email?.split('@')[0] || 'Administrator');
      setAdminRole(adminRow.role || 'admin');
      setAdminEmail(session.user.email || '');
      setDbLive(true);
      await Promise.all([fetchDashboardData(), loadAuditLogs()]);
    } catch (error: any) {
      toast.error(error.message || 'Session check failed');
      navigate('/admin/login');
    } finally {
      setLoading(false);
    }
  };

  const fetchDashboardData = async () => {
    try {
      const { count: farmerCountData } = await supabase
        .from('farm_records')
        .select('*', { count: 'exact', head: true });
      setFarmerCount(farmerCountData || 0);

      const { count: userCountData } = await supabase
        .from('user_accounts')
        .select('*', { count: 'exact', head: true });
      setUserCount(userCountData || 0);

      const { count: pendingData } = await supabase
        .from('ai_consultations')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'pending');
      setPendingConsultations(pendingData || 0);

      const { count: weatherCount } = await supabase
        .from('alerts')
        .select('*', { count: 'exact', head: true })
        .eq('type', 'weather');
      setWeatherAlerts(weatherCount || 0);

      const { count: marketCount } = await supabase
        .from('market_prices')
        .select('*', { count: 'exact', head: true });
      setMarketUpdates(marketCount || 0);

      const { data: recent } = await supabase
        .from('farm_records')
        .select('id, farmer_name, name, created_at')
        .order('created_at', { ascending: false })
        .limit(10);
      setRecentFarmers((recent || []).map(r => ({
        id: r.id,
        name: r.farmer_name || r.name || 'Unknown',
        created_at: r.created_at,
      })));

      const { data: alerts } = await supabase
        .from('alerts')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(10);
      setSystemAlerts(alerts || []);
    } catch (error) {
      toast.error('Failed to load dashboard data');
    }
  };

  const loadAuditLogs = async () => {
    try {
      setAuditLogs(await fetchAuditLogs(150));
    } catch {
      setAuditLogs([]);
    }
  };

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
      toast.success('Logged out successfully');
      navigate('/admin/login');
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50">
        <div className="text-center">
          <Loader2 className="mx-auto h-8 w-8 animate-spin text-green-600" />
          <p className="mt-4 text-sm font-semibold text-slate-600">Loading Admin Dashboard…</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/90 px-6 py-4 shadow-sm backdrop-blur">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-green-600 text-white shadow-md shadow-green-200">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-900">Admin Control Center</h1>
              <p className="flex items-center gap-2 text-xs text-slate-500">
                Welcome, {adminName} · <span className="font-bold uppercase tracking-wider text-green-700">{adminRole}</span>
                <span className="inline-flex items-center gap-1 rounded-full bg-green-100 px-2 py-0.5 text-[10px] font-black text-green-700">
                  <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-green-500" /> DB LIVE
                </span>
              </p>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 rounded-lg border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-600 transition-all hover:bg-slate-50 hover:text-red-600"
          >
            <LogOut className="h-4 w-4" />
            Sign Out
          </button>
        </div>
      </header>

      {/* Tab Navigation */}
      <div className="sticky top-[73px] z-10 overflow-x-auto border-b border-slate-200 bg-white px-6 shadow-sm">
        <div className="flex gap-1 -mb-px">
          {TABS.map(tab => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-2 whitespace-nowrap px-4 py-3 text-sm font-bold transition-all border-b-2 ${
                activeTab === tab.key
                  ? 'border-green-600 text-green-700'
                  : 'border-transparent text-slate-500 hover:text-slate-700'
              }`}
            >
              {tab.icon}
              {tab.label}
              {tab.key === 'consultations' && pendingConsultations > 0 && (
                <span className="rounded-full bg-red-500 px-1.5 py-0.5 text-[10px] font-black text-white">
                  {pendingConsultations}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <main className="p-6">
        {activeTab === 'overview' && (
          <>
            {/* Stats Grid */}
            <div className="mb-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <StatCard icon={<Users className="h-5 w-5" />} label="Total Farmers" value={farmerCount} color="blue" />
              <StatCard icon={<Users className="h-5 w-5" />} label="User Accounts" value={userCount} color="purple" />
              <StatCard icon={<MessageCircleQuestion className="h-5 w-5" />} label="Pending Inquiries" value={pendingConsultations} color="amber" />
              <StatCard icon={<TrendingUp className="h-5 w-5" />} label="Market Listings" value={marketUpdates} color="green" />
            </div>
            <div className="mb-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <StatCard icon={<Cloud className="h-5 w-5" />} label="Weather Alerts" value={weatherAlerts} color="cyan" />
              <StatCard icon={<Bell className="h-5 w-5" />} label="System Alerts" value={systemAlerts.length} color="red" />
            </div>

            {/* Two Column Layout */}
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
              <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                <h2 className="mb-4 flex items-center gap-2 text-base font-bold text-slate-900">
                  <Leaf className="h-5 w-5 text-green-600" />
                  Recent Farmers
                </h2>
                {recentFarmers.length === 0 ? (
                  <EmptyState message="No farmers registered yet" />
                ) : (
                  <div className="space-y-3">
                    {recentFarmers.map((farmer) => (
                      <div
                        key={farmer.id}
                        className="flex items-center justify-between rounded-xl border border-slate-100 p-3"
                      >
                        <div className="flex items-center gap-3">
                          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-green-100 text-green-700">
                            <Users className="h-4 w-4" />
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-slate-900">{farmer.name}</p>
                            <p className="text-[11px] text-slate-500">
                              Joined {new Date(farmer.created_at).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <CheckCircle2 className="h-4 w-4 text-green-500" />
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                <h2 className="mb-4 flex items-center gap-2 text-base font-bold text-slate-900">
                  <AlertTriangle className="h-5 w-5 text-amber-500" />
                  System Alerts
                </h2>
                {systemAlerts.length === 0 ? (
                  <EmptyState message="No active system alerts" />
                ) : (
                  <div className="space-y-3">
                    {systemAlerts.map((alert) => (
                      <div
                        key={alert.id}
                        className={`rounded-xl border p-3 ${
                          alert.severity === 'critical'
                            ? 'border-red-200 bg-red-50'
                            : alert.severity === 'warning'
                            ? 'border-amber-200 bg-amber-50'
                            : 'border-blue-200 bg-blue-50'
                        }`}
                      >
                        <div className="flex items-start gap-2">
                          {alert.severity === 'critical' ? (
                            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-red-500" />
                          ) : alert.severity === 'warning' ? (
                            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-500" />
                          ) : (
                            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-blue-500" />
                          )}
                          <div>
                            <p className="text-sm font-semibold text-slate-900">{alert.message}</p>
                            <p className="text-[11px] text-slate-500">
                              {new Date(alert.created_at).toLocaleString()}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </>
        )}

        {activeTab === 'database' && <AdminDatabaseControlPanel actorName={adminName} />}

        {activeTab === 'platform' && <AdminPlatformSettingsPanel actorName={adminName} />}

        {activeTab === 'consultations' && <AdminConsultationPanel />}

        {activeTab === 'market' && <AdminMarketPanel />}

        {activeTab === 'updates' && <AdminUpdatesPanel />}

        {activeTab === 'audit' && (
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
            <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
              <h2 className="flex items-center gap-2 text-base font-bold text-slate-900">
                <ScrollText className="h-5 w-5 text-green-600" />
                Audit Logs
              </h2>
              <button
                onClick={loadAuditLogs}
                className="flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-bold text-slate-600 hover:bg-slate-50"
              >
                <Radio className="h-3.5 w-3.5" /> Refresh
              </button>
            </div>
            {auditLogs.length === 0 ? (
              <EmptyState message="No audit activity yet" />
            ) : (
              <div className="space-y-3">
                {auditLogs.map((log) => (
                  <div key={log.id} className="flex items-start gap-3 rounded-xl border border-slate-100 p-3">
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-green-100 text-green-700">
                      <ShieldCheck className="h-4 w-4" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold text-slate-900">
                        {log.actor} <span className="font-bold text-green-700">{log.action}</span>
                      </p>
                      {log.detail && <p className="truncate text-xs text-slate-500">{log.detail}</p>}
                      <p className="text-[11px] text-slate-400">
                        {new Date(log.created_at).toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}

/* ───── Sub-components ───── */

const COLOR_MAP: Record<string, string> = {
  blue: 'bg-blue-50 text-blue-600',
  amber: 'bg-amber-50 text-amber-600',
  green: 'bg-green-50 text-green-600',
  red: 'bg-red-50 text-red-600',
  purple: 'bg-purple-50 text-purple-600',
  cyan: 'bg-cyan-50 text-cyan-600',
};

function StatCard({
  icon,
  label,
  value,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  color: string;
}) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md">
      <div className={`mb-3 flex h-10 w-10 items-center justify-center rounded-xl ${COLOR_MAP[color] || COLOR_MAP.blue}`}>
        {icon}
      </div>
      <p className="text-2xl font-black text-slate-900">{value}</p>
      <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">{label}</p>
    </div>
  );
}

function EmptyState({ message }: { message: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-8 text-center">
      <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-slate-100">
        <ClipboardList className="h-5 w-5 text-slate-400" />
      </div>
      <p className="text-sm font-medium text-slate-500">{message}</p>
    </div>
  );
}

export default AdminDashboardInner;