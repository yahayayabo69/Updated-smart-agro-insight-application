import React from 'react';
import { 
  Cloud, 
  Sun, 
  CloudRain, 
  CloudLightning, 
  Wind, 
  Droplets, 
  Thermometer,
  ArrowRight,
  Info
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MOCK_WEATHER, MOCK_FORECAST } from '@/lib/mock-data';
import { motion } from 'framer-motion';

export default function Weather() {
  const getIcon = (condition: string, size = "h-8 w-8") => {
    switch (condition) {
      case 'Sunny': return <Sun className={`${size} text-amber-500`} />;
      case 'Rain': return <CloudRain className={`${size} text-blue-500`} />;
      case 'Thunderstorm': return <CloudLightning className={`${size} text-purple-600`} />;
      case 'Cloudy': return <Cloud className={`${size} text-slate-500`} />;
      case 'Partly Cloudy': return <Cloud className={`${size} text-slate-400`} />;
      default: return <Sun className={`${size} text-amber-500`} />;
    }
  };

  return (
    <div className="space-y-8 pb-8">
      <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between px-2">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">Weather Insights</h2>
          <p className="text-slate-500 font-medium">Localized forecast for {MOCK_WEATHER.location}</p>
        </div>
        <Badge variant="outline" className="w-fit border-green-200 bg-green-50 text-green-700 font-bold px-3 py-1">
          Last Updated: 12 mins ago
        </Badge>
      </div>

      <div className="grid gap-8 lg:grid-cols-3">
        {/* Current Weather Detailed Card */}
        <Card className="overflow-hidden border-none bg-white shadow-2xl shadow-slate-200/60 lg:col-span-2">
          <div className="relative p-8 md:p-12">
            <div className="absolute right-0 top-0 h-full w-1/3 opacity-5 pointer-events-none overflow-hidden">
               <Sun className="h-full w-full -mr-12 -mt-12 text-amber-500" />
            </div>

            <div className="relative z-10 flex flex-col gap-12 md:flex-row md:items-center">
              <div className="flex-1">
                <div className="flex items-center gap-4 mb-6">
                  <div className="rounded-3xl bg-amber-50 p-6 shadow-sm">
                    {getIcon(MOCK_WEATHER.condition, "h-16 w-16")}
                  </div>
                  <div>
                    <h3 className="text-2xl font-black text-slate-900">{MOCK_WEATHER.condition}</h3>
                    <p className="text-sm font-bold text-slate-400 uppercase tracking-widest">Currently</p>
                  </div>
                </div>
                
                <div className="flex items-baseline gap-2">
                  <span className="text-8xl font-black text-slate-900 tracking-tighter">{MOCK_WEATHER.temp}°</span>
                  <span className="text-4xl font-bold text-slate-300">C</span>
                </div>
              </div>

              <div className="grid flex-1 grid-cols-2 gap-6 md:border-l md:pl-12 md:border-slate-100">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs font-black text-slate-400 uppercase tracking-wider">
                    <Droplets className="h-3.5 w-3.5" /> Humidity
                  </div>
                  <p className="text-2xl font-black text-slate-900">{MOCK_WEATHER.humidity}%</p>
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs font-black text-slate-400 uppercase tracking-wider">
                    <Wind className="h-3.5 w-3.5" /> Wind Speed
                  </div>
                  <p className="text-2xl font-black text-slate-900">{MOCK_WEATHER.windSpeed} km/h</p>
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs font-black text-slate-400 uppercase tracking-wider">
                    <Thermometer className="h-3.5 w-3.5" /> Feels Like
                  </div>
                  <p className="text-2xl font-black text-slate-900">35°C</p>
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs font-black text-slate-400 uppercase tracking-wider">
                    <Info className="h-3.5 w-3.5" /> UV Index
                  </div>
                  <p className="text-2xl font-black text-amber-600">High (8)</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-slate-50 border-t border-slate-100 p-8">
             <div className="flex items-start gap-4">
                <div className="mt-1 flex h-8 w-8 items-center justify-center rounded-lg bg-green-600 text-white shadow-lg shadow-green-600/20">
                  <Info className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="font-black text-slate-900 mb-1 tracking-tight uppercase text-xs">Farmer's Field Advisory</h4>
                  <p className="text-sm font-medium text-slate-600 leading-relaxed italic">
                    "{MOCK_WEATHER.advice}"
                  </p>
                </div>
             </div>
          </div>
        </Card>

        {/* 5-Day Forecast Card */}
        <Card className="overflow-hidden border-none bg-white shadow-2xl shadow-slate-200/60">
          <CardHeader>
            <CardTitle className="text-xl font-black tracking-tight">5-Day Forecast</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {MOCK_FORECAST.map((item, idx) => (
              <div 
                key={idx}
                className="flex items-center justify-between rounded-2xl p-4 transition-colors hover:bg-slate-50"
              >
                <div className="w-12 text-sm font-black text-slate-900">{item.day}</div>
                <div className="flex flex-1 items-center justify-center gap-2 px-4">
                  {getIcon(item.condition, "h-6 w-6")}
                  <span className="text-xs font-bold text-slate-500">{item.condition}</span>
                </div>
                <div className="text-right">
                  <span className="text-lg font-black text-slate-900">{item.temp}°</span>
                </div>
              </div>
            ))}
          </CardContent>
          <div className="bg-slate-50 p-6 text-center">
            <Button variant="ghost" className="text-xs font-black text-green-600 uppercase tracking-widest flex items-center gap-2 mx-auto">
              View Detailed Radar <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
        </Card>
      </div>

      {/* Advisory Sections */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card className="border-none bg-green-50 p-6">
           <h3 className="text-lg font-black text-green-900 mb-3 tracking-tight">Planting Window</h3>
           <p className="text-sm text-green-800 leading-relaxed mb-4">
             The current weather pattern indicates a stable planting window for cereal crops like Maize and Sorghum over the next 48 hours.
           </p>
           <Badge className="bg-green-200 text-green-800 hover:bg-green-200 border-none font-bold">Recommended</Badge>
        </Card>
        <Card className="border-none bg-amber-50 p-6">
           <h3 className="text-lg font-black text-amber-900 mb-3 tracking-tight">Harvest Advisory</h3>
           <p className="text-sm text-amber-800 leading-relaxed mb-4">
             Prepare for rain on Wednesday. Ensure all harvested grains are properly stored and covered to prevent moisture damage.
           </p>
           <Badge className="bg-amber-200 text-amber-800 hover:bg-amber-200 border-none font-bold">Action Required</Badge>
        </Card>
      </div>
    </div>
  );
}
