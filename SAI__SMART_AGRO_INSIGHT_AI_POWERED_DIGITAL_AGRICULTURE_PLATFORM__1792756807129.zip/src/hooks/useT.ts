import { TRANSLATIONS } from '@/data/saiData';

export function useT() {
  const lang = typeof window !== 'undefined'
    ? ((localStorage.getItem('sai_lang') as 'en' | 'ha') || 'en')
    : 'en';

  return function t(key: string): string {
    const val = TRANSLATIONS[lang]?.[key as keyof typeof TRANSLATIONS.en];
    if (typeof val === 'string') return val;
    return key;
  };
}