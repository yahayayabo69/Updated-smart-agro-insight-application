-- AI Consultations for Ask SAI / Tambayi SAI multimodal interface
CREATE TABLE IF NOT EXISTS public.ai_consultations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question text NOT NULL,
  language text NOT NULL DEFAULT 'en',
  media_type text NOT NULL DEFAULT 'none',
  media_urls text[] NOT NULL DEFAULT '{}',
  media_names text[] NOT NULL DEFAULT '{}',
  media_sizes bigint[] NOT NULL DEFAULT '{}',
  ai_response text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Allow public (anon) inserts so farmers can submit without an auth flow
ALTER TABLE public.ai_consultations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_ai_consultations" ON public.ai_consultations;
CREATE POLICY "anon_select_ai_consultations"
  ON public.ai_consultations FOR SELECT
  TO anon USING (true);

DROP POLICY IF EXISTS "anon_insert_ai_consultations" ON public.ai_consultations;
CREATE POLICY "anon_insert_ai_consultations"
  ON public.ai_consultations FOR INSERT
  TO anon WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_ai_consultations" ON public.ai_consultations;
CREATE POLICY "anon_update_ai_consultations"
  ON public.ai_consultations FOR UPDATE
  TO anon USING (true) WITH CHECK (true);

-- Index for admin review ordering
CREATE INDEX IF NOT EXISTS idx_ai_consultations_created_at
  ON public.ai_consultations (created_at DESC);