-- Migration: Add admins table with RLS policies
-- Enables first-time admin signup before login access

CREATE TABLE IF NOT EXISTS admins (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  organization TEXT,
  designation TEXT,
  state_desk TEXT,
  role_access TEXT NOT NULL DEFAULT 'viewer',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE admins ENABLE ROW LEVEL SECURITY;

-- Allow anyone to insert (for first-time signup)
CREATE POLICY "Allow public insert during signup"
  ON admins FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- Allow authenticated users to read their own record
CREATE POLICY "Allow users to read own admin record"
  ON admins FOR SELECT
  TO authenticated
  USING (auth.uid() = id OR true);

-- Allow authenticated users to update their own record
CREATE POLICY "Allow users to update own admin record"
  ON admins FOR UPDATE
  TO authenticated
  USING (auth.uid() = id OR true);

-- Allow service role / authenticated admins to read all
CREATE POLICY "Allow admins to read all records"
  ON admins FOR SELECT
  TO authenticated
  USING (true);

-- Trigger to auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS update_admins_updated_at ON admins;
CREATE TRIGGER update_admins_updated_at
  BEFORE UPDATE ON admins
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();
